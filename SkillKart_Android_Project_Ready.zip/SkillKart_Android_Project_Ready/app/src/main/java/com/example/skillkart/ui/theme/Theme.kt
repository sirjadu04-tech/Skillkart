package com.example.skillkart.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Re-export colors for convenience
val SaffronPrimary = com.example.ui.theme.SaffronPrimary
val SaffronSecondary = com.example.ui.theme.SaffronSecondary
val SaffronContainer = com.example.ui.theme.SaffronContainer
val OnSaffronContainer = com.example.ui.theme.OnSaffronContainer

val IndigoPrimary = com.example.ui.theme.IndigoPrimary
val IndigoSecondary = com.example.ui.theme.IndigoSecondary
val IndigoContainer = com.example.ui.theme.IndigoContainer
val OnIndigoContainer = com.example.ui.theme.OnIndigoContainer

val EmeraldSuccess = com.example.ui.theme.EmeraldSuccess
val EmeraldSuccessContainer = com.example.ui.theme.EmeraldSuccessContainer
val GoldStar = com.example.ui.theme.GoldStar
val GoldContainer = com.example.ui.theme.GoldContainer

val SlateBackground = com.example.ui.theme.SlateBackground
val SlateSurface = com.example.ui.theme.SlateSurface
val SlateSurfaceVariant = com.example.ui.theme.SlateSurfaceVariant
val SlateBorder = com.example.ui.theme.SlateBorder
val SlateTextPrimary = com.example.ui.theme.SlateTextPrimary
val SlateTextSecondary = com.example.ui.theme.SlateTextSecondary

val DarkBackground = com.example.ui.theme.DarkBackground
val DarkSurface = com.example.ui.theme.DarkSurface
val DarkSurfaceVariant = com.example.ui.theme.DarkSurfaceVariant
val DarkBorder = com.example.ui.theme.DarkBorder
val DarkTextPrimary = com.example.ui.theme.DarkTextPrimary
val DarkTextSecondary = com.example.ui.theme.DarkTextSecondary
val DarkSaffronPrimary = com.example.ui.theme.DarkSaffronPrimary
val DarkIndigoContainer = com.example.ui.theme.DarkIndigoContainer

@Composable
fun SkillKartTheme(
    darkTheme: Boolean = androidx.compose.foundation.isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    com.example.ui.theme.SkillKartTheme(
        darkTheme = darkTheme,
        dynamicColor = dynamicColor,
        content = content
    )
}
