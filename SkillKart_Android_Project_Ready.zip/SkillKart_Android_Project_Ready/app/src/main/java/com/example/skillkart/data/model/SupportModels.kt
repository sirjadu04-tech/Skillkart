package com.example.skillkart.data.model

enum class TicketStatus(val displayName: String, val hindiName: String) {
    OPEN("Open", "खुला"),
    WAITING_FOR_SUPPORT("Waiting for Support", "सपोर्ट प्रतीक्षा"),
    WAITING_FOR_USER("Waiting for User", "उपयोगकर्ता प्रतीक्षा"),
    RESOLVED("Resolved", "हल किया गया"),
    CLOSED("Closed", "बंद")
}

enum class TicketPriority(val displayName: String, val level: Int) {
    LOW("Low", 1),
    MEDIUM("Medium", 2),
    HIGH("High", 3),
    URGENT("Urgent", 4)
}

object ComplaintCategories {
    val ALL = listOf(
        "Order Problem",
        "Payment Problem",
        "Worker Problem",
        "Customer Problem",
        "Refund Problem",
        "Account Problem",
        "Safety Problem",
        "Fraud/Scam Report",
        "Other"
    )

    fun getIcon(category: String): String {
        return when (category) {
            "Order Problem" -> "📦"
            "Payment Problem" -> "💳"
            "Worker Problem" -> "👷"
            "Customer Problem" -> "👤"
            "Refund Problem" -> "💸"
            "Account Problem" -> "🔐"
            "Safety Problem" -> "🛡️"
            "Fraud/Scam Report" -> "🚨"
            else -> "❓"
        }
    }
}

data class SupportTicket(
    val id: String = "",
    val ticketId: String = id,
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val userRole: String = "customer",
    val subject: String = "",
    val category: String = "General Support",
    val status: TicketStatus = TicketStatus.OPEN,
    val priority: TicketPriority = TicketPriority.MEDIUM,
    val relatedOrderId: String? = null,
    val relatedOrderTitle: String? = null,
    val internalNotes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastMessage: String = "",
    val unreadUserCount: Int = 0,
    val unreadAdminCount: Int = 0
) {
    val isOpen: Boolean get() = status == TicketStatus.OPEN || status == TicketStatus.WAITING_FOR_SUPPORT || status == TicketStatus.WAITING_FOR_USER
    val isResolvedOrClosed: Boolean get() = status == TicketStatus.RESOLVED || status == TicketStatus.CLOSED

    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "ticketId" to id,
            "id" to id,
            "userId" to userId,
            "userName" to userName,
            "userEmail" to userEmail,
            "userRole" to userRole,
            "subject" to subject,
            "category" to category,
            "status" to status.name,
            "priority" to priority.name,
            "relatedOrderId" to relatedOrderId,
            "relatedOrderTitle" to relatedOrderTitle,
            "internalNotes" to internalNotes,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt,
            "lastMessage" to lastMessage,
            "unreadUserCount" to unreadUserCount,
            "unreadAdminCount" to unreadAdminCount
        )
    }
}

data class SupportMessage(
    val id: String = "",
    val messageId: String = id,
    val ticketId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderRole: String = "user", // "user", "admin", "support"
    val message: String = "",
    val imageUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val read: Boolean = false,
    val formattedTime: String = "Just now"
) {
    val isFromSupport: Boolean get() = senderRole.equals("admin", ignoreCase = true) || senderRole.equals("support", ignoreCase = true)

    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "messageId" to id,
            "id" to id,
            "ticketId" to ticketId,
            "senderId" to senderId,
            "senderName" to senderName,
            "senderRole" to senderRole,
            "message" to message,
            "imageUrl" to imageUrl,
            "createdAt" to createdAt,
            "read" to read,
            "formattedTime" to formattedTime
        )
    }
}

data class Complaint(
    val id: String = "",
    val complaintId: String = id,
    val ticketId: String = "",
    val userId: String = "",
    val userName: String = "",
    val category: String = "Other",
    val orderId: String? = null,
    val orderTitle: String? = null,
    val details: String = "",
    val evidenceImageUrl: String? = null,
    val status: String = "Under Investigation", // Under Investigation, Action Taken, Resolved, Closed
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "complaintId" to id,
            "id" to id,
            "ticketId" to ticketId,
            "userId" to userId,
            "userName" to userName,
            "category" to category,
            "orderId" to orderId,
            "orderTitle" to orderTitle,
            "details" to details,
            "evidenceImageUrl" to evidenceImageUrl,
            "status" to status,
            "createdAt" to createdAt
        )
    }
}

data class FaqItem(
    val id: String = "",
    val question: String = "",
    val answer: String = "",
    val category: String = "General",
    val orderIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "question" to question,
            "answer" to answer,
            "category" to category,
            "orderIndex" to orderIndex,
            "createdAt" to createdAt
        )
    }
}
