package com.example.skillkart.ui.screens.create

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Title
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.skillkart.data.model.PostType
import com.example.skillkart.data.model.ServicePackage
import com.example.skillkart.data.model.SkillCategories
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import com.example.skillkart.ui.theme.EmeraldSuccess
import com.example.skillkart.ui.theme.IndigoPrimary
import com.example.skillkart.ui.theme.SaffronPrimary

@Composable
fun CreateScreen(
    currentUser: User,
    myServices: List<ServicePackage>,
    onCreatePost: (
        title: String,
        caption: String,
        type: PostType,
        tags: List<String>,
        linkedServiceId: String?,
        linkedServiceTitle: String?,
        linkedPriceInr: Int?,
        beforeDesc: String?,
        afterDesc: String?
    ) -> Unit,
    onCreateService: (
        title: String,
        category: String,
        priceInr: Int,
        completionTime: String,
        serviceRadius: String,
        maxVisits: String,
        description: String,
        inclusions: List<String>
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Post Work Showcase, 1 = Fixed-Price Service Package

    // Post creation state
    var postTitle by remember { mutableStateOf("") }
    var postCaption by remember { mutableStateOf("") }
    var postType by remember { mutableStateOf(PostType.WORK_SHOWCASE) }
    var postTags by remember { mutableStateOf("#Delhi #Welding #ProWorker") }
    var beforeDescription by remember { mutableStateOf("") }
    var afterDescription by remember { mutableStateOf("") }
    var linkedServiceId by remember { mutableStateOf<String?>(null) }

    // Service package creation state
    var serviceTitle by remember { mutableStateOf("") }
    var serviceCategory by remember { mutableStateOf("Welding") }
    var servicePrice by remember { mutableStateOf("1200") }
    var serviceCompletionTime by remember { mutableStateOf("2 - 3 Hours") }
    var serviceRadius by remember { mutableStateOf("15 km") }
    var serviceMaxVisits by remember { mutableStateOf("1 Visit Included") }
    var serviceDescription by remember { mutableStateOf("") }
    val serviceInclusions = remember {
        mutableStateListOf(
            "Complete on-site inspection",
            "Labor & precision tools included",
            "1-Month work warranty"
        )
    }
    var newInclusionText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("create_screen")
    ) {
        Text(
            text = "Worker Studio (कारीगर स्टूडियो)",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Showcase your real craft to customers or launch a fixed-price package",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(14.dp))

        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.clip(RoundedCornerShape(12.dp)),
            divider = {}
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DynamicFeed, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Post Work", fontWeight = FontWeight.Bold)
                    }
                }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Inventory, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New Package", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            // === CREATE POST FORM ===
            Text(
                text = "Select Post Type:",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    PostType.WORK_SHOWCASE to "Work Showcase 🛠️",
                    PostType.BEFORE_AFTER to "Before / After 🔄",
                    PostType.SERVICE_OFFER to "Special Offer 🏷️",
                    PostType.TIPS_UPDATE to "Craft Tips 💡"
                ).forEach { (type, label) ->
                    FilterChip(
                        selected = postType == type,
                        onClick = { postType = type },
                        label = { Text(label, fontWeight = if (postType == type) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = postTitle,
                onValueChange = { postTitle = it },
                label = { Text("Title / Post Headline") },
                placeholder = { Text("e.g. Completed heavy MS Main Gate installation") },
                leadingIcon = { Icon(Icons.Default.Title, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_post_title_input"),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = postCaption,
                onValueChange = { postCaption = it },
                label = { Text("Caption & Work Details / विवरण") },
                placeholder = { Text("Share materials used, techniques, time taken, or warranty offered...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_post_caption_input"),
                shape = RoundedCornerShape(10.dp),
                minLines = 3
            )

            if (postType == PostType.BEFORE_AFTER) {
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = beforeDescription,
                    onValueChange = { beforeDescription = it },
                    label = { Text("Before State (पहले की स्थिति)") },
                    placeholder = { Text("e.g. Broken rusted latch and sagging hinge") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = afterDescription,
                    onValueChange = { afterDescription = it },
                    label = { Text("After State (काम के बाद)") },
                    placeholder = { Text("e.g. Re-aligned frame, heavy-duty ball bearing hinges, rust coat") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Link existing service package (Fiverr/Instagram hybrid concept)
            if (myServices.isNotEmpty()) {
                Text(
                    text = "Link a Fixed-Price Package to this post (Optional):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = linkedServiceId == null,
                        onClick = { linkedServiceId = null },
                        label = { Text("None") }
                    )
                    myServices.forEach { srv ->
                        FilterChip(
                            selected = linkedServiceId == srv.id,
                            onClick = { linkedServiceId = srv.id },
                            label = { Text("${srv.title} (₹${srv.priceInr})") }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = postTags,
                onValueChange = { postTags = it },
                label = { Text("Hashtags / Tags") },
                placeholder = { Text("#Electrician #SafeWiring #Noida") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = {
                    val finalTitle = postTitle.ifBlank { "Showcase of recent work" }
                    val finalCaption = postCaption.ifBlank { "Finished precision work with premium quality standards." }
                    val tagsList = postTags.split(" ", ",").filter { it.isNotBlank() }
                    val linkedSrv = myServices.find { it.id == linkedServiceId }
                    onCreatePost(
                        finalTitle,
                        finalCaption,
                        postType,
                        tagsList,
                        linkedSrv?.id,
                        linkedSrv?.title,
                        linkedSrv?.priceInr,
                        if (postType == PostType.BEFORE_AFTER) beforeDescription.ifBlank { "Before repair state" } else null,
                        if (postType == PostType.BEFORE_AFTER) afterDescription.ifBlank { "Clean completed repair" } else null
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_post_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text(
                    text = "Publish to SkillKart Feed 🚀",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

        } else {
            // === CREATE FIXED PRICE SERVICE PACKAGE ===
            Text(
                text = "Package Category:",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SkillCategories.ALL.filter { it.name != "All" }.forEach { cat ->
                    val isSelected = serviceCategory == cat.name
                    FilterChip(
                        selected = isSelected,
                        onClick = { serviceCategory = cat.name },
                        label = { Text("${cat.icon} ${cat.name}") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = serviceTitle,
                onValueChange = { serviceTitle = it },
                label = { Text("Service Package Name / पैकेज का नाम") },
                placeholder = { Text("e.g. Complete Main Gate Fabrication & Fitting") },
                leadingIcon = { Icon(Icons.Default.Build, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_service_title_input"),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Fixed Price in INR (₹)
            OutlinedTextField(
                value = servicePrice,
                onValueChange = { servicePrice = it.filter { char -> char.isDigit() } },
                label = { Text("Fixed Price in INR (₹) / तय कीमत") },
                leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = SaffronPrimary) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("create_service_price_input"),
                shape = RoundedCornerShape(10.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = serviceCompletionTime,
                    onValueChange = { serviceCompletionTime = it },
                    label = { Text("Est. Completion Time") },
                    leadingIcon = { Icon(Icons.Default.Timer, contentDescription = null) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = serviceRadius,
                    onValueChange = { serviceRadius = it },
                    label = { Text("Service Radius") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = serviceDescription,
                onValueChange = { serviceDescription = it },
                label = { Text("Detailed Package Description / विवरण") },
                placeholder = { Text("Explain exactly what customers will receive in this fixed package...") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                minLines = 3
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Inclusions Checklist
            Text(
                text = "What is included in this package (पैकेज में क्या शामिल है):",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                serviceInclusions.forEachIndexed { idx, inc ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = inc, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        IconButton(onClick = { serviceInclusions.removeAt(idx) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(18.dp))
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = newInclusionText,
                        onValueChange = { newInclusionText = it },
                        placeholder = { Text("Add inclusion (e.g. Free 30-day follow-up)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = {
                            if (newInclusionText.isNotBlank()) {
                                serviceInclusions.add(newInclusionText.trim())
                                newInclusionText = ""
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                    ) {
                        Text("+ Add")
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    val finalTitle = serviceTitle.ifBlank { "$serviceCategory Professional Service Package" }
                    val finalPrice = servicePrice.toIntOrNull() ?: 1500
                    val finalDesc = serviceDescription.ifBlank { "Standard fixed price package provided by certified specialist." }
                    onCreateService(
                        finalTitle,
                        serviceCategory,
                        finalPrice,
                        serviceCompletionTime,
                        serviceRadius,
                        serviceMaxVisits,
                        finalDesc,
                        serviceInclusions.toList()
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("submit_service_package_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text(
                    text = "Publish Fixed-Price Package 📦",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}
