package com.example

import android.app.Application
import android.util.Log
import com.example.skillkart.data.firebase.FirebaseConfig

class SkillKartApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        try {
            val initialized = FirebaseConfig.initialize(this)
            Log.i("SkillKartApp", "Firebase initialized on app startup: $initialized")
        } catch (e: Exception) {
            Log.e("SkillKartApp", "Error during Firebase startup initialization", e)
        }
    }
}
