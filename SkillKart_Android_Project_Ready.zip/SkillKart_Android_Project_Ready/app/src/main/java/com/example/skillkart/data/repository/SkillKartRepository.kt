package com.example.skillkart.data.repository

import android.content.Context
import android.util.Log
import androidx.room.Room
import com.example.skillkart.data.firebase.FirebaseManager
import com.example.skillkart.data.local.ChatMessageEntity
import com.example.skillkart.data.local.NotificationEntity
import com.example.skillkart.data.local.OrderEntity
import com.example.skillkart.data.local.PostEntity
import com.example.skillkart.data.local.ReviewEntity
import com.example.skillkart.data.local.ServicePackageEntity
import com.example.skillkart.data.local.SkillKartDatabase
import com.example.skillkart.data.model.CategoryItem
import com.example.skillkart.data.model.Challenge
import com.example.skillkart.data.model.ChallengeParticipant
import com.example.skillkart.data.model.SampleChallenges
import com.example.skillkart.data.model.ChatMessage
import com.example.skillkart.data.model.Comment
import com.example.skillkart.data.model.Complaint
import com.example.skillkart.data.model.FaqItem
import com.example.skillkart.data.model.NotificationItem
import com.example.skillkart.data.model.NotificationType
import com.example.skillkart.data.model.Order
import com.example.skillkart.data.model.OrderStatus
import com.example.skillkart.data.model.Post
import com.example.skillkart.data.model.PostType
import com.example.skillkart.data.model.Review
import com.example.skillkart.data.model.ServicePackage
import com.example.skillkart.data.model.SupportMessage
import com.example.skillkart.data.model.SupportTicket
import com.example.skillkart.data.model.TicketPriority
import com.example.skillkart.data.model.TicketStatus
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SkillKartRepository private constructor(private val context: Context) {

    val firebaseManager = FirebaseManager.getInstance(context)
    val authRepository = AuthRepository.getInstance()

    private val db = Room.databaseBuilder(
        context.applicationContext,
        SkillKartDatabase::class.java,
        "skillkart_db"
    ).fallbackToDestructiveMigration().build()

    private val dao = db.skillKartDao()
    private val repoScope = CoroutineScope(Dispatchers.IO)

    // Demo / Active Users
    private val _allUsers = MutableStateFlow<List<User>>(initialUsers)
    val allUsers: StateFlow<List<User>> = _allUsers.asStateFlow()

    private val _currentUser = MutableStateFlow<User>(initialUsers[0]) // Default: Customer (Rahul)
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // In-memory comments store
    private val _postComments = MutableStateFlow<Map<String, List<Comment>>>(initialComments)
    val postComments: StateFlow<Map<String, List<Comment>>> = _postComments.asStateFlow()

    // Support System State Flows
    private val _supportTickets = MutableStateFlow<List<SupportTicket>>(initialSupportTickets)
    val supportTickets: StateFlow<List<SupportTicket>> = _supportTickets.asStateFlow()

    private val _supportMessages = MutableStateFlow<Map<String, List<SupportMessage>>>(initialSupportMessages)
    val supportMessages: StateFlow<Map<String, List<SupportMessage>>> = _supportMessages.asStateFlow()

    private val _complaints = MutableStateFlow<List<Complaint>>(initialComplaints)
    val complaints: StateFlow<List<Complaint>> = _complaints.asStateFlow()

    private val _faqs = MutableStateFlow<List<FaqItem>>(initialFaqs)
    val faqs: StateFlow<List<FaqItem>> = _faqs.asStateFlow()

    // Challenges State Flow
    private val _challenges = MutableStateFlow<List<Challenge>>(SampleChallenges.ALL)
    val challenges: StateFlow<List<Challenge>> = _challenges.asStateFlow()

    fun toggleJoinChallenge(challengeId: String) {
        val currentList = _challenges.value
        val updated = currentList.map { ch ->
            if (ch.id == challengeId) {
                val newJoined = !ch.isJoinedByMe
                val countDelta = if (newJoined) 1 else -1
                ch.copy(
                    isJoinedByMe = newJoined,
                    participantsCount = (ch.participantsCount + countDelta).coerceAtLeast(0)
                )
            } else ch
        }
        _challenges.value = updated
    }

    fun voteForChallengeParticipant(challengeId: String, workerId: String) {
        val currentList = _challenges.value
        val updated = currentList.map { ch ->
            if (ch.id == challengeId) {
                val updatedLeaderboard = ch.leaderboard.map { participant ->
                    if (participant.workerId == workerId) {
                        val newVoted = !participant.isVotedByMe
                        val voteDelta = if (newVoted) 1 else -1
                        participant.copy(
                            isVotedByMe = newVoted,
                            votesCount = (participant.votesCount + voteDelta).coerceAtLeast(0)
                        )
                    } else participant
                }.sortedByDescending { it.votesCount }.mapIndexed { index, p -> p.copy(rank = index + 1) }

                ch.copy(leaderboard = updatedLeaderboard)
            } else ch
        }
        _challenges.value = updated
    }

    fun submitChallengeWork(challengeId: String, submissionTitle: String, imageUrl: String? = null) {
        val user = _currentUser.value
        val currentList = _challenges.value
        val updated = currentList.map { ch ->
            if (ch.id == challengeId) {
                val newParticipant = ChallengeParticipant(
                    rank = ch.leaderboard.size + 1,
                    workerId = user.id,
                    workerName = user.name,
                    workerAvatarColor = user.avatarColorHex,
                    trade = user.trade.ifBlank { "Pro Artisan" },
                    submissionTitle = submissionTitle,
                    submissionImageUrl = imageUrl,
                    votesCount = 1,
                    isVotedByMe = true,
                    submissionDate = "Just now"
                )
                val newLeaderboard = (ch.leaderboard + newParticipant)
                    .sortedByDescending { it.votesCount }
                    .mapIndexed { index, p -> p.copy(rank = index + 1) }

                ch.copy(
                    isJoinedByMe = true,
                    participantsCount = if (ch.isJoinedByMe) ch.participantsCount else ch.participantsCount + 1,
                    submissionsCount = ch.submissionsCount + 1,
                    leaderboard = newLeaderboard
                )
            } else ch
        }
        _challenges.value = updated
    }

    init {
        repoScope.launch {
            seedInitialDataIfEmpty()
            listenToFirebaseIfAvailable()
        }
    }

    private suspend fun seedInitialDataIfEmpty() {
        withContext(Dispatchers.IO) {
            // Seed Room DB
            dao.insertServices(initialServices.map { it.toEntity() })
            dao.insertPosts(initialPosts.map { it.toEntity() })
            dao.insertOrders(initialOrders.map { it.toEntity() })
            dao.insertMessages(initialMessages.map { it.toEntity() })
            dao.insertReviews(initialReviews.map { it.toEntity() })
            dao.insertNotifications(initialNotifications.map { it.toEntity() })
        }
    }

    private fun listenToFirebaseIfAvailable() {
        if (!firebaseManager.isFirebaseAvailable) return
        repoScope.launch {
            try {
                // Listen to users
                launch {
                    firebaseManager.allUsersFlow.collect { firebaseUsers ->
                        if (firebaseUsers.isNotEmpty()) {
                            val merged = (firebaseUsers + initialUsers).distinctBy { it.id }
                            _allUsers.value = merged
                        }
                    }
                }
                // Listen to services
                launch {
                    firebaseManager.allServicesFlow.collect { firebaseServices ->
                        if (firebaseServices.isNotEmpty()) {
                            dao.insertServices(firebaseServices.map { it.toEntity() })
                        }
                    }
                }
                // Listen to posts
                launch {
                    firebaseManager.allPostsFlow.collect { firebasePosts ->
                        if (firebasePosts.isNotEmpty()) {
                            dao.insertPosts(firebasePosts.map { it.toEntity() })
                        }
                    }
                }
                // Listen to orders
                launch {
                    firebaseManager.allOrdersFlow.collect { firebaseOrders ->
                        if (firebaseOrders.isNotEmpty()) {
                            dao.insertOrders(firebaseOrders.map { it.toEntity() })
                        }
                    }
                }
                // Listen to reviews
                launch {
                    firebaseManager.allReviewsFlow.collect { firebaseReviews ->
                        if (firebaseReviews.isNotEmpty()) {
                            dao.insertReviews(firebaseReviews.map { it.toEntity() })
                        }
                    }
                }
                // Listen to Real-time Chat Messages
                launch {
                    firebaseManager.messagesFlow().collect { firebaseMsgs ->
                        if (firebaseMsgs.isNotEmpty()) {
                            dao.insertMessages(firebaseMsgs.map { it.toEntity() })
                        }
                    }
                }
                // Listen to Support Tickets
                launch {
                    firebaseManager.getSupportTicketsFlow().collect { fbTickets ->
                        if (fbTickets.isNotEmpty()) {
                            val merged = (fbTickets + _supportTickets.value).distinctBy { it.id }
                            _supportTickets.value = merged
                        }
                    }
                }
                // Listen to Complaints
                launch {
                    firebaseManager.getComplaintsFlow().collect { fbComplaints ->
                        if (fbComplaints.isNotEmpty()) {
                            val merged = (fbComplaints + _complaints.value).distinctBy { it.id }
                            _complaints.value = merged
                        }
                    }
                }
                // Listen to FAQs
                launch {
                    firebaseManager.getFaqsFlow().collect { fbFaqs ->
                        if (fbFaqs.isNotEmpty()) {
                            val merged = (fbFaqs + _faqs.value).distinctBy { it.id }
                            _faqs.value = merged
                        }
                    }
                }
                // Seed Firestore if empty
                firebaseManager.seedInitialFirestoreDataIfEmpty(
                    users = initialUsers,
                    services = initialServices,
                    posts = initialPosts,
                    orders = initialOrders,
                    reviews = initialReviews
                )
            } catch (e: Exception) {
                Log.w("SkillKartRepository", "Firebase sync listener note: ${e.message}")
            }
        }
    }

    // --- Firebase Auth Operations ---
    suspend fun signUpWithFirebase(
        name: String,
        email: String,
        password: String,
        role: UserRole,
        city: String,
        area: String,
        trade: String = ""
    ): Result<User> {
        val result = authRepository.signUp(
            name = name,
            email = email,
            password = password,
            role = role,
            city = city,
            area = area,
            trade = trade
        )
        if (result.isSuccess) {
            val user = result.getOrNull()
            if (user != null) {
                _currentUser.value = user
                _allUsers.value = listOf(user) + _allUsers.value.filter { it.id != user.id }
            }
        }
        return result
    }

    suspend fun signInWithFirebase(email: String, password: String): Result<User> {
        val result = authRepository.signIn(email, password)
        if (result.isSuccess) {
            val user = result.getOrNull()
            if (user != null) {
                _currentUser.value = user
                _allUsers.value = listOf(user) + _allUsers.value.filter { it.id != user.id }
            }
        }
        return result
    }

    fun signOut() {
        authRepository.signOut()
        _currentUser.value = initialUsers[0]
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        return authRepository.sendPasswordResetEmail(email)
    }

    // --- User & Auth ---
    fun switchUser(userId: String) {
        val found = _allUsers.value.find { it.id == userId }
        if (found != null) {
            _currentUser.value = found
        }
    }

    fun toggleRole() {
        val current = _currentUser.value
        val newRole = if (current.role == UserRole.CUSTOMER) UserRole.WORKER else UserRole.CUSTOMER
        val updated = current.copy(
            role = newRole,
            accountType = if (newRole == UserRole.WORKER) "worker" else "customer",
            trade = if (newRole == UserRole.WORKER && current.trade.isBlank()) "Skilled Professional" else current.trade
        )
        _currentUser.value = updated
        _allUsers.value = _allUsers.value.map { if (it.id == updated.id) updated else it }
        repoScope.launch {
            firebaseManager.updateUserProfile(
                uid = updated.id,
                name = updated.name,
                city = updated.city,
                area = updated.area,
                bio = updated.bio,
                trade = updated.trade,
                skills = updated.skills,
                accountType = updated.accountType
            )
        }
    }

    fun setUserIntent(role: UserRole) {
        val current = _currentUser.value
        val updated = current.copy(
            role = role,
            accountType = if (role == UserRole.WORKER) "worker" else "customer",
            trade = if (role == UserRole.WORKER && current.trade.isBlank()) "Skilled Professional" else current.trade
        )
        _currentUser.value = updated
        _allUsers.value = _allUsers.value.map { if (it.id == updated.id) updated else it }
        repoScope.launch {
            firebaseManager.updateUserProfile(
                uid = updated.id,
                name = updated.name,
                city = updated.city,
                area = updated.area,
                bio = updated.bio,
                trade = updated.trade,
                skills = updated.skills,
                accountType = updated.accountType
            )
        }
    }

    fun updateProfile(name: String, location: String, bio: String, trade: String, skills: List<String>) {
        val parts = location.split(",").map { it.trim() }
        val area = parts.firstOrNull() ?: _currentUser.value.area
        val city = if (parts.size > 1) parts.drop(1).joinToString(", ") else _currentUser.value.city
        val updated = _currentUser.value.copy(
            name = name,
            location = location,
            area = area,
            city = city,
            bio = bio,
            trade = trade,
            skills = skills
        )
        _currentUser.value = updated
        _allUsers.value = _allUsers.value.map { if (it.id == updated.id) updated else it }
        repoScope.launch {
            firebaseManager.updateUserProfile(
                uid = updated.id,
                name = name,
                city = city,
                area = area,
                bio = bio,
                trade = trade,
                skills = skills,
                accountType = updated.accountType
            )
        }
    }

    fun registerNewUser(name: String, email: String, phone: String, role: UserRole, trade: String, location: String) {
        val parts = location.split(",").map { it.trim() }
        val area = parts.firstOrNull() ?: "Connaught Place"
        val city = if (parts.size > 1) parts.drop(1).joinToString(", ") else "New Delhi"
        val newUser = User(
            id = "user_${System.currentTimeMillis()}",
            uid = "user_${System.currentTimeMillis()}",
            name = name,
            email = email,
            phone = phone,
            role = role,
            accountType = if (role == UserRole.WORKER) "worker" else "customer",
            trade = trade,
            city = city,
            area = area,
            location = location,
            bio = if (role == UserRole.WORKER) "Dedicated and skilled $trade with 5+ years of verified on-site experience." else "Valued client looking for trusted local workers.",
            skills = if (role == UserRole.WORKER) listOf(trade, "On-Time Service", "Guaranteed Work") else emptyList(),
            avatarColorHex = if (role == UserRole.WORKER) "#E65100" else "#1A237E"
        )
        _allUsers.value = _allUsers.value + newUser
        _currentUser.value = newUser
    }

    // --- Services ---
    val allServices: Flow<List<ServicePackage>> = dao.getAllServices().map { list ->
        list.map { it.toModel() }
    }

    suspend fun createServicePackage(
        title: String,
        category: String,
        priceInr: Int,
        completionTime: String,
        serviceRadius: String,
        maxVisits: String,
        description: String,
        inclusions: List<String>,
        images: List<String> = emptyList()
    ) {
        val user = _currentUser.value
        val service = ServicePackage(
            id = "srv_${System.currentTimeMillis()}",
            workerId = user.id,
            workerName = user.name,
            workerTrade = user.trade.ifBlank { category },
            workerRating = user.rating,
            workerLocation = user.location,
            title = title,
            category = category,
            priceInr = priceInr,
            completionTime = completionTime,
            serviceRadius = serviceRadius,
            maxVisits = maxVisits,
            description = description,
            inclusions = inclusions,
            images = images,
            isActive = true
        )
        dao.insertService(service.toEntity())
        firebaseManager.createService(service)
    }

    fun searchServicesFlow(
        category: String = "All",
        searchQuery: String = "",
        maxPrice: Int = 100000,
        minRating: Float = 0f
    ): Flow<List<ServicePackage>> {
        return firebaseManager.searchServicesFlow(category, searchQuery, maxPrice, minRating)
    }

    suspend fun searchServicesFromFirestore(
        category: String = "All",
        searchQuery: String = ""
    ): List<ServicePackage> {
        return firebaseManager.queryServicesFromFirestore(category, searchQuery)
    }

    // --- Posts & Social Feed ---
    val allPosts: Flow<List<Post>> = dao.getAllPosts().map { list ->
        list.map { it.toModel() }
    }

    suspend fun createPost(
        title: String,
        caption: String,
        type: PostType,
        tags: List<String>,
        linkedServiceId: String?,
        linkedServiceTitle: String?,
        linkedPriceInr: Int?,
        beforeDesc: String?,
        afterDesc: String?,
        imageUrl: String? = null
    ) {
        val user = _currentUser.value
        val post = Post(
            id = "post_${System.currentTimeMillis()}",
            workerId = user.id,
            workerName = user.name,
            workerTrade = user.trade.ifBlank { "Skilled Worker" },
            workerAvatarColor = user.avatarColorHex,
            workerLocation = user.location,
            workerRating = user.rating,
            type = type,
            title = title,
            caption = caption,
            imageUrl = imageUrl,
            tags = tags,
            linkedServiceId = linkedServiceId,
            linkedServiceTitle = linkedServiceTitle,
            linkedPriceInr = linkedPriceInr,
            beforeDescription = beforeDesc,
            afterDescription = afterDesc,
            likesCount = 1,
            isLikedByMe = true,
            commentsCount = 0,
            sharesCount = 0,
            isFollowedByMe = false,
            timestamp = "Just now"
        )
        dao.insertPost(post.toEntity())
        firebaseManager.createPost(post)
    }

    suspend fun toggleLikePost(post: Post) {
        val newLiked = !post.isLikedByMe
        val newCount = if (newLiked) post.likesCount + 1 else (post.likesCount - 1).coerceAtLeast(0)
        val updated = post.copy(isLikedByMe = newLiked, likesCount = newCount)
        dao.insertPost(updated.toEntity())

        firebaseManager.likePost(post.id, newCount)

        if (newLiked && post.workerId != _currentUser.value.id) {
            addNotification(
                userId = post.workerId,
                type = NotificationType.POST_LIKED,
                title = "New Like on your post",
                message = "${_currentUser.value.name} liked your showcase: \"${post.title}\"",
                relatedId = post.id
            )
        }
    }

    suspend fun toggleFollowWorker(workerId: String, currentFollowState: Boolean) {
        val updatedUsers = _allUsers.value.map { user ->
            if (user.id == workerId) {
                val newFollowers = if (!currentFollowState) user.followersCount + 1 else (user.followersCount - 1).coerceAtLeast(0)
                user.copy(followersCount = newFollowers)
            } else user
        }
        _allUsers.value = updatedUsers

        firebaseManager.toggleFollow(workerId, currentFollowState)

        if (!currentFollowState) {
            addNotification(
                userId = workerId,
                type = NotificationType.NEW_FOLLOWER,
                title = "New Follower",
                message = "${_currentUser.value.name} started following your work profile!",
                relatedId = _currentUser.value.id
            )
        }
    }

    fun addCommentToPost(postId: String, text: String) {
        val user = _currentUser.value
        val newComment = Comment(
            id = "cmt_${System.currentTimeMillis()}",
            postId = postId,
            userId = user.id,
            userName = user.name,
            userAvatarColor = user.avatarColorHex,
            text = text,
            timestamp = "Just now"
        )
        val map = _postComments.value.toMutableMap()
        val currentList = map[postId] ?: emptyList()
        map[postId] = currentList + newComment
        _postComments.value = map
        repoScope.launch {
            firebaseManager.addComment(newComment)
        }
    }

    // --- Orders / Booking ---
    val allOrders: Flow<List<Order>> = dao.getAllOrders().map { list ->
        list.map { it.toModel() }
    }

    suspend fun createOrder(
        service: ServicePackage,
        requirementDetails: String,
        address: String,
        date: String,
        timeSlot: String,
        instructions: String,
        imageUrl: String? = null
    ): Order {
        val user = _currentUser.value
        val order = Order(
            id = "SK-${(1000..9999).random()}",
            serviceId = service.id,
            serviceTitle = service.title,
            serviceCategory = service.category,
            customerId = user.id,
            customerName = user.name,
            customerPhone = user.phone,
            workerId = service.workerId,
            workerName = service.workerName,
            workerTrade = service.workerTrade,
            priceInr = service.priceInr,
            status = OrderStatus.PENDING,
            requirementDetails = requirementDetails,
            serviceAddress = address,
            preferredDate = date,
            timeSlot = timeSlot,
            instructions = instructions,
            imageUrl = imageUrl,
            createdAt = System.currentTimeMillis(),
            hasReview = false
        )
        dao.insertOrder(order.toEntity())
        firebaseManager.createOrder(order)

        // Notify worker
        addNotification(
            userId = service.workerId,
            type = NotificationType.BOOKING_NEW,
            title = "New Booking Request!",
            message = "${user.name} booked \"${service.title}\" for ₹${service.priceInr}.",
            relatedId = order.id
        )

        // Send initial auto-confirmation message in Chat
        sendChatMessage(
            conversationId = getConversationId(user.id, service.workerId),
            senderId = user.id,
            senderName = user.name,
            receiverId = service.workerId,
            text = "Hello ${service.workerName}! I have requested a booking for \"${service.title}\" (Order #${order.id}) on $date ($timeSlot). Address: $address.",
            orderIdRef = order.id
        )

        return order
    }

    suspend fun updateOrderStatus(order: Order, newStatus: OrderStatus) {
        val updated = order.copy(status = newStatus)
        dao.insertOrder(updated.toEntity())
        firebaseManager.updateOrderStatus(order.id, newStatus)

        val user = _currentUser.value
        val isWorkerActing = user.id == order.workerId

        val notifUserId = if (isWorkerActing) order.customerId else order.workerId
        val notifType = when (newStatus) {
            OrderStatus.ACCEPTED -> NotificationType.BOOKING_ACCEPTED
            OrderStatus.CANCELLED -> NotificationType.BOOKING_REJECTED
            OrderStatus.COMPLETED -> NotificationType.ORDER_COMPLETED
            else -> NotificationType.BOOKING_ACCEPTED
        }

        val messageText = when (newStatus) {
            OrderStatus.ACCEPTED -> "Your booking #${order.id} for \"${order.serviceTitle}\" was accepted by ${order.workerName}!"
            OrderStatus.IN_PROGRESS -> "${order.workerName} has started working on order #${order.id}."
            OrderStatus.COMPLETED -> "Order #${order.id} marked as completed! Please leave a review for ${order.workerName}."
            OrderStatus.CANCELLED -> "Order #${order.id} was cancelled."
            OrderStatus.PENDING -> "Order #${order.id} updated."
        }

        addNotification(
            userId = notifUserId,
            type = notifType,
            title = "Order ${newStatus.displayName}: #${order.id}",
            message = messageText,
            relatedId = order.id
        )

        // Also post in chat
        sendChatMessage(
            conversationId = getConversationId(order.customerId, order.workerId),
            senderId = user.id,
            senderName = user.name,
            receiverId = notifUserId,
            text = "Status update for Order #${order.id}: **${newStatus.displayName} (${newStatus.hindiName})**",
            orderIdRef = order.id
        )
    }

    // --- Chat Messages ---
    val allMessages: Flow<List<ChatMessage>> = dao.getAllMessages().map { list ->
        list.map { it.toModel() }
    }

    suspend fun sendChatMessage(
        conversationId: String,
        senderId: String,
        senderName: String,
        receiverId: String,
        text: String,
        imageUrl: String? = null,
        orderIdRef: String? = null
    ) {
        val now = System.currentTimeMillis()
        val timeString = java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(now))
        val message = ChatMessage(
            id = "msg_${System.currentTimeMillis()}_${(100..999).random()}",
            conversationId = conversationId,
            senderId = senderId,
            senderName = senderName,
            receiverId = receiverId,
            text = text,
            imageUrl = imageUrl,
            orderIdRef = orderIdRef,
            timestamp = now,
            formattedTime = timeString,
            isRead = true
        )
        dao.insertMessage(message.toEntity())
        firebaseManager.sendMessage(message)
    }

    fun getConversationId(userA: String, userB: String): String {
        return if (userA < userB) "${userA}_$userB" else "${userB}_$userA"
    }

    // --- Reviews ---
    val allReviews: Flow<List<Review>> = dao.getAllReviews().map { list ->
        list.map { it.toModel() }
    }

    suspend fun submitReview(
        order: Order,
        rating: Int,
        comment: String,
        tags: List<String>,
        imageUrl: String? = null
    ) {
        val user = _currentUser.value
        val review = Review(
            id = "rev_${System.currentTimeMillis()}",
            workerId = order.workerId,
            customerId = user.id,
            customerName = user.name,
            serviceId = order.serviceId,
            serviceTitle = order.serviceTitle,
            orderId = order.id,
            rating = rating,
            comment = comment,
            tags = tags,
            imageUrl = imageUrl,
            date = "Today"
        )
        dao.insertReview(review.toEntity())
        firebaseManager.submitReview(review)

        // Mark order as reviewed
        val updatedOrder = order.copy(hasReview = true)
        dao.insertOrder(updatedOrder.toEntity())
        firebaseManager.updateOrder(updatedOrder)

        // Notify worker
        addNotification(
            userId = order.workerId,
            type = NotificationType.REVIEW_RECEIVED,
            title = "⭐ New $rating-Star Review!",
            message = "${user.name} reviewed \"${order.serviceTitle}\": \"$comment\"",
            relatedId = order.id
        )

        // Update worker rating in memory & Firestore
        val worker = _allUsers.value.find { it.id == order.workerId }
        if (worker != null) {
            val newReviewCount = worker.reviewCount + 1
            val newRating = ((worker.rating * worker.reviewCount) + rating) / newReviewCount
            val updatedWorker = worker.copy(
                rating = ((newRating * 10).toInt() / 10.0f).coerceIn(1.0f, 5.0f),
                reviewCount = newReviewCount,
                completedJobs = worker.completedJobs + 1
            )
            _allUsers.value = _allUsers.value.map { if (it.id == updatedWorker.id) updatedWorker else it }
            firebaseManager.updateWorkerRating(order.workerId, updatedWorker.rating, newReviewCount, updatedWorker.completedJobs)
        }
    }

    // --- Notifications ---
    val allNotifications: Flow<List<NotificationItem>> = dao.getAllNotifications().map { list ->
        list.map { it.toModel() }
    }

    suspend fun addNotification(
        userId: String,
        type: NotificationType,
        title: String,
        message: String,
        relatedId: String? = null
    ) {
        val notif = NotificationItem(
            id = "notif_${System.currentTimeMillis()}_${(100..999).random()}",
            userId = userId,
            type = type,
            title = title,
            message = message,
            relatedId = relatedId,
            timestamp = "Just now",
            isRead = false
        )
        dao.insertNotification(notif.toEntity())
        firebaseManager.addNotification(notif)
    }

    // --- Entity Mappers with Named Arguments ---
    private fun ServicePackage.toEntity() = ServicePackageEntity(
        id = id,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        workerRating = workerRating,
        workerLocation = workerLocation,
        title = title,
        category = category,
        priceInr = priceInr,
        completionTime = completionTime,
        serviceRadius = serviceRadius,
        maxVisits = maxVisits,
        description = description,
        inclusions = inclusions,
        isActive = isActive,
        createdAt = createdAt
    )

    private fun ServicePackageEntity.toModel() = ServicePackage(
        id = id,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        workerRating = workerRating,
        workerLocation = workerLocation,
        title = title,
        category = category,
        priceInr = priceInr,
        completionTime = completionTime,
        serviceRadius = serviceRadius,
        maxVisits = maxVisits,
        description = description,
        inclusions = inclusions,
        isActive = isActive,
        createdAt = createdAt
    )

    private fun Post.toEntity() = PostEntity(
        id = id,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        workerAvatarColor = workerAvatarColor,
        workerLocation = workerLocation,
        workerRating = workerRating,
        type = type.name,
        title = title,
        caption = caption,
        tags = tags,
        linkedServiceId = linkedServiceId,
        linkedServiceTitle = linkedServiceTitle,
        linkedPriceInr = linkedPriceInr,
        beforeDescription = beforeDescription,
        afterDescription = afterDescription,
        likesCount = likesCount,
        isLikedByMe = isLikedByMe,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isFollowedByMe = isFollowedByMe,
        timestamp = timestamp
    )

    private fun PostEntity.toModel() = Post(
        id = id,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        workerAvatarColor = workerAvatarColor,
        workerLocation = workerLocation,
        workerRating = workerRating,
        type = runCatching { PostType.valueOf(type) }.getOrDefault(PostType.WORK_SHOWCASE),
        title = title,
        caption = caption,
        tags = tags,
        linkedServiceId = linkedServiceId,
        linkedServiceTitle = linkedServiceTitle,
        linkedPriceInr = linkedPriceInr,
        beforeDescription = beforeDescription,
        afterDescription = afterDescription,
        likesCount = likesCount,
        isLikedByMe = isLikedByMe,
        commentsCount = commentsCount,
        sharesCount = sharesCount,
        isFollowedByMe = isFollowedByMe,
        timestamp = timestamp
    )

    private fun Order.toEntity() = OrderEntity(
        id = id,
        serviceId = serviceId,
        serviceTitle = serviceTitle,
        serviceCategory = serviceCategory,
        customerId = customerId,
        customerName = customerName,
        customerPhone = customerPhone,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        priceInr = priceInr,
        status = status.name,
        requirementDetails = requirementDetails,
        serviceAddress = serviceAddress,
        preferredDate = preferredDate,
        timeSlot = timeSlot,
        instructions = instructions,
        createdAt = createdAt,
        hasReview = hasReview
    )

    private fun OrderEntity.toModel() = Order(
        id = id,
        serviceId = serviceId,
        serviceTitle = serviceTitle,
        serviceCategory = serviceCategory,
        customerId = customerId,
        customerName = customerName,
        customerPhone = customerPhone,
        workerId = workerId,
        workerName = workerName,
        workerTrade = workerTrade,
        priceInr = priceInr,
        status = runCatching { OrderStatus.valueOf(status) }.getOrDefault(OrderStatus.PENDING),
        requirementDetails = requirementDetails,
        serviceAddress = serviceAddress,
        preferredDate = preferredDate,
        timeSlot = timeSlot,
        instructions = instructions,
        createdAt = createdAt,
        hasReview = hasReview
    )

    private fun ChatMessage.toEntity() = ChatMessageEntity(
        id = id,
        conversationId = conversationId,
        senderId = senderId,
        senderName = senderName,
        receiverId = receiverId,
        text = text,
        imageUrl = imageUrl,
        orderIdRef = orderIdRef,
        timestamp = timestamp,
        formattedTime = formattedTime,
        isRead = isRead
    )

    private fun ChatMessageEntity.toModel() = ChatMessage(
        id = id,
        conversationId = conversationId,
        senderId = senderId,
        senderName = senderName,
        receiverId = receiverId,
        text = text,
        imageUrl = imageUrl,
        orderIdRef = orderIdRef,
        timestamp = timestamp,
        formattedTime = formattedTime,
        isRead = isRead
    )

    private fun Review.toEntity() = ReviewEntity(
        id = id,
        workerId = workerId,
        customerId = customerId,
        customerName = customerName,
        serviceTitle = serviceTitle,
        rating = rating,
        comment = comment,
        tags = tags,
        date = date
    )

    private fun ReviewEntity.toModel() = Review(
        id = id,
        workerId = workerId,
        customerId = customerId,
        customerName = customerName,
        serviceId = "",
        serviceTitle = serviceTitle,
        orderId = "",
        rating = rating,
        comment = comment,
        tags = tags,
        imageUrl = null,
        date = date
    )

    // -------------------------------------------------------------
    // SUPPORT TICKETS, IN-APP CHAT & COMPLAINTS
    // -------------------------------------------------------------

    fun createSupportTicket(
        subject: String,
        category: String,
        initialMessage: String,
        orderId: String? = null,
        orderTitle: String? = null,
        imageUrl: String? = null
    ): SupportTicket {
        val user = _currentUser.value
        val ticketId = "TKT-${(1000..9999).random()}"
        val now = System.currentTimeMillis()
        val ticket = SupportTicket(
            id = ticketId,
            ticketId = ticketId,
            userId = user.id,
            userName = user.name,
            userEmail = user.email,
            userRole = if (user.role == UserRole.WORKER) "worker" else "customer",
            subject = subject.ifBlank { "Support Request - $category" },
            category = category,
            status = TicketStatus.OPEN,
            priority = TicketPriority.MEDIUM,
            relatedOrderId = orderId,
            relatedOrderTitle = orderTitle,
            createdAt = now,
            updatedAt = now,
            lastMessage = initialMessage.ifBlank { "Ticket opened" },
            unreadUserCount = 0,
            unreadAdminCount = 1
        )

        val firstMsg = SupportMessage(
            id = "msg_${System.currentTimeMillis()}",
            ticketId = ticketId,
            senderId = user.id,
            senderName = user.name,
            senderRole = if (user.role == UserRole.WORKER) "worker" else "user",
            message = initialMessage.ifBlank { "Hello, I need assistance with my $category." },
            imageUrl = imageUrl,
            createdAt = now,
            read = false,
            formattedTime = "Just now"
        )

        val currentTickets = _supportTickets.value
        _supportTickets.value = listOf(ticket) + currentTickets

        val currentMsgs = _supportMessages.value.toMutableMap()
        currentMsgs[ticketId] = listOf(firstMsg)
        _supportMessages.value = currentMsgs

        repoScope.launch {
            firebaseManager.createSupportTicket(ticket)
            firebaseManager.sendSupportMessage(firstMsg)
        }

        return ticket
    }

    fun sendSupportMessage(
        ticketId: String,
        text: String,
        imageUrl: String? = null,
        isFromAdmin: Boolean = false
    ): SupportMessage {
        val user = _currentUser.value
        val now = System.currentTimeMillis()
        val senderRole = if (isFromAdmin || user.role == UserRole.ADMIN) "admin" else if (user.role == UserRole.WORKER) "worker" else "user"
        val senderName = if (isFromAdmin || user.role == UserRole.ADMIN) "SkillKart Support" else user.name

        val newMsg = SupportMessage(
            id = "msg_${System.currentTimeMillis()}_${(100..999).random()}",
            ticketId = ticketId,
            senderId = if (isFromAdmin || user.role == UserRole.ADMIN) "support_agent" else user.id,
            senderName = senderName,
            senderRole = senderRole,
            message = text.trim(),
            imageUrl = imageUrl,
            createdAt = now,
            read = false,
            formattedTime = "Just now"
        )

        // Update in-memory messages
        val currentMsgs = _supportMessages.value.toMutableMap()
        val list = currentMsgs[ticketId]?.toMutableList() ?: mutableListOf()
        list.add(newMsg)
        currentMsgs[ticketId] = list
        _supportMessages.value = currentMsgs

        // Update ticket in-memory
        val currentTickets = _supportTickets.value.toMutableList()
        val index = currentTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val old = currentTickets[index]
            val updatedStatus = if (isFromAdmin || user.role == UserRole.ADMIN) {
                if (old.status == TicketStatus.OPEN || old.status == TicketStatus.WAITING_FOR_SUPPORT) TicketStatus.WAITING_FOR_USER else old.status
            } else {
                if (old.status == TicketStatus.CLOSED || old.status == TicketStatus.RESOLVED) TicketStatus.OPEN else TicketStatus.WAITING_FOR_SUPPORT
            }

            val updatedTicket = old.copy(
                lastMessage = text.ifBlank { if (imageUrl != null) "📷 Photo attached" else "" },
                updatedAt = now,
                status = updatedStatus,
                unreadUserCount = if (isFromAdmin || user.role == UserRole.ADMIN) old.unreadUserCount + 1 else old.unreadUserCount,
                unreadAdminCount = if (!isFromAdmin && user.role != UserRole.ADMIN) old.unreadAdminCount + 1 else old.unreadAdminCount
            )
            currentTickets[index] = updatedTicket
            _supportTickets.value = currentTickets

            // If reply from Admin, notify user
            if (isFromAdmin || user.role == UserRole.ADMIN) {
                repoScope.launch {
                    addNotification(
                        userId = old.userId,
                        type = NotificationType.SUPPORT_REPLY,
                        title = "Support Reply on #${old.ticketId}",
                        message = text.take(80),
                        relatedId = ticketId
                    )
                }
            }
        }

        repoScope.launch {
            firebaseManager.sendSupportMessage(newMsg)
        }

        return newMsg
    }

    fun updateTicketStatus(ticketId: String, newStatus: TicketStatus) {
        val currentTickets = _supportTickets.value.toMutableList()
        val index = currentTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val old = currentTickets[index]
            val updated = old.copy(status = newStatus, updatedAt = System.currentTimeMillis())
            currentTickets[index] = updated
            _supportTickets.value = currentTickets

            repoScope.launch {
                firebaseManager.updateSupportTicket(ticketId, mapOf("status" to newStatus.name, "updatedAt" to updated.updatedAt))
                // Send notification to user about status change
                addNotification(
                    userId = old.userId,
                    type = NotificationType.COMPLAINT_STATUS_CHANGED,
                    title = "Ticket #${old.ticketId} Status: ${newStatus.displayName}",
                    message = "Your support ticket status has been updated to '${newStatus.displayName}'.",
                    relatedId = ticketId
                )
            }
        }
    }

    fun updateTicketPriority(ticketId: String, newPriority: TicketPriority) {
        val currentTickets = _supportTickets.value.toMutableList()
        val index = currentTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val old = currentTickets[index]
            val updated = old.copy(priority = newPriority, updatedAt = System.currentTimeMillis())
            currentTickets[index] = updated
            _supportTickets.value = currentTickets

            repoScope.launch {
                firebaseManager.updateSupportTicket(ticketId, mapOf("priority" to newPriority.name, "updatedAt" to updated.updatedAt))
            }
        }
    }

    fun updateTicketInternalNotes(ticketId: String, notes: String) {
        val currentTickets = _supportTickets.value.toMutableList()
        val index = currentTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val old = currentTickets[index]
            val updated = old.copy(internalNotes = notes, updatedAt = System.currentTimeMillis())
            currentTickets[index] = updated
            _supportTickets.value = currentTickets

            repoScope.launch {
                firebaseManager.updateSupportTicket(ticketId, mapOf("internalNotes" to notes, "updatedAt" to updated.updatedAt))
            }
        }
    }

    fun markTicketRead(ticketId: String, forUser: Boolean) {
        val currentTickets = _supportTickets.value.toMutableList()
        val index = currentTickets.indexOfFirst { it.id == ticketId }
        if (index != -1) {
            val old = currentTickets[index]
            val updated = if (forUser) old.copy(unreadUserCount = 0) else old.copy(unreadAdminCount = 0)
            currentTickets[index] = updated
            _supportTickets.value = currentTickets

            repoScope.launch {
                firebaseManager.markSupportMessagesRead(ticketId, forUser)
            }
        }
    }

    fun closeTicket(ticketId: String) {
        updateTicketStatus(ticketId, TicketStatus.CLOSED)
    }

    fun reopenTicket(ticketId: String) {
        updateTicketStatus(ticketId, TicketStatus.OPEN)
    }

    fun createComplaint(
        category: String,
        details: String,
        orderId: String? = null,
        orderTitle: String? = null,
        evidenceImageUrl: String? = null
    ): Pair<Complaint, SupportTicket> {
        val user = _currentUser.value
        val complaintId = "CMP-${(10000..99999).random()}"
        val now = System.currentTimeMillis()

        // 1. Automatically create a linked Support Ticket so the user can discuss with support team!
        val subject = "Complaint #$complaintId - $category" + (if (orderTitle != null) " ($orderTitle)" else "")
        val initialMsgText = "🚨 Complaint Details:\nCategory: $category\n${if (orderId != null) "Order ID: $orderId ($orderTitle)\n" else ""}Details: $details"
        val ticket = createSupportTicket(
            subject = subject,
            category = category,
            initialMessage = initialMsgText,
            orderId = orderId,
            orderTitle = orderTitle,
            imageUrl = evidenceImageUrl
        )

        // 2. Create Complaint record
        val complaint = Complaint(
            id = complaintId,
            complaintId = complaintId,
            ticketId = ticket.id,
            userId = user.id,
            userName = user.name,
            category = category,
            orderId = orderId,
            orderTitle = orderTitle,
            details = details,
            evidenceImageUrl = evidenceImageUrl,
            status = "Under Investigation",
            createdAt = now
        )

        val currentComplaints = _complaints.value
        _complaints.value = listOf(complaint) + currentComplaints

        repoScope.launch {
            firebaseManager.createComplaint(complaint)
            // Notification for complaint registration
            addNotification(
                userId = user.id,
                type = NotificationType.COMPLAINT_STATUS_CHANGED,
                title = "Complaint Registered ($complaintId)",
                message = "Your issue is registered under Support Ticket #${ticket.ticketId}. Our team is investigating.",
                relatedId = ticket.id
            )
        }

        return Pair(complaint, ticket)
    }

    fun saveFaq(faq: FaqItem) {
        val current = _faqs.value.toMutableList()
        val index = current.indexOfFirst { it.id == faq.id }
        if (index != -1) {
            current[index] = faq
        } else {
            val id = if (faq.id.isNotBlank()) faq.id else "faq_${System.currentTimeMillis()}"
            current.add(faq.copy(id = id))
        }
        _faqs.value = current
        repoScope.launch {
            firebaseManager.saveFaqItem(faq)
        }
    }

    fun deleteFaq(faqId: String) {
        _faqs.value = _faqs.value.filter { it.id != faqId }
        repoScope.launch {
            firebaseManager.deleteFaqItem(faqId)
        }
    }

    private fun NotificationItem.toEntity() = NotificationEntity(
        id = id,
        userId = userId,
        type = type.name,
        title = title,
        message = message,
        relatedId = relatedId,
        timestamp = timestamp,
        isRead = isRead
    )

    private fun NotificationEntity.toModel() = NotificationItem(
        id = id,
        userId = userId,
        type = runCatching { NotificationType.valueOf(type) }.getOrDefault(NotificationType.BOOKING_NEW),
        title = title,
        message = message,
        relatedId = relatedId,
        timestamp = timestamp,
        isRead = isRead
    )

    companion object {
        @Volatile
        private var INSTANCE: SkillKartRepository? = null

        fun getInstance(context: Context): SkillKartRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SkillKartRepository(context).also { INSTANCE = it }
            }
        }

        // Preloaded Rich Datasets for India-focused Skilled Workers
        val initialUsers = listOf(
            User(
                id = "usr_rahul",
                name = "Rahul Gond",
                email = "rahul.gond@example.com",
                phone = "+91 98765 43210",
                role = UserRole.CUSTOMER,
                location = "Laxmi Nagar, New Delhi",
                bio = "Looking for verified local craftsmen and skilled technicians for home renovation.",
                avatarColorHex = "#1A237E"
            ),
            User(
                id = "usr_admin",
                name = "SkillKart Admin & Support Head",
                email = "admin@skillkart.in",
                phone = "",
                role = UserRole.ADMIN,
                accountType = "admin",
                location = "SkillKart HQ, New Delhi",
                bio = "SkillKart Official Central Support & Operations Team.",
                avatarColorHex = "#D32F2F",
                isVerified = true
            ),
            User(
                id = "usr_ramesh",
                name = "Ramesh Sharma",
                email = "ramesh.welder@skillkart.in",
                phone = "+91 98112 34567",
                role = UserRole.WORKER,
                trade = "Master Welder & Fabricator",
                location = "Mayur Vihar, New Delhi",
                bio = "12+ years of expertise in heavy MS Gate, Stainless Steel railing, grill fabrication, and laser-guided argon welding.",
                skills = listOf("MS Gate Welding", "SS Railing", "Argon Arc Welding", "Custom Grill Work", "Structural Fabrication"),
                rating = 4.9f,
                reviewCount = 58,
                completedJobs = 142,
                followersCount = 840,
                avatarColorHex = "#E65100",
                isVerified = true
            ),
            User(
                id = "usr_suresh",
                name = "Suresh Kumar",
                email = "suresh.electric@skillkart.in",
                phone = "+91 98450 12345",
                role = UserRole.WORKER,
                trade = "Licensed Senior Electrician",
                location = "Indiranagar, Bengaluru",
                bio = "Govt. certified electrical technician specializing in short circuit diagnosis, smart home wiring, and 3-phase MCB installations.",
                skills = listOf("House Wiring", "3-Phase MCB", "Inverter Setup", "Smart Lighting", "Earthing Check"),
                rating = 4.8f,
                reviewCount = 42,
                completedJobs = 98,
                followersCount = 610,
                avatarColorHex = "#0288D1",
                isVerified = true
            ),
            User(
                id = "usr_priya",
                name = "Priya Patel",
                email = "priya.design@skillkart.in",
                phone = "+91 98200 54321",
                role = UserRole.WORKER,
                trade = "Brand & Graphic Designer",
                location = "Andheri West, Mumbai",
                bio = "Helping Indian MSMEs, D2C brands, and local stores with iconic brand logos, social media creative kits, and visiting card packages.",
                skills = listOf("Logo Design", "Packaging Design", "Social Media Kits", "Vector Art", "Brochure Layout"),
                rating = 5.0f,
                reviewCount = 89,
                completedJobs = 210,
                followersCount = 1420,
                avatarColorHex = "#7B1FA2",
                isVerified = true
            ),
            User(
                id = "usr_vikram",
                name = "Vikram Singh",
                email = "vikram.carpentry@skillkart.in",
                phone = "+91 99700 88990",
                role = UserRole.WORKER,
                trade = "Master Carpenter & Modular Woodcraft",
                location = "Kothrud, Pune",
                bio = "Specialist in customized hydraulic beds, modular kitchen cabinets, hardwood doors, and antique furniture restoration.",
                skills = listOf("Modular Kitchen", "Hydraulic Bed", "Wood Polishing", "Door Lock Fitting", "Plywood Wardrobe"),
                rating = 4.9f,
                reviewCount = 37,
                completedJobs = 112,
                followersCount = 490,
                avatarColorHex = "#5D4037",
                isVerified = true
            ),
            User(
                id = "usr_anita",
                name = "Anita Devi",
                email = "anita.beauty@skillkart.in",
                phone = "+91 97110 33445",
                role = UserRole.WORKER,
                trade = "Bridal & Hair Styling Artist",
                location = "South Extension, New Delhi",
                bio = "Certified cosmetologist offering doorstep bridal styling, organic facial therapies, HD party makeup, and hair spa treatments.",
                skills = listOf("HD Party Makeup", "Bridal Mehendi", "Organic Facial", "Keratin Hair Spa", "Threading & Waxing"),
                rating = 4.9f,
                reviewCount = 76,
                completedJobs = 175,
                followersCount = 1180,
                avatarColorHex = "#C2185B",
                isVerified = true
            ),
            User(
                id = "usr_amit",
                name = "Amit Verma",
                email = "amit.acservice@skillkart.in",
                phone = "+91 99100 22334",
                role = UserRole.WORKER,
                trade = "AC & Inverter HVAC Technician",
                location = "Sector 62, Noida",
                bio = "Split & Window AC high-pressure water jet cleaning, PCB troubleshooting, R32/R410 gas refilling with 90-day cooling warranty.",
                skills = listOf("Jet AC Service", "Gas Refilling", "PCB Repair", "Compressor Check", "AC Installation"),
                rating = 4.8f,
                reviewCount = 64,
                completedJobs = 160,
                followersCount = 730,
                avatarColorHex = "#00796B",
                isVerified = true
            )
        )

        val initialServices = listOf(
            ServicePackage(
                id = "srv_welding_1",
                workerId = "usr_ramesh",
                workerName = "Ramesh Sharma",
                workerTrade = "Master Welder & Fabricator",
                workerRating = 4.9f,
                workerLocation = "Delhi NCR (East Delhi)",
                title = "MS Gate & Main Entrance Grill Welding Repair",
                category = "Welding",
                priceInr = 1500,
                completionTime = "1-2 Days",
                serviceRadius = "Within 12 km",
                maxVisits = "2 on-site visits included",
                description = "Complete heavy-duty welding repair for main gates, balcony railings, broken hinges, and customized bracket reinforcements. High precision arc & argon welding with grinding finish.",
                inclusions = listOf(
                    "On-site mobile welding unit inspection",
                    "Heavy-gauge MS rod welding & structural alignment",
                    "Smooth grinding of joints & burr removal",
                    "Anti-rust Red Oxide primer base coating",
                    "1 Month free workmanship warranty"
                )
            ),
            ServicePackage(
                id = "srv_electric_1",
                workerId = "usr_suresh",
                workerName = "Suresh Kumar",
                workerTrade = "Licensed Senior Electrician",
                workerRating = 4.8f,
                workerLocation = "Bengaluru (East & Central)",
                title = "Complete 2BHK/3BHK Electrical Health & MCB Tripping Fix",
                category = "Electrician",
                priceInr = 899,
                completionTime = "Same Day (3-4 hrs)",
                serviceRadius = "Within 15 km",
                maxVisits = "Single comprehensive visit",
                description = "Comprehensive electrical inspection: identification of neutral leakages, fixing sudden MCB tripping, replacement of faulty switches, and safe heavy-appliance load distribution.",
                inclusions = listOf(
                    "Digital multimeter voltage & earthing check",
                    "Distribution board & MCB fuse testing",
                    "Up to 4 switchboard / socket repairs",
                    "Load balancing for AC and geysers",
                    "Safety compliance report"
                )
            ),
            ServicePackage(
                id = "srv_design_1",
                workerId = "usr_priya",
                workerName = "Priya Patel",
                workerTrade = "Brand & Graphic Designer",
                workerRating = 5.0f,
                workerLocation = "All India (Remote Online)",
                title = "Complete Brand Identity Kit + Vector Logo + Social Kit",
                category = "Graphic Designer",
                priceInr = 1999,
                completionTime = "2 Days",
                serviceRadius = "Online / Pan India",
                maxVisits = "3 Revision rounds",
                description = "Craft a standout, memorable brand identity for your business, shop, or startup. Includes 3 custom concepts, high-res vector source files (AI, SVG, PDF), brand color palette, and social media branding kit.",
                inclusions = listOf(
                    "3 Unique custom logo concepts",
                    "Vector source files (SVG, PDF, PNG with transparency)",
                    "Print-ready Visiting Card & Letterhead layout",
                    "Social Media business profile asset pack",
                    "Full commercial copyright transfer"
                )
            ),
            ServicePackage(
                id = "srv_carpenter_1",
                workerId = "usr_vikram",
                workerName = "Vikram Singh",
                workerTrade = "Master Carpenter & Modular Woodcraft",
                workerRating = 4.9f,
                workerLocation = "Pune (Kothrud & Baner)",
                title = "Hydraulic Bed Mechanism Repair & Plywood Wardrobe Hinge Fix",
                category = "Carpenter",
                priceInr = 1200,
                completionTime = "Same Day (4 hrs)",
                serviceRadius = "Within 10 km",
                maxVisits = "1 visit with precision tools",
                description = "Fix heavy hydraulic bed lifting issues, noisy hinges, sliding wardrobe channel misalignment, and sagging drawer tracks. Heavy-duty hardware alignment included.",
                inclusions = listOf(
                    "Hydraulic pump pressure test & adjustment",
                    "Soft-close telescopic channel realignment",
                    "Plywood door leveling and screw tightening",
                    "Lubrication of all sliding tracks & roller wheels"
                )
            ),
            ServicePackage(
                id = "srv_beauty_1",
                workerId = "usr_anita",
                workerName = "Anita Devi",
                workerTrade = "Bridal & Hair Styling Artist",
                workerRating = 4.9f,
                workerLocation = "New Delhi (South & Central)",
                title = "Doorstep HD Festive Glow Facial & Hair Spa Package",
                category = "Beauty Services",
                priceInr = 2499,
                completionTime = "Same Day (2.5 hrs)",
                serviceRadius = "Within 10 km",
                maxVisits = "Doorstep session",
                description = "Relaxing 7-step organic radiant facial tailored to Indian skin, followed by a deeply nourishing Moroccan Argan oil hair spa with ozone steam and neck pressure massage.",
                inclusions = listOf(
                    "Deep pore cleansing & gentle fruit exfoliation",
                    "Gold-infused hydrating mask & vacuum blackhead suction",
                    "Argan oil scalp massage & therapeutic hot steam",
                    "Complimentary eyebrow threading & upper lip shaping"
                )
            ),
            ServicePackage(
                id = "srv_ac_1",
                workerId = "usr_amit",
                workerName = "Amit Verma",
                workerTrade = "AC & Inverter HVAC Technician",
                workerRating = 4.8f,
                workerLocation = "Noida & Greater Noida",
                title = "High-Pressure Jet Pump AC Deep Clean + Gas Pressure Check",
                category = "AC Repair",
                priceInr = 599,
                completionTime = "Same Day (1.5 hrs)",
                serviceRadius = "Within 12 km",
                maxVisits = "1 Full service visit",
                description = "Advanced 360-degree foam and high-pressure jet wash for indoor cooling coils, outdoor unit condenser, blower fan, and drain pipe unclogging to eliminate foul odor and boost cooling efficiency.",
                inclusions = listOf(
                    "Indoor unit jet wash with waterproof bag jacket",
                    "Condenser coil deep grime wash",
                    "Digital air flow and cooling temperature test",
                    "Compressor current draw & gas pressure check",
                    "30-day no water leakage guarantee"
                )
            ),
            ServicePackage(
                id = "srv_plumber_1",
                workerId = "usr_ramesh",
                workerName = "Rajesh Yadav",
                workerTrade = "Plumber & Pipe Fitting Expert",
                workerRating = 4.7f,
                workerLocation = "Gurugram, Haryana",
                title = "Bathroom Concealed Pipe Leakage Detection & Diverter Repair",
                category = "Plumber",
                priceInr = 699,
                completionTime = "Same Day (2 hrs)",
                serviceRadius = "Within 10 km",
                maxVisits = "1 visit",
                description = "Precision inspection of water seepage, concealed diverter valve repairs, jet spray replacement, and pipe joint sealing without unnecessary wall breakage.",
                inclusions = listOf(
                    "Acoustic water leak detection",
                    "Internal ceramic cartridge replacement/tuning",
                    "Teflon tape & high-pressure seal application",
                    "Tap flow aeration & drain blockage clearing"
                )
            )
        )

        val initialPosts = listOf(
            Post(
                id = "post_1",
                workerId = "usr_ramesh",
                workerName = "Ramesh Sharma",
                workerTrade = "Master Welder & Fabricator",
                workerAvatarColor = "#E65100",
                workerLocation = "East Delhi",
                workerRating = 4.9f,
                type = PostType.BEFORE_AFTER,
                title = "Restored 15-Year-Old Heavy Iron Gate in Preet Vihar 🚪⚡",
                caption = "Client thought they had to spend ₹45,000 on a brand new gate. We came in, ground out all deep rust, reinforced the load-bearing pivots with 12mm hardened steel pins, and arc-welded custom ornamental spearheads. Finished with matte black zinc anti-corrosion primer!",
                tags = listOf("#WeldingCraft", "DelhiWelder", "#IronGateRestoration", "#SkillKartPro"),
                linkedServiceId = "srv_welding_1",
                linkedServiceTitle = "MS Gate & Main Entrance Grill Welding Repair",
                linkedPriceInr = 1500,
                beforeDescription = "Broken lower hinge, 40% rusted bottom frame dragging on the ground",
                afterDescription = "Laser-aligned hinge, newly welded reinforced 3mm MS bar, smooth 1-finger swing",
                likesCount = 84,
                isLikedByMe = false,
                commentsCount = 12,
                sharesCount = 6,
                isFollowedByMe = false,
                timestamp = "3 hours ago"
            ),
            Post(
                id = "post_2",
                workerId = "usr_priya",
                workerName = "Priya Patel",
                workerTrade = "Brand & Graphic Designer",
                workerAvatarColor = "#7B1FA2",
                workerLocation = "Mumbai (Online)",
                workerRating = 5.0f,
                type = PostType.WORK_SHOWCASE,
                title = "Modern Chai Brand Identity: 'Desi Kadak' ☕🎨",
                caption = "Created this vibrant visual system for a homegrown tea startup in Ahmedabad. Crafted custom Hindi-English typography fusion, packaging tin labels, and Instagram launch templates. What do you think of this warm terracotta and cardamom green color scheme?",
                tags = listOf("#BrandDesign", "#Packaging", "#LogoDesign", "#MadeInIndia"),
                linkedServiceId = "srv_design_1",
                linkedServiceTitle = "Complete Brand Identity Kit + Vector Logo",
                linkedPriceInr = 1999,
                likesCount = 142,
                isLikedByMe = true,
                commentsCount = 19,
                sharesCount = 28,
                isFollowedByMe = true,
                timestamp = "6 hours ago"
            ),
            Post(
                id = "post_3",
                workerId = "usr_suresh",
                workerName = "Suresh Kumar",
                workerTrade = "Licensed Senior Electrician",
                workerAvatarColor = "#0288D1",
                workerLocation = "Bengaluru",
                workerRating = 4.8f,
                type = PostType.TIPS_UPDATE,
                title = "⚡ Pro Safety Tip: Why your Geyser trips the MCB in Winter",
                caption = "90% of tripping during cold months is due to hard water scaling on the immersion element creating micro-current leakage to earth. Always check for a proper 30mA RCCB breaker in your DB box. Never bypass a tripping MCB with a thicker wire!",
                tags = listOf("#ElectricianTips", "#ElectricalSafety", "#BengaluruHomes"),
                linkedServiceId = "srv_electric_1",
                linkedServiceTitle = "Complete 2BHK/3BHK Electrical Health & MCB Fix",
                linkedPriceInr = 899,
                likesCount = 67,
                isLikedByMe = false,
                commentsCount = 8,
                sharesCount = 15,
                isFollowedByMe = false,
                timestamp = "1 day ago"
            ),
            Post(
                id = "post_4",
                workerId = "usr_vikram",
                workerName = "Vikram Singh",
                workerTrade = "Master Carpenter & Modular Woodcraft",
                workerAvatarColor = "#5D4037",
                workerLocation = "Pune",
                workerRating = 4.9f,
                type = PostType.WORK_SHOWCASE,
                title = "Custom Teakwood Temple & Floating TV Console 🪚✨",
                caption = "Completed this turnkey living room installation in Baner. Built with 19mm marine-grade BWP plywood and natural Burmese teak veneer with warm LED cove backlighting. Hand-sanded and finished with satin PU coat.",
                tags = listOf("#Woodwork", "#CustomFurniture", "#PuneCarpenters", "#InteriorDesign"),
                linkedServiceId = "srv_carpenter_1",
                linkedServiceTitle = "Hydraulic Bed & Plywood Wardrobe Hinge Fix",
                linkedPriceInr = 1200,
                likesCount = 110,
                isLikedByMe = false,
                commentsCount = 14,
                sharesCount = 9,
                isFollowedByMe = false,
                timestamp = "2 days ago"
            )
        )

        val initialComments = mapOf(
            "post_1" to listOf(
                Comment(
                    id = "c1",
                    postId = "post_1",
                    userId = "usr_rahul",
                    userName = "Rahul Gond",
                    userAvatarColor = "#1A237E",
                    text = "Bhaiya, do you also repair terrace shed fabrication in Mayur Vihar?",
                    timestamp = "2 hours ago"
                ),
                Comment(
                    id = "c2",
                    postId = "post_1",
                    userId = "usr_ramesh",
                    userName = "Ramesh Sharma (Author)",
                    userAvatarColor = "#E65100",
                    text = "Yes Rahul ji! I do all shed roofing, MS framework, and polycarb sheet installations. You can book my service package or DM me directly!",
                    timestamp = "1 hour ago"
                )
            ),
            "post_2" to listOf(
                Comment(
                    id = "c3",
                    postId = "post_2",
                    userId = "usr_vikram",
                    userName = "Vikram Singh",
                    userAvatarColor = "#5D4037",
                    text = "Clean typography and palette! Super sharp work Priya.",
                    timestamp = "4 hours ago"
                )
            )
        )

        val initialOrders = listOf(
            Order(
                id = "SK-4821",
                serviceId = "srv_welding_1",
                serviceTitle = "MS Gate & Main Entrance Grill Welding Repair",
                serviceCategory = "Welding",
                customerId = "usr_rahul",
                customerName = "Rahul Gond",
                customerPhone = "+91 98765 43210",
                workerId = "usr_ramesh",
                workerName = "Ramesh Sharma",
                workerTrade = "Master Welder & Fabricator",
                priceInr = 1500,
                status = OrderStatus.IN_PROGRESS,
                requirementDetails = "Main driveway double-leaf gate bottom hinge is bent and scratching the floor tiles. Needs reinforcement bracket welding.",
                serviceAddress = "House 42-B, Block C, Preet Vihar, New Delhi - 110092",
                preferredDate = "Tomorrow",
                timeSlot = "10:00 AM - 1:00 PM",
                instructions = "Please bring portable welding gear. Power plug available near driveway.",
                createdAt = System.currentTimeMillis() - 86400000L,
                hasReview = false
            ),
            Order(
                id = "SK-3190",
                serviceId = "srv_electric_1",
                serviceTitle = "Complete Electrical Health & MCB Fix",
                serviceCategory = "Electrician",
                customerId = "usr_rahul",
                customerName = "Rahul Gond",
                customerPhone = "+91 98765 43210",
                workerId = "usr_suresh",
                workerName = "Suresh Kumar",
                workerTrade = "Licensed Senior Electrician",
                priceInr = 899,
                status = OrderStatus.COMPLETED,
                requirementDetails = "Master bedroom AC MCB tripping constantly after 10 mins running.",
                serviceAddress = "House 42-B, Block C, Preet Vihar, New Delhi",
                preferredDate = "Last Week",
                timeSlot = "3:00 PM - 5:00 PM",
                instructions = "Main board located near stairwell.",
                createdAt = System.currentTimeMillis() - (86400000L * 5),
                hasReview = true
            )
        )

        val initialMessages = listOf(
            ChatMessage(
                id = "m1",
                conversationId = "usr_rahul_usr_ramesh",
                senderId = "usr_rahul",
                senderName = "Rahul Gond",
                receiverId = "usr_ramesh",
                text = "Namaste Ramesh ji! I booked your MS Gate Welding package for tomorrow morning (Order #SK-4821).",
                orderIdRef = "SK-4821",
                timestamp = System.currentTimeMillis() - 3600000L * 3,
                formattedTime = "09:15 AM",
                isRead = true
            ),
            ChatMessage(
                id = "m2",
                conversationId = "usr_rahul_usr_ramesh",
                senderId = "usr_ramesh",
                senderName = "Ramesh Sharma",
                receiverId = "usr_rahul",
                text = "Namaste Rahul ji! I saw your booking. I will arrive around 10:30 AM with my mobile arc unit, heavy clamps, and primer. Will get your gate swinging smoothly like new!",
                orderIdRef = "SK-4821",
                timestamp = System.currentTimeMillis() - 3600000L * 2,
                formattedTime = "09:30 AM",
                isRead = true
            ),
            ChatMessage(
                id = "m3",
                conversationId = "usr_rahul_usr_ramesh",
                senderId = "usr_rahul",
                senderName = "Rahul Gond",
                receiverId = "usr_ramesh",
                text = "Great! Power connection is ready at the parking pillar.",
                orderIdRef = "SK-4821",
                timestamp = System.currentTimeMillis() - 3600000L,
                formattedTime = "10:00 AM",
                isRead = true
            )
        )

        val initialReviews = listOf(
            Review(
                id = "rev_1",
                workerId = "usr_ramesh",
                customerId = "usr_rahul",
                customerName = "Rahul Gond",
                serviceTitle = "MS Gate & Main Entrance Grill Welding Repair",
                rating = 5,
                comment = "Ramesh ji did an exceptional job! Very polite, brought proper safety gear and heavy duty rods. Gate swings like brand new. Fixed price, no extra drama. Highly recommend!",
                tags = listOf("On Time", "Master Craftsman", "Transparent Fixed Price", "Clean Finish"),
                date = "3 days ago"
            ),
            Review(
                id = "rev_2",
                workerId = "usr_ramesh",
                customerId = "usr_vikram",
                customerName = "Anand Mehra",
                serviceTitle = "Custom Grill & Balcony Railing",
                rating = 5,
                comment = "Precision alignment and solid weld joints. The anti-rust primer finish was very neat.",
                tags = listOf("Professional", "Top Quality", "Fair Price"),
                date = "1 week ago"
            ),
            Review(
                id = "rev_3",
                workerId = "usr_priya",
                customerId = "usr_rahul",
                customerName = "Vikas Singhal",
                serviceTitle = "Complete Brand Identity Kit",
                rating = 5,
                comment = "Priya delivered the concepts within 48 hours. The vector source files and color palette were studio quality. Super cooperative with adjustments!",
                tags = listOf("Creative", "Fast Delivery", "Super Communicator"),
                date = "4 days ago"
            )
        )

        val initialNotifications = listOf(
            NotificationItem(
                id = "n1",
                userId = "usr_rahul",
                type = NotificationType.BOOKING_ACCEPTED,
                title = "Order Accepted!",
                message = "Ramesh Sharma accepted your booking #SK-4821 for MS Gate Welding.",
                relatedId = "SK-4821",
                timestamp = "2 hours ago",
                isRead = false
            ),
            NotificationItem(
                id = "n2",
                userId = "usr_rahul",
                type = NotificationType.NEW_MESSAGE,
                title = "New Message from Ramesh Sharma",
                message = "\"Namaste Rahul ji! I saw your booking. I will arrive around 10:30 AM...\"",
                relatedId = "usr_ramesh",
                timestamp = "2 hours ago",
                isRead = false
            ),
            NotificationItem(
                id = "n3",
                userId = "usr_ramesh",
                type = NotificationType.BOOKING_NEW,
                title = "New Booking Received",
                message = "Rahul Gond booked MS Gate Welding (₹1,500).",
                relatedId = "SK-4821",
                timestamp = "3 hours ago",
                isRead = true
            )
        )

        val initialSupportTickets = listOf(
            SupportTicket(
                id = "TKT-1082",
                ticketId = "TKT-1082",
                userId = "usr_rahul",
                userName = "Rahul Gond",
                userEmail = "rahul.gond@example.com",
                userRole = "customer",
                subject = "Timing & Slot Adjustment for MCB Wiring",
                category = "Order Problem",
                status = TicketStatus.OPEN,
                priority = TicketPriority.MEDIUM,
                relatedOrderId = "ord_101",
                relatedOrderTitle = "Complete 3-Phase MCB Distribution Box Installation",
                internalNotes = "Customer requested 2:30 PM slot instead of 11:00 AM. Electrician Suresh informed.",
                createdAt = System.currentTimeMillis() - 7200000,
                updatedAt = System.currentTimeMillis() - 1800000,
                lastMessage = "Hello Rahul, we have notified technician Suresh Kumar regarding the 2:30 PM timing update.",
                unreadUserCount = 1,
                unreadAdminCount = 0
            ),
            SupportTicket(
                id = "TKT-1054",
                ticketId = "TKT-1054",
                userId = "usr_rahul",
                userName = "Rahul Gond",
                userEmail = "rahul.gond@example.com",
                userRole = "customer",
                subject = "Fixed Price Guarantee and Invoice Summary",
                category = "Payment Problem",
                status = TicketStatus.RESOLVED,
                priority = TicketPriority.LOW,
                relatedOrderId = "ord_102",
                relatedOrderTitle = "Heavy Duty Modern MS Sliding Main Gate Fabrication",
                internalNotes = "Invoice and tax breakdown shared with customer. Resolved.",
                createdAt = System.currentTimeMillis() - 172800000,
                updatedAt = System.currentTimeMillis() - 86400000,
                lastMessage = "Your GST tax breakdown and fixed payment receipt have been verified and archived.",
                unreadUserCount = 0,
                unreadAdminCount = 0
            ),
            SupportTicket(
                id = "TKT-1099",
                ticketId = "TKT-1099",
                userId = "usr_ramesh",
                userName = "Ramesh Sharma",
                userEmail = "ramesh.welder@skillkart.in",
                userRole = "worker",
                subject = "Safety equipment & ISI certificate fast-track badge",
                category = "Safety Problem",
                status = TicketStatus.WAITING_FOR_SUPPORT,
                priority = TicketPriority.HIGH,
                internalNotes = "Worker submitted valid ISI safety compliance certificates. Verification pending.",
                createdAt = System.currentTimeMillis() - 3600000,
                updatedAt = System.currentTimeMillis() - 3600000,
                lastMessage = "Submitted my argon welding ISI safety compliance certification for fast-track badge.",
                unreadUserCount = 0,
                unreadAdminCount = 1
            )
        )

        val initialSupportMessages = mapOf(
            "TKT-1082" to listOf(
                SupportMessage(
                    id = "msg_t1_1",
                    ticketId = "TKT-1082",
                    senderId = "usr_rahul",
                    senderName = "Rahul Gond",
                    senderRole = "user",
                    message = "Hi Team, I need to check if electrician Suresh can arrive at 2:30 PM instead of 11:00 AM tomorrow due to power shutdown in our building?",
                    createdAt = System.currentTimeMillis() - 7200000,
                    read = true,
                    formattedTime = "2 hours ago"
                ),
                SupportMessage(
                    id = "msg_t1_2",
                    ticketId = "TKT-1082",
                    senderId = "support_agent",
                    senderName = "SkillKart Support",
                    senderRole = "admin",
                    message = "Hello Rahul! Welcome to SkillKart In-App Support. We have notified technician Suresh Kumar regarding the 2:30 PM timing update. He will confirm shortly in your order chat.",
                    createdAt = System.currentTimeMillis() - 1800000,
                    read = false,
                    formattedTime = "30 mins ago"
                )
            ),
            "TKT-1054" to listOf(
                SupportMessage(
                    id = "msg_t2_1",
                    ticketId = "TKT-1054",
                    senderId = "usr_rahul",
                    senderName = "Rahul Gond",
                    senderRole = "user",
                    message = "Could you please re-share the fixed price invoice summary for my MS gate fabrication?",
                    createdAt = System.currentTimeMillis() - 172800000,
                    read = true,
                    formattedTime = "2 days ago"
                ),
                SupportMessage(
                    id = "msg_t2_2",
                    ticketId = "TKT-1054",
                    senderId = "support_agent",
                    senderName = "SkillKart Support",
                    senderRole = "admin",
                    message = "Your GST tax breakdown and fixed payment receipt have been verified and archived. The ₹18,500 total is fixed with zero extra charges.",
                    createdAt = System.currentTimeMillis() - 86400000,
                    read = true,
                    formattedTime = "1 day ago"
                )
            ),
            "TKT-1099" to listOf(
                SupportMessage(
                    id = "msg_t3_1",
                    ticketId = "TKT-1099",
                    senderId = "usr_ramesh",
                    senderName = "Ramesh Sharma",
                    senderRole = "worker",
                    message = "Submitted my argon welding ISI safety compliance certification for fast-track badge.",
                    createdAt = System.currentTimeMillis() - 3600000,
                    read = false,
                    formattedTime = "1 hour ago"
                )
            )
        )

        val initialComplaints = listOf(
            Complaint(
                id = "CMP-90812",
                complaintId = "CMP-90812",
                ticketId = "TKT-1082",
                userId = "usr_rahul",
                userName = "Rahul Gond",
                category = "Order Problem",
                orderId = "ord_101",
                orderTitle = "Complete 3-Phase MCB Distribution Box Installation",
                details = "Requested slot rescheduling due to maintenance in society power lines.",
                status = "Under Investigation",
                createdAt = System.currentTimeMillis() - 7200000
            )
        )

        val initialFaqs = listOf(
            FaqItem(
                id = "faq_1",
                question = "How does SkillKart 100% Fixed Pricing work?",
                answer = "Every service package on SkillKart has an all-inclusive, upfront INR price. Workers agree to the exact defined scope before booking and are strictly prohibited from demanding extra on-site fees or sudden charges.",
                category = "Fixed Pricing",
                orderIndex = 1
            ),
            FaqItem(
                id = "faq_2",
                question = "How do I communicate with my assigned worker?",
                answer = "All communication happens securely inside the app via real-time In-App Chat. You can discuss exact requirements, share photos of the issue, and coordinate timing safely.",
                category = "General",
                orderIndex = 2
            ),
            FaqItem(
                id = "faq_3",
                question = "How do I report a problem or register a complaint?",
                answer = "You can report a problem from 'Orders → 🚨 Report a Problem' or from 'Profile → Help & Support → 🚨 Report a Problem'. A dedicated support ticket will be opened immediately and our team will assist you via live in-app chat.",
                category = "Complaints & Support",
                orderIndex = 3
            ),
            FaqItem(
                id = "faq_4",
                question = "How do cancellations and refunds work?",
                answer = "If you cancel before the skilled worker begins traveling to your location, you receive an instant 100% refund. You can monitor refund progress and dispute status directly in the Support Chat.",
                category = "Payments & Refunds",
                orderIndex = 4
            ),
            FaqItem(
                id = "faq_5",
                question = "How are workers verified on SkillKart?",
                answer = "Every professional undergoes Aadhaar/Govt ID verification, trade certification background checks, and past work portfolio inspection before receiving their verified badge.",
                category = "Verification",
                orderIndex = 5
            ),
            FaqItem(
                id = "faq_6",
                question = "How do I reach the SkillKart Support Team?",
                answer = "All customer and worker support is handled directly through our In-App Support Chat. Go to 'Profile → Help & Support → 💬 Chat with Support' to connect with our operations team.",
                category = "Complaints & Support",
                orderIndex = 6
            )
        )
    }
}
