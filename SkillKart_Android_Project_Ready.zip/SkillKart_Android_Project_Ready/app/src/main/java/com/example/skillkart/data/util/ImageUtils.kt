package com.example.skillkart.data.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ImageUtils {

    suspend fun compressImageUri(context: Context, uri: Uri, maxDimension: Int = 1024, quality: Int = 80): ByteArray? {
        return withContext(Dispatchers.IO) {
            try {
                var input: InputStream? = context.contentResolver.openInputStream(uri)
                val options = BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                BitmapFactory.decodeStream(input, null, options)
                input?.close()

                var sampleSize = 1
                while (options.outWidth / sampleSize > maxDimension || options.outHeight / sampleSize > maxDimension) {
                    sampleSize *= 2
                }

                val decodeOptions = BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                }

                input = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(input, null, decodeOptions)
                input?.close()

                if (bitmap != null) {
                    val stream = ByteArrayOutputStream()
                    bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream)
                    val bytes = stream.toByteArray()
                    bitmap.recycle()
                    bytes
                } else null
            } catch (e: Exception) {
                e.printStackTrace()
                null
            }
        }
    }

    suspend fun uriToBase64DataUrl(context: Context, uri: Uri): String? {
        return withContext(Dispatchers.IO) {
            try {
                val bytes = compressImageUri(context, uri, maxDimension = 800, quality = 75)
                if (bytes != null) {
                    val base64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                    "data:image/jpeg;base64,$base64"
                } else null
            } catch (e: Exception) {
                null
            }
        }
    }
}
