package com.example.skillkart.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.skillkart.data.model.CategoryItem
import com.example.skillkart.data.model.Challenge
import com.example.skillkart.data.model.ChatMessage
import com.example.skillkart.data.model.Comment
import com.example.skillkart.data.model.Complaint
import com.example.skillkart.data.model.FaqItem
import com.example.skillkart.data.model.NotificationItem
import com.example.skillkart.data.model.Order
import com.example.skillkart.data.model.OrderStatus
import com.example.skillkart.data.model.Post
import com.example.skillkart.data.model.PostType
import com.example.skillkart.data.model.Review
import com.example.skillkart.data.model.ServicePackage
import com.example.skillkart.data.model.SkillCategories
import com.example.skillkart.data.model.SupportMessage
import com.example.skillkart.data.model.SupportTicket
import com.example.skillkart.data.model.TicketPriority
import com.example.skillkart.data.model.TicketStatus
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import com.example.skillkart.data.repository.SkillKartRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class MainTab(val title: String, val hindiTitle: String) {
    HOME("Home", "होम"),
    DISCOVER("Discover", "खोजें"),
    CREATE("Create", "बनाएं"),
    ORDERS("Orders", "ऑर्डर"),
    PROFILE("Profile", "प्रोफ़ाइल")
}

data class FilterState(
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val maxPrice: Int = 10000,
    val minRating: Float = 0f,
    val sortBy: String = "Popular" // Popular, Rating, PriceLow, PriceHigh
)

class SkillKartViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SkillKartRepository.getInstance(application)

    // Current Navigation State
    private val _currentTab = MutableStateFlow(MainTab.HOME)
    val currentTab: StateFlow<MainTab> = _currentTab.asStateFlow()

    // Active User & Users
    val currentUser: StateFlow<User> = repository.currentUser
    val allUsers: StateFlow<List<User>> = repository.allUsers

    // Services & Feed
    val allServices: StateFlow<List<ServicePackage>> = repository.allServices
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPosts: StateFlow<List<Post>> = repository.allPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMessages: StateFlow<List<ChatMessage>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReviews: StateFlow<List<Review>> = repository.allReviews
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNotifications: StateFlow<List<NotificationItem>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // In-memory comments store
    val postComments: StateFlow<Map<String, List<Comment>>> = repository.postComments

    // Firebase state
    val isFirebaseAvailable: Boolean = repository.firebaseManager.isFirebaseAvailable

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _uploadProgress = MutableStateFlow<Float?>(null)
    val uploadProgress: StateFlow<Float?> = _uploadProgress.asStateFlow()

    fun clearAuthError() {
        _authError.value = null
    }

    // Discover Filter State
    private val _filterState = MutableStateFlow(FilterState())
    val filterState: StateFlow<FilterState> = _filterState.asStateFlow()

    // Filtered Services for Discover Screen
    val filteredServices: StateFlow<List<ServicePackage>> = combine(
        allServices,
        _filterState
    ) { services, filter ->
        services.filter { srv ->
            val matchCat = filter.selectedCategory == "All" || srv.category.equals(filter.selectedCategory, ignoreCase = true)
            val matchQuery = filter.searchQuery.isBlank() ||
                    srv.title.contains(filter.searchQuery, ignoreCase = true) ||
                    srv.workerName.contains(filter.searchQuery, ignoreCase = true) ||
                    srv.category.contains(filter.searchQuery, ignoreCase = true) ||
                    srv.workerLocation.contains(filter.searchQuery, ignoreCase = true) ||
                    srv.description.contains(filter.searchQuery, ignoreCase = true)
            val matchPrice = srv.priceInr <= filter.maxPrice
            val matchRating = srv.workerRating >= filter.minRating
            matchCat && matchQuery && matchPrice && matchRating
        }.sortedWith { a, b ->
            when (filter.sortBy) {
                "Rating" -> b.workerRating.compareTo(a.workerRating)
                "PriceLow" -> a.priceInr.compareTo(b.priceInr)
                "PriceHigh" -> b.priceInr.compareTo(a.priceInr)
                else -> b.workerRating.compareTo(a.workerRating)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Details for navigation overlays/sheets
    private val _selectedService = MutableStateFlow<ServicePackage?>(null)
    val selectedService: StateFlow<ServicePackage?> = _selectedService.asStateFlow()

    private val _selectedWorker = MutableStateFlow<User?>(null)
    val selectedWorker: StateFlow<User?> = _selectedWorker.asStateFlow()

    private val _selectedOrder = MutableStateFlow<Order?>(null)
    val selectedOrder: StateFlow<Order?> = _selectedOrder.asStateFlow()

    private val _activeChatPartner = MutableStateFlow<User?>(null)
    val activeChatPartner: StateFlow<User?> = _activeChatPartner.asStateFlow()

    private val _activeChatOrderIdRef = MutableStateFlow<String?>(null)
    val activeChatOrderIdRef: StateFlow<String?> = _activeChatOrderIdRef.asStateFlow()

    // Sheets / Dialogs
    private val _showBookingSheet = MutableStateFlow(false)
    val showBookingSheet: StateFlow<Boolean> = _showBookingSheet.asStateFlow()

    private val _showReviewDialog = MutableStateFlow(false)
    val showReviewDialog: StateFlow<Boolean> = _showReviewDialog.asStateFlow()
    private val _orderToReview = MutableStateFlow<Order?>(null)
    val orderToReview: StateFlow<Order?> = _orderToReview.asStateFlow()

    private val _activeCommentPost = MutableStateFlow<Post?>(null)
    val activeCommentPost: StateFlow<Post?> = _activeCommentPost.asStateFlow()

    private val _showAuthScreen = MutableStateFlow(false)
    val showAuthScreen: StateFlow<Boolean> = _showAuthScreen.asStateFlow()

    private val _showNotificationsSheet = MutableStateFlow(false)
    val showNotificationsSheet: StateFlow<Boolean> = _showNotificationsSheet.asStateFlow()

    private val _showEditProfileDialog = MutableStateFlow(false)
    val showEditProfileDialog: StateFlow<Boolean> = _showEditProfileDialog.asStateFlow()

    // UI Feedback Toast/Snackbar
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // Support System State Flows
    val supportTickets: StateFlow<List<SupportTicket>> = repository.supportTickets
    val supportMessages: StateFlow<Map<String, List<SupportMessage>>> = repository.supportMessages
    val complaints: StateFlow<List<Complaint>> = repository.complaints
    val faqs: StateFlow<List<FaqItem>> = repository.faqs

    // Support Navigation & Overlays
    private val _showHelpSupportScreen = MutableStateFlow(false)
    val showHelpSupportScreen: StateFlow<Boolean> = _showHelpSupportScreen.asStateFlow()

    private val _activeSupportTicket = MutableStateFlow<SupportTicket?>(null)
    val activeSupportTicket: StateFlow<SupportTicket?> = _activeSupportTicket.asStateFlow()

    private val _showMyComplaints = MutableStateFlow(false)
    val showMyComplaints: StateFlow<Boolean> = _showMyComplaints.asStateFlow()

    private val _showFaqs = MutableStateFlow(false)
    val showFaqs: StateFlow<Boolean> = _showFaqs.asStateFlow()

    private val _showReportProblemDialog = MutableStateFlow(false)
    val showReportProblemDialog: StateFlow<Boolean> = _showReportProblemDialog.asStateFlow()

    private val _preselectedComplaintOrder = MutableStateFlow<Order?>(null)
    val preselectedComplaintOrder: StateFlow<Order?> = _preselectedComplaintOrder.asStateFlow()

    private val _showAdminSupportScreen = MutableStateFlow(false)
    val showAdminSupportScreen: StateFlow<Boolean> = _showAdminSupportScreen.asStateFlow()

    // Challenges State Flow & UI Overlays
    val challenges: StateFlow<List<Challenge>> = repository.challenges
    private val _showChallengesScreen = MutableStateFlow(false)
    val showChallengesScreen: StateFlow<Boolean> = _showChallengesScreen.asStateFlow()

    fun openChallenges() {
        _showChallengesScreen.value = true
    }

    fun closeChallenges() {
        _showChallengesScreen.value = false
    }

    fun toggleJoinChallenge(challengeId: String) {
        repository.toggleJoinChallenge(challengeId)
        val ch = repository.challenges.value.find { it.id == challengeId }
        val joined = ch?.isJoinedByMe == true
        showSnackbar(if (joined) "🎉 You joined the challenge! Submit your work to climb the leaderboard." else "Left challenge")
    }

    fun voteForChallengeParticipant(challengeId: String, workerId: String) {
        repository.voteForChallengeParticipant(challengeId, workerId)
        showSnackbar("⭐ Your vote has been recorded on the live leaderboard!")
    }

    fun submitChallengeWork(challengeId: String, title: String) {
        repository.submitChallengeWork(challengeId, title)
        showSnackbar("🚀 Your challenge submission has been posted! +250 XP earned.")
    }

    fun showSnackbar(msg: String) {
        _snackbarMessage.value = msg
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    // --- Support & Help Actions ---
    fun openHelpSupport() {
        _showHelpSupportScreen.value = true
    }

    fun closeHelpSupport() {
        _showHelpSupportScreen.value = false
    }

    fun openSupportChat(ticket: SupportTicket) {
        _activeSupportTicket.value = ticket
        repository.markTicketRead(ticket.id, forUser = currentUser.value.role != UserRole.ADMIN)
    }

    fun openSupportChatByTicketId(ticketId: String) {
        val found = supportTickets.value.find { it.id == ticketId }
        if (found != null) {
            _activeSupportTicket.value = found
            repository.markTicketRead(ticketId, forUser = currentUser.value.role != UserRole.ADMIN)
        }
    }

    fun closeSupportChat() {
        _activeSupportTicket.value = null
    }

    fun openMyComplaints() {
        _showMyComplaints.value = true
    }

    fun closeMyComplaints() {
        _showMyComplaints.value = false
    }

    fun openFaqs() {
        _showFaqs.value = true
    }

    fun closeFaqs() {
        _showFaqs.value = false
    }

    fun openReportProblem(order: Order? = null) {
        _preselectedComplaintOrder.value = order
        _showReportProblemDialog.value = true
    }

    fun closeReportProblem() {
        _showReportProblemDialog.value = false
        _preselectedComplaintOrder.value = null
    }

    fun openAdminSupport() {
        _showAdminSupportScreen.value = true
    }

    fun closeAdminSupport() {
        _showAdminSupportScreen.value = false
    }

    fun createSupportTicket(
        subject: String,
        category: String,
        initialMessage: String,
        orderId: String? = null,
        orderTitle: String? = null,
        imageUrl: String? = null
    ): SupportTicket {
        val ticket = repository.createSupportTicket(
            subject = subject,
            category = category,
            initialMessage = initialMessage,
            orderId = orderId,
            orderTitle = orderTitle,
            imageUrl = imageUrl
        )
        showSnackbar("Support Ticket #${ticket.ticketId} Created! Connecting to agent...")
        _activeSupportTicket.value = ticket
        return ticket
    }

    fun sendSupportMessage(ticketId: String, text: String, imageUrl: String? = null, isFromAdmin: Boolean = false) {
        repository.sendSupportMessage(ticketId, text, imageUrl, isFromAdmin)
    }

    fun updateTicketStatus(ticketId: String, newStatus: TicketStatus) {
        repository.updateTicketStatus(ticketId, newStatus)
        showSnackbar("Ticket status updated to ${newStatus.displayName}")
    }

    fun updateTicketPriority(ticketId: String, newPriority: TicketPriority) {
        repository.updateTicketPriority(ticketId, newPriority)
        showSnackbar("Ticket priority set to ${newPriority.displayName}")
    }

    fun updateTicketInternalNotes(ticketId: String, notes: String) {
        repository.updateTicketInternalNotes(ticketId, notes)
        showSnackbar("Internal notes saved")
    }

    fun closeTicket(ticketId: String) {
        repository.closeTicket(ticketId)
        showSnackbar("Ticket marked as Closed")
    }

    fun reopenTicket(ticketId: String) {
        repository.reopenTicket(ticketId)
        showSnackbar("Ticket reopened successfully")
    }

    fun submitComplaint(
        category: String,
        details: String,
        orderId: String? = null,
        orderTitle: String? = null,
        imageUrl: String? = null
    ) {
        val (complaint, ticket) = repository.createComplaint(
            category = category,
            details = details,
            orderId = orderId,
            orderTitle = orderTitle,
            evidenceImageUrl = imageUrl
        )
        closeReportProblem()
        showSnackbar("Complaint registered! Support Ticket #${ticket.ticketId} opened.")
        openSupportChat(ticket)
    }

    fun saveFaq(faq: FaqItem) {
        repository.saveFaq(faq)
        showSnackbar("FAQ saved successfully")
    }

    fun deleteFaq(faqId: String) {
        repository.deleteFaq(faqId)
        showSnackbar("FAQ deleted")
    }

    // --- Navigation & Tab actions ---
    fun selectTab(tab: MainTab) {
        _currentTab.value = tab
    }

    fun openServiceDetail(service: ServicePackage) {
        _selectedService.value = service
    }

    fun closeServiceDetail() {
        _selectedService.value = null
    }

    fun openWorkerProfile(workerId: String) {
        val user = allUsers.value.find { it.id == workerId }
        _selectedWorker.value = user
    }

    fun closeWorkerProfile() {
        _selectedWorker.value = null
    }

    fun openOrderDetail(order: Order) {
        _selectedOrder.value = order
    }

    fun closeOrderDetail() {
        _selectedOrder.value = null
    }

    fun openChatWith(user: User, orderIdRef: String? = null) {
        _activeChatPartner.value = user
        _activeChatOrderIdRef.value = orderIdRef
    }

    fun openChatWithWorkerId(workerId: String, orderIdRef: String? = null) {
        val user = allUsers.value.find { it.id == workerId }
        if (user != null) {
            _activeChatPartner.value = user
            _activeChatOrderIdRef.value = orderIdRef
        }
    }

    fun closeChat() {
        _activeChatPartner.value = null
        _activeChatOrderIdRef.value = null
    }

    fun startBooking(service: ServicePackage) {
        _selectedService.value = service
        _showBookingSheet.value = true
    }

    fun closeBooking() {
        _showBookingSheet.value = false
    }

    fun startReview(order: Order) {
        _orderToReview.value = order
        _showReviewDialog.value = true
    }

    fun closeReviewDialog() {
        _showReviewDialog.value = false
        _orderToReview.value = null
    }

    fun openCommentsFor(post: Post) {
        _activeCommentPost.value = post
    }

    fun closeComments() {
        _activeCommentPost.value = null
    }

    fun toggleNotifications(show: Boolean) {
        _showNotificationsSheet.value = show
    }

    fun toggleAuthScreen(show: Boolean) {
        _showAuthScreen.value = show
    }

    fun toggleEditProfile(show: Boolean) {
        _showEditProfileDialog.value = show
    }

    // --- Discover Filters ---
    fun setCategoryFilter(category: String) {
        _filterState.value = _filterState.value.copy(selectedCategory = category)
    }

    fun setSearchQuery(query: String) {
        _filterState.value = _filterState.value.copy(searchQuery = query)
    }

    fun setSortBy(sort: String) {
        _filterState.value = _filterState.value.copy(sortBy = sort)
    }

    fun setMaxPrice(price: Int) {
        _filterState.value = _filterState.value.copy(maxPrice = price)
    }

    fun setMinRating(rating: Float) {
        _filterState.value = _filterState.value.copy(minRating = rating)
    }

    fun updateFilters(
        category: String? = null,
        searchQuery: String? = null,
        maxPrice: Int? = null,
        minRating: Float? = null,
        sortBy: String? = null
    ) {
        _filterState.value = _filterState.value.copy(
            selectedCategory = category ?: _filterState.value.selectedCategory,
            searchQuery = searchQuery ?: _filterState.value.searchQuery,
            maxPrice = maxPrice ?: _filterState.value.maxPrice,
            minRating = minRating ?: _filterState.value.minRating,
            sortBy = sortBy ?: _filterState.value.sortBy
        )
    }

    fun resetFilters() {
        _filterState.value = FilterState()
    }

    // --- User & Role Management ---
    fun switchUser(userId: String) {
        repository.switchUser(userId)
        showSnackbar("Switched user to ${currentUser.value.name}")
    }

    fun toggleRole() {
        repository.toggleRole()
        val role = currentUser.value.role.name
        showSnackbar("Switched active mode to $role")
    }

    fun setUserIntent(role: UserRole) {
        repository.setUserIntent(role)
        showSnackbar(if (role == UserRole.WORKER) "Switched to Worker Mode 🛠️" else "Switched to Customer Mode 🛒")
    }

    fun updateProfile(name: String, location: String, bio: String, trade: String, skills: List<String>) {
        repository.updateProfile(name, location, bio, trade, skills)
        _showEditProfileDialog.value = false
        showSnackbar("Profile updated successfully!")
    }

    fun registerUser(name: String, email: String, phone: String, role: UserRole, trade: String, location: String) {
        repository.registerNewUser(name, email, phone, role, trade, location)
        _showAuthScreen.value = false
        showSnackbar("Welcome to SkillKart, $name!")
    }

    fun signUpWithFirebase(
        name: String,
        email: String,
        password: String,
        role: UserRole,
        city: String,
        area: String,
        trade: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _authError.value = null
            val result = repository.signUpWithFirebase(name, email, password, role, city, area, trade)
            _isLoading.value = false
            if (result.isSuccess) {
                showSnackbar("Welcome to SkillKart, $name!")
                _showAuthScreen.value = false
                onSuccess()
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Signup failed. Please try again."
                _authError.value = errorMsg
                showSnackbar(errorMsg)
            }
        }
    }

    fun signInWithFirebase(
        email: String,
        password: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _authError.value = null
            val result = repository.signInWithFirebase(email, password)
            _isLoading.value = false
            if (result.isSuccess) {
                showSnackbar("Welcome back, ${currentUser.value.name}!")
                _showAuthScreen.value = false
                onSuccess()
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Invalid email or password."
                _authError.value = errorMsg
                showSnackbar(errorMsg)
            }
        }
    }

    fun signOut() {
        repository.signOut()
        showSnackbar("Logged out successfully.")
    }

    fun sendPasswordReset(email: String) {
        if (email.isBlank()) {
            showSnackbar("Please enter your email address first.")
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            val result = repository.sendPasswordReset(email)
            _isLoading.value = false
            if (result.isSuccess) {
                showSnackbar("Password reset link sent to $email")
            } else {
                val errorMsg = result.exceptionOrNull()?.message ?: "Failed to send reset link."
                showSnackbar(errorMsg)
            }
        }
    }

    // --- Posts & Social Actions ---
    fun toggleLike(post: Post) {
        viewModelScope.launch {
            repository.toggleLikePost(post)
        }
    }

    fun toggleFollow(workerId: String, currentFollow: Boolean) {
        viewModelScope.launch {
            repository.toggleFollowWorker(workerId, currentFollow)
            showSnackbar(if (!currentFollow) "Following worker!" else "Unfollowed")
        }
    }

    fun submitComment(postId: String, text: String) {
        if (text.isNotBlank()) {
            repository.addCommentToPost(postId, text)
        }
    }

    fun createPost(
        title: String,
        caption: String,
        type: PostType,
        tags: List<String>,
        linkedServiceId: String?,
        linkedServiceTitle: String?,
        linkedPriceInr: Int?,
        beforeDesc: String?,
        afterDesc: String?,
        imageUrl: String? = null
    ) {
        viewModelScope.launch {
            repository.createPost(
                title, caption, type, tags, linkedServiceId, linkedServiceTitle, linkedPriceInr, beforeDesc, afterDesc, imageUrl
            )
            _currentTab.value = MainTab.HOME
            showSnackbar("Work showcase posted to Feed!")
        }
    }

    // --- Service Package Creation ---
    fun createServicePackage(
        title: String,
        category: String,
        priceInr: Int,
        completionTime: String,
        serviceRadius: String,
        maxVisits: String,
        description: String,
        inclusions: List<String>,
        images: List<String> = emptyList()
    ) {
        viewModelScope.launch {
            repository.createServicePackage(
                title, category, priceInr, completionTime, serviceRadius, maxVisits, description, inclusions, images
            )
            _currentTab.value = MainTab.DISCOVER
            showSnackbar("Service Package \"$title\" published!")
        }
    }

    // --- Booking / Orders ---
    fun confirmBooking(
        service: ServicePackage,
        requirement: String,
        address: String,
        date: String,
        timeSlot: String,
        instructions: String,
        imageUrl: String? = null
    ) {
        viewModelScope.launch {
            val order = repository.createOrder(
                service = service,
                requirementDetails = requirement,
                address = address,
                date = date,
                timeSlot = timeSlot,
                instructions = instructions,
                imageUrl = imageUrl
            )
            _showBookingSheet.value = false
            _selectedService.value = null
            _selectedOrder.value = order
            _currentTab.value = MainTab.ORDERS
            showSnackbar("Booking Confirmed! Order #${order.id}")
        }
    }

    fun updateOrderStatus(order: Order, newStatus: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(order, newStatus)
            showSnackbar("Order #${order.id} status updated to ${newStatus.displayName}")
        }
    }

    // --- Chat ---
    fun sendChatMessage(receiverId: String, text: String, imageNote: String? = null, orderIdRef: String? = null) {
        val user = currentUser.value
        val conversationId = repository.getConversationId(user.id, receiverId)
        viewModelScope.launch {
            repository.sendChatMessage(
                conversationId = conversationId,
                senderId = user.id,
                senderName = user.name,
                receiverId = receiverId,
                text = text,
                imageUrl = imageNote,
                orderIdRef = orderIdRef
            )
        }
    }

    // --- Reviews ---
    fun submitReview(rating: Int, comment: String, tags: List<String>, imageUrl: String? = null) {
        val order = _orderToReview.value ?: return
        viewModelScope.launch {
            repository.submitReview(order, rating, comment, tags, imageUrl)
            _showReviewDialog.value = false
            _orderToReview.value = null
            showSnackbar("Review submitted! Thank you.")
        }
    }
}
