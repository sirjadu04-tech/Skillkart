package com.example.skillkart.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import kotlinx.coroutines.flow.Flow

class Converters {
    @TypeConverter
    fun fromStringList(value: List<String>?): String {
        return value?.joinToString("||") ?: ""
    }

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrEmpty()) return emptyList()
        return value.split("||").filter { it.isNotBlank() }
    }
}

@Entity(tableName = "services")
data class ServicePackageEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val workerName: String,
    val workerTrade: String,
    val workerRating: Float,
    val workerLocation: String,
    val title: String,
    val category: String,
    val priceInr: Int,
    val completionTime: String,
    val serviceRadius: String,
    val maxVisits: String,
    val description: String,
    val inclusions: List<String>,
    val isActive: Boolean,
    val createdAt: Long
)

@Entity(tableName = "posts")
data class PostEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val workerName: String,
    val workerTrade: String,
    val workerAvatarColor: String,
    val workerLocation: String,
    val workerRating: Float,
    val type: String,
    val title: String,
    val caption: String,
    val tags: List<String>,
    val linkedServiceId: String?,
    val linkedServiceTitle: String?,
    val linkedPriceInr: Int?,
    val beforeDescription: String?,
    val afterDescription: String?,
    val likesCount: Int,
    val isLikedByMe: Boolean,
    val commentsCount: Int,
    val sharesCount: Int,
    val isFollowedByMe: Boolean,
    val timestamp: String
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val serviceId: String,
    val serviceTitle: String,
    val serviceCategory: String,
    val customerId: String,
    val customerName: String,
    val customerPhone: String,
    val workerId: String,
    val workerName: String,
    val workerTrade: String,
    val priceInr: Int,
    val status: String,
    val requirementDetails: String,
    val serviceAddress: String,
    val preferredDate: String,
    val timeSlot: String,
    val instructions: String,
    val createdAt: Long,
    val hasReview: Boolean
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val receiverId: String,
    val text: String,
    val imageUrl: String?,
    val orderIdRef: String?,
    val timestamp: Long,
    val formattedTime: String,
    val isRead: Boolean
)

@Entity(tableName = "reviews")
data class ReviewEntity(
    @PrimaryKey val id: String,
    val workerId: String,
    val customerId: String,
    val customerName: String,
    val serviceTitle: String,
    val rating: Int,
    val comment: String,
    val tags: List<String>,
    val date: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val type: String,
    val title: String,
    val message: String,
    val relatedId: String?,
    val timestamp: String,
    val isRead: Boolean
)

@Dao
interface SkillKartDao {
    @Query("SELECT * FROM services ORDER BY createdAt DESC")
    fun getAllServices(): Flow<List<ServicePackageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertServices(services: List<ServicePackageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertService(service: ServicePackageEntity)

    @Query("SELECT * FROM posts")
    fun getAllPosts(): Flow<List<PostEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPosts(posts: List<PostEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: PostEntity)

    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<OrderEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessageEntity>)

    @Query("SELECT * FROM reviews")
    fun getAllReviews(): Flow<List<ReviewEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: ReviewEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReviews(reviews: List<ReviewEntity>)

    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)
}

@Database(
    entities = [
        ServicePackageEntity::class,
        PostEntity::class,
        OrderEntity::class,
        ChatMessageEntity::class,
        ReviewEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class SkillKartDatabase : RoomDatabase() {
    abstract fun skillKartDao(): SkillKartDao
}
