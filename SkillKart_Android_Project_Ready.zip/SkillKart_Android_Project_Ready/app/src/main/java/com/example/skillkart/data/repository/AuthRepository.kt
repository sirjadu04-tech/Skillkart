package com.example.skillkart.data.repository

import android.util.Log
import com.example.skillkart.data.firebase.FirebaseConfig
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

/**
 * Repository responsible for user authentication and user profile management in Firestore.
 * Utilizes the initialized FirebaseAuth and FirebaseFirestore instances from [FirebaseConfig].
 */
class AuthRepository(
    private val auth: FirebaseAuth? = FirebaseConfig.auth,
    private val firestore: FirebaseFirestore? = FirebaseConfig.firestore
) {

    companion object {
        private const val TAG = "AuthRepository"

        @Volatile
        private var instance: AuthRepository? = null

        fun getInstance(): AuthRepository {
            return instance ?: synchronized(this) {
                instance ?: AuthRepository().also { instance = it }
            }
        }
    }

    /**
     * Flow that emits the currently authenticated [FirebaseUser] whenever the auth state changes.
     */
    val authStateFlow: Flow<FirebaseUser?> = callbackFlow {
        val authClient = auth
        if (authClient == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        authClient.addAuthStateListener(listener)

        awaitClose {
            authClient.removeAuthStateListener(listener)
        }
    }

    /**
     * Current authenticated Firebase user, or null if not signed in.
     */
    val currentFirebaseUser: FirebaseUser?
        get() = auth?.currentUser

    /**
     * Signs up a new user with email and password, sets their display name,
     * and creates the user profile document in the Firestore 'users' collection.
     * If the user is a WORKER, also creates a document in 'workerProfiles'.
     */
    suspend fun signUp(
        name: String,
        email: String,
        password: String,
        role: UserRole,
        city: String = "Delhi NCR",
        area: String = "Connaught Place",
        phone: String = "",
        trade: String = "",
        bio: String = "",
        skills: List<String> = emptyList()
    ): Result<User> {
        val authClient = auth ?: return Result.failure(IllegalStateException("FirebaseAuth is not initialized"))
        val db = firestore ?: return Result.failure(IllegalStateException("FirebaseFirestore is not initialized"))

        return try {
            val authResult = authClient.createUserWithEmailAndPassword(email.trim(), password).await()
            val firebaseUser = authResult.user ?: return Result.failure(IllegalStateException("User creation failed"))

            // Update Firebase Auth display name
            try {
                val profileUpdates = UserProfileChangeRequest.Builder()
                    .setDisplayName(name.trim())
                    .build()
                firebaseUser.updateProfile(profileUpdates).await()
            } catch (e: Exception) {
                Log.w(TAG, "Notice: could not update Firebase display name", e)
            }

            val uid = firebaseUser.uid
            val location = if (city.isNotBlank()) "$area, $city" else area
            val defaultAvatarColor = if (role == UserRole.WORKER) "#E65100" else "#1A237E"
            val userTrade = if (role == UserRole.WORKER && trade.isBlank()) "Skilled Professional" else trade
            val userBio = if (bio.isNotBlank()) bio else {
                if (role == UserRole.WORKER) "Dedicated and skilled $userTrade with verified local experience."
                else "Valued client looking for trusted local workers."
            }
            val userSkills = if (skills.isNotEmpty()) skills else {
                if (role == UserRole.WORKER && userTrade.isNotBlank()) listOf(userTrade, "Verified Work", "Quality Guaranteed")
                else emptyList()
            }

            val newUser = User(
                id = uid,
                uid = uid,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                role = role,
                accountType = if (role == UserRole.WORKER) "worker" else if (role == UserRole.ADMIN) "admin" else "customer",
                trade = userTrade,
                city = city.trim(),
                area = area.trim(),
                location = location,
                bio = userBio,
                skills = userSkills,
                rating = 5.0f,
                reviewCount = 0,
                completedJobs = 0,
                followersCount = 0,
                followingCount = 0,
                avatarColorHex = defaultAvatarColor,
                isVerified = true,
                createdAt = System.currentTimeMillis()
            )

            // Save user document in the 'users' Firestore collection
            val userMap = newUser.toFirestoreMap()
            db.collection(FirebaseConfig.COLLECTION_USERS)
                .document(uid)
                .set(userMap, SetOptions.merge())
                .await()

            // If the role is WORKER, also mirror to 'workerProfiles' collection
            if (role == UserRole.WORKER) {
                db.collection(FirebaseConfig.COLLECTION_WORKER_PROFILES)
                    .document(uid)
                    .set(userMap, SetOptions.merge())
                    .await()
            }

            Log.i(TAG, "Successfully signed up and created Firestore document for user: $uid")
            Result.success(newUser)
        } catch (e: FirebaseAuthException) {
            val readableMessage = mapAuthErrorCode(e.errorCode, e.message)
            Log.e(TAG, "Sign up FirebaseAuthException: ${e.errorCode} - ${e.message}")
            Result.failure(Exception(readableMessage, e))
        } catch (e: Exception) {
            Log.e(TAG, "Sign up failed", e)
            Result.failure(e)
        }
    }

    /**
     * Signs in an existing user with email and password and loads their profile from Firestore.
     */
    suspend fun signIn(email: String, password: String): Result<User> {
        val authClient = auth ?: return Result.failure(IllegalStateException("FirebaseAuth is not initialized"))
        val db = firestore ?: return Result.failure(IllegalStateException("FirebaseFirestore is not initialized"))

        return try {
            val authResult = authClient.signInWithEmailAndPassword(email.trim(), password).await()
            val firebaseUser = authResult.user ?: return Result.failure(IllegalStateException("Sign in failed"))

            val uid = firebaseUser.uid
            val userDoc = db.collection(FirebaseConfig.COLLECTION_USERS).document(uid).get().await()

            val user = if (userDoc.exists()) {
                parseUserFromDoc(uid, userDoc.data ?: emptyMap(), firebaseUser)
            } else {
                // Fallback: create basic user profile if document doesn't exist yet
                val fallbackUser = User(
                    id = uid,
                    uid = uid,
                    name = firebaseUser.displayName ?: email.substringBefore("@"),
                    email = firebaseUser.email ?: email,
                    role = UserRole.CUSTOMER,
                    accountType = "customer",
                    createdAt = System.currentTimeMillis()
                )
                db.collection(FirebaseConfig.COLLECTION_USERS)
                    .document(uid)
                    .set(fallbackUser.toFirestoreMap(), SetOptions.merge())
                    .await()
                fallbackUser
            }

            Log.i(TAG, "Successfully signed in user: $uid")
            Result.success(user)
        } catch (e: FirebaseAuthException) {
            val readableMessage = mapAuthErrorCode(e.errorCode, e.message)
            Log.e(TAG, "Sign in FirebaseAuthException: ${e.errorCode} - ${e.message}")
            Result.failure(Exception(readableMessage, e))
        } catch (e: Exception) {
            Log.e(TAG, "Sign in failed", e)
            Result.failure(e)
        }
    }

    /**
     * Signs out the currently authenticated user from FirebaseAuth.
     */
    fun signOut() {
        try {
            auth?.signOut()
            Log.i(TAG, "User signed out successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error signing out", e)
        }
    }

    /**
     * Fetches the user document from Firestore for a given UID.
     */
    suspend fun getUserProfile(uid: String): Result<User?> {
        val db = firestore ?: return Result.failure(IllegalStateException("FirebaseFirestore is not initialized"))
        return try {
            val snapshot = db.collection(FirebaseConfig.COLLECTION_USERS).document(uid).get().await()
            if (snapshot.exists()) {
                val user = parseUserFromDoc(uid, snapshot.data ?: emptyMap())
                Result.success(user)
            } else {
                Result.success(null)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching user profile for $uid", e)
            Result.failure(e)
        }
    }

    /**
     * Updates user profile fields in Firestore.
     */
    suspend fun updateUserProfile(user: User): Result<Unit> {
        val db = firestore ?: return Result.failure(IllegalStateException("FirebaseFirestore is not initialized"))
        return try {
            val userMap = user.toFirestoreMap()
            db.collection(FirebaseConfig.COLLECTION_USERS)
                .document(user.id)
                .set(userMap, SetOptions.merge())
                .await()

            if (user.role == UserRole.WORKER) {
                db.collection(FirebaseConfig.COLLECTION_WORKER_PROFILES)
                    .document(user.id)
                    .set(userMap, SetOptions.merge())
                    .await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to update user profile", e)
            Result.failure(e)
        }
    }

    /**
     * Sends a password reset email to the provided address.
     */
    suspend fun sendPasswordResetEmail(email: String): Result<Unit> {
        val authClient = auth ?: return Result.failure(IllegalStateException("FirebaseAuth is not initialized"))
        return try {
            authClient.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Password reset failed for $email", e)
            Result.failure(e)
        }
    }

    private fun parseUserFromDoc(
        id: String,
        map: Map<String, Any?>,
        firebaseUser: FirebaseUser? = null
    ): User {
        val accountType = map["accountType"] as? String ?: "customer"
        val role = when {
            accountType.equals("admin", ignoreCase = true) -> UserRole.ADMIN
            accountType.equals("worker", ignoreCase = true) -> UserRole.WORKER
            else -> UserRole.CUSTOMER
        }
        val rawSkills = map["skills"]
        val skills = when (rawSkills) {
            is List<*> -> rawSkills.filterIsInstance<String>()
            is String -> rawSkills.split(",").map { it.trim() }.filter { it.isNotEmpty() }
            else -> emptyList()
        }

        val city = map["city"] as? String ?: "Delhi NCR"
        val area = map["area"] as? String ?: "Connaught Place"
        val location = map["location"] as? String ?: "$area, $city"

        return User(
            id = id,
            uid = id,
            name = map["name"] as? String ?: firebaseUser?.displayName ?: "User",
            email = map["email"] as? String ?: firebaseUser?.email ?: "",
            phone = map["phone"] as? String ?: firebaseUser?.phoneNumber ?: "",
            role = role,
            accountType = accountType,
            trade = map["trade"] as? String ?: "",
            city = city,
            area = area,
            location = location,
            bio = map["bio"] as? String ?: "",
            skills = skills,
            rating = (map["rating"] as? Number)?.toFloat() ?: 5.0f,
            reviewCount = (map["reviewCount"] as? Number)?.toInt() ?: 0,
            completedJobs = (map["completedJobs"] as? Number)?.toInt() ?: 0,
            followersCount = (map["followersCount"] as? Number)?.toInt() ?: 0,
            followingCount = (map["followingCount"] as? Number)?.toInt() ?: 0,
            profilePhoto = map["profilePhoto"] as? String,
            avatarColorHex = map["avatarColorHex"] as? String ?: if (role == UserRole.WORKER) "#E65100" else "#1A237E",
            isVerified = map["isVerified"] as? Boolean ?: true,
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    private fun mapAuthErrorCode(code: String, fallback: String?): String {
        return when (code) {
            "ERROR_EMAIL_ALREADY_IN_USE", "email-already-in-use" -> "This email address is already registered."
            "ERROR_INVALID_EMAIL", "invalid-email" -> "Please enter a valid email address."
            "ERROR_WEAK_PASSWORD", "weak-password" -> "Password is too weak. Please use at least 6 characters."
            "ERROR_WRONG_PASSWORD", "wrong-password" -> "Incorrect password. Please try again."
            "ERROR_USER_NOT_FOUND", "user-not-found" -> "No account found with this email address."
            "ERROR_USER_DISABLED", "user-disabled" -> "This user account has been disabled."
            "ERROR_TOO_MANY_REQUESTS", "too-many-requests" -> "Too many failed attempts. Please try again later."
            else -> fallback ?: "Authentication error. Please check your credentials."
        }
    }
}
