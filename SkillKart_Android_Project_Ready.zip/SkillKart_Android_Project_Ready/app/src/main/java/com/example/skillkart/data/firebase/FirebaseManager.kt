package com.example.skillkart.data.firebase

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.skillkart.data.model.ChatMessage
import com.example.skillkart.data.model.Comment
import com.example.skillkart.data.model.Complaint
import com.example.skillkart.data.model.FaqItem
import com.example.skillkart.data.model.NotificationItem
import com.example.skillkart.data.model.NotificationType
import com.example.skillkart.data.model.Order
import com.example.skillkart.data.model.OrderStatus
import com.example.skillkart.data.model.Post
import com.example.skillkart.data.model.PostType
import com.example.skillkart.data.model.Review
import com.example.skillkart.data.model.ServicePackage
import com.example.skillkart.data.model.SupportMessage
import com.example.skillkart.data.model.SupportTicket
import com.example.skillkart.data.model.TicketPriority
import com.example.skillkart.data.model.TicketStatus
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import com.example.skillkart.data.util.ImageUtils
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseManager private constructor(private val context: Context) {

    init {
        FirebaseConfig.initialize(context)
    }

    companion object {
        private const val TAG = "SkillKartFirebase"
        @Volatile
        private var instance: FirebaseManager? = null

        fun getInstance(context: Context): FirebaseManager {
            return instance ?: synchronized(this) {
                instance ?: FirebaseManager(context.applicationContext).also { instance = it }
            }
        }
    }

    val isFirebaseAvailable: Boolean
        get() {
            return try {
                FirebaseConfig.initialize(context)
                FirebaseConfig.isInitialized || FirebaseApp.getApps(context).isNotEmpty()
            } catch (e: Exception) {
                false
            }
        }

    private val auth: FirebaseAuth?
        get() = FirebaseConfig.auth

    private val firestore: FirebaseFirestore?
        get() = FirebaseConfig.firestore

    private val storage: FirebaseStorage?
        get() = FirebaseConfig.storage

    fun getCurrentFirebaseUser(): FirebaseUser? = FirebaseConfig.currentUser

    // -------------------------------------------------------------
    // AUTHENTICATION
    // -------------------------------------------------------------

    suspend fun signUp(
        name: String,
        email: String,
        password: String,
        role: UserRole,
        city: String,
        area: String,
        trade: String = ""
    ): Result<User> {
        val authInstance = auth ?: return Result.failure(Exception("Firebase is not initialized. Running in local mode."))
        return try {
            val authResult = authInstance.createUserWithEmailAndPassword(email.trim(), password).await()
            val firebaseUser = authResult.user ?: throw Exception("User creation failed")
            val uid = firebaseUser.uid

            val newUser = User(
                id = uid,
                uid = uid,
                name = name.trim(),
                email = email.trim(),
                phone = "",
                role = role,
                accountType = if (role == UserRole.WORKER) "worker" else "customer",
                trade = if (role == UserRole.WORKER) trade.ifBlank { "Skilled Professional" } else "",
                city = city.trim().ifBlank { "Delhi NCR" },
                area = area.trim().ifBlank { "Connaught Place" },
                location = "${area.trim().ifBlank { "Connaught Place" }}, ${city.trim().ifBlank { "Delhi NCR" }}",
                bio = if (role == UserRole.WORKER) "Skilled $trade ready to take on verified service requests." else "Customer on SkillKart.",
                skills = if (role == UserRole.WORKER && trade.isNotBlank()) listOf(trade, "Quality Guaranteed", "On-Time Service") else emptyList(),
                rating = 5.0f,
                completedJobs = 0,
                followersCount = 0,
                followingCount = 0,
                avatarColorHex = if (role == UserRole.WORKER) "#E65100" else "#1A237E",
                isVerified = true,
                createdAt = System.currentTimeMillis()
            )

            // Save to Firestore
            saveUserProfile(newUser)

            Result.success(newUser)
        } catch (e: Exception) {
            Log.e(TAG, "Sign up error", e)
            Result.failure(Exception(getFriendlyErrorMessage(e)))
        }
    }

    suspend fun signIn(email: String, password: String): Result<User> {
        val authInstance = auth ?: return Result.failure(Exception("Firebase is not initialized. Running in local mode."))
        return try {
            val authResult = authInstance.signInWithEmailAndPassword(email.trim(), password).await()
            val firebaseUser = authResult.user ?: throw Exception("Login failed")
            val uid = firebaseUser.uid

            val userDoc = getUserProfile(uid)
            if (userDoc != null) {
                Result.success(userDoc)
            } else {
                // Create minimal profile if none exists
                val fallbackUser = User(
                    id = uid,
                    uid = uid,
                    name = firebaseUser.displayName ?: email.substringBefore("@"),
                    email = email.trim(),
                    role = UserRole.CUSTOMER,
                    accountType = "customer"
                )
                saveUserProfile(fallbackUser)
                Result.success(fallbackUser)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Sign in error", e)
            Result.failure(Exception(getFriendlyErrorMessage(e)))
        }
    }

    fun signOut() {
        try {
            auth?.signOut()
        } catch (e: Exception) {
            Log.w(TAG, "Sign out error: ${e.message}")
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> {
        val authInstance = auth ?: return Result.failure(Exception("Firebase is not initialized."))
        return try {
            authInstance.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(Exception(getFriendlyErrorMessage(e)))
        }
    }

    // -------------------------------------------------------------
    // USERS COLLECTION
    // -------------------------------------------------------------

    suspend fun saveUserProfile(user: User): Boolean {
        val db = firestore ?: return false
        return try {
            val userMap = user.toFirestoreMap()
            db.collection("users").document(user.id).set(userMap, SetOptions.merge()).await()
            if (user.role == UserRole.WORKER) {
                db.collection("workerProfiles").document(user.id).set(userMap, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to save user profile", e)
            false
        }
    }

    suspend fun getUserProfile(uid: String): User? {
        val db = firestore ?: return null
        return try {
            val snapshot = db.collection("users").document(uid).get().await()
            if (snapshot.exists()) {
                parseUser(snapshot.id, snapshot.data ?: emptyMap())
            } else null
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching user profile", e)
            null
        }
    }

    fun usersFlow(): Flow<List<User>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("users").addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "users listen error: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val users = snapshot.documents.mapNotNull { doc ->
                    doc.data?.let { parseUser(doc.id, it) }
                }
                trySend(users)
            }
        }
        awaitClose { registration.remove() }
    }

    private fun parseUser(id: String, map: Map<String, Any?>): User {
        val roleStr = map["accountType"] as? String ?: "customer"
        val role = if (roleStr.equals("worker", ignoreCase = true)) UserRole.WORKER else UserRole.CUSTOMER
        val city = map["city"] as? String ?: "Delhi NCR"
        val area = map["area"] as? String ?: "Connaught Place"
        val location = map["location"] as? String ?: "$area, $city"
        val skills = (map["skills"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()

        return User(
            id = id,
            uid = id,
            name = map["name"] as? String ?: "User",
            email = map["email"] as? String ?: "",
            phone = map["phone"] as? String ?: "",
            role = role,
            accountType = roleStr,
            trade = map["trade"] as? String ?: "",
            city = city,
            area = area,
            location = location,
            bio = map["bio"] as? String ?: "",
            skills = skills,
            rating = ((map["rating"] as? Number)?.toFloat()) ?: 5.0f,
            reviewCount = ((map["reviewCount"] as? Number)?.toInt()) ?: 0,
            completedJobs = ((map["completedJobs"] as? Number)?.toInt()) ?: 0,
            followersCount = ((map["followersCount"] as? Number)?.toInt()) ?: 0,
            followingCount = ((map["followingCount"] as? Number)?.toInt()) ?: 0,
            profilePhoto = map["profilePhoto"] as? String,
            avatarColorHex = map["avatarColorHex"] as? String ?: if (role == UserRole.WORKER) "#E65100" else "#1A237E",
            isVerified = (map["isVerified"] as? Boolean) ?: true,
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    // -------------------------------------------------------------
    // SERVICES COLLECTION
    // -------------------------------------------------------------

    suspend fun createService(service: ServicePackage): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (service.id.isNotBlank()) service.id else db.collection("services").document().id
            val finalService = service.copy(id = docId)
            db.collection("services").document(docId).set(finalService.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating service", e)
            false
        }
    }

    suspend fun updateService(service: ServicePackage): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("services").document(service.id).set(service.toFirestoreMap(), SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating service", e)
            false
        }
    }

    suspend fun deleteService(serviceId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("services").document(serviceId).delete().await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting service", e)
            false
        }
    }

    fun servicesFlow(): Flow<List<ServicePackage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("services")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "services listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parseService(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    /**
     * Executes a targeted Firestore query filtering services by category and sorting by createdAt,
     * applying text and numerical filters reactively.
     */
    fun searchServicesFlow(
        category: String = "All",
        searchQuery: String = "",
        maxPrice: Int = 100000,
        minRating: Float = 0f
    ): Flow<List<ServicePackage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        var query: Query = db.collection("services")
        if (category.isNotBlank() && !category.equals("All", ignoreCase = true)) {
            query = query.whereEqualTo("category", category)
        }

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                Log.w(TAG, "searchServicesFlow listen error: ${error.message}")
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val list = snapshot.documents.mapNotNull { doc ->
                    doc.data?.let { parseService(doc.id, it) }
                }.filter { srv ->
                    val matchQuery = searchQuery.isBlank() ||
                            srv.title.contains(searchQuery, ignoreCase = true) ||
                            srv.workerName.contains(searchQuery, ignoreCase = true) ||
                            srv.category.contains(searchQuery, ignoreCase = true) ||
                            srv.workerLocation.contains(searchQuery, ignoreCase = true) ||
                            srv.description.contains(searchQuery, ignoreCase = true) ||
                            srv.inclusions.any { it.contains(searchQuery, ignoreCase = true) }
                    val matchPrice = srv.priceInr <= maxPrice
                    val matchRating = srv.workerRating >= minRating
                    matchQuery && matchPrice && matchRating
                }
                trySend(list)
            }
        }
        awaitClose { registration.remove() }
    }

    /**
     * Performs a one-shot query to Firestore for services with specified category and text query.
     */
    suspend fun queryServicesFromFirestore(
        category: String = "All",
        searchQuery: String = ""
    ): List<ServicePackage> {
        val db = firestore ?: return emptyList()
        return try {
            var query: Query = db.collection("services")
            if (category.isNotBlank() && !category.equals("All", ignoreCase = true)) {
                query = query.whereEqualTo("category", category)
            }
            val snapshot = query.get().await()
            snapshot.documents.mapNotNull { doc ->
                doc.data?.let { parseService(doc.id, it) }
            }.filter { srv ->
                searchQuery.isBlank() ||
                        srv.title.contains(searchQuery, ignoreCase = true) ||
                        srv.workerName.contains(searchQuery, ignoreCase = true) ||
                        srv.description.contains(searchQuery, ignoreCase = true) ||
                        srv.inclusions.any { it.contains(searchQuery, ignoreCase = true) }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying services from Firestore: ${e.message}")
            emptyList()
        }
    }

    private fun parseService(id: String, map: Map<String, Any?>): ServicePackage {
        val inclusions = (map["inclusions"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        val images = (map["images"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        val price = (map["price"] as? Number)?.toInt() ?: (map["priceInr"] as? Number)?.toInt() ?: 0
        val completion = map["estimatedDays"] as? String ?: map["completionTime"] as? String ?: "1-2 Days"
        val active = (map["active"] as? Boolean) ?: (map["isActive"] as? Boolean) ?: true

        return ServicePackage(
            id = id,
            workerId = map["workerId"] as? String ?: "",
            workerName = map["workerName"] as? String ?: "",
            workerTrade = map["workerTrade"] as? String ?: "",
            workerRating = ((map["workerRating"] as? Number)?.toFloat()) ?: 5.0f,
            workerLocation = map["workerLocation"] as? String ?: "Delhi NCR",
            title = map["title"] as? String ?: "",
            category = map["category"] as? String ?: "Other",
            priceInr = price,
            completionTime = completion,
            serviceRadius = map["serviceRadius"] as? String ?: "Within 10 km",
            maxVisits = map["maxVisits"] as? String ?: "1-2 on-site visits",
            description = map["description"] as? String ?: "",
            inclusions = inclusions,
            images = images,
            isActive = active,
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    // -------------------------------------------------------------
    // POSTS COLLECTION
    // -------------------------------------------------------------

    suspend fun createPost(post: Post): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (post.id.isNotBlank()) post.id else db.collection("posts").document().id
            val finalPost = post.copy(id = docId)
            db.collection("posts").document(docId).set(finalPost.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating post", e)
            false
        }
    }

    suspend fun toggleLikePost(postId: String, userId: String, isCurrentlyLiked: Boolean): Boolean {
        val db = firestore ?: return false
        return try {
            val docRef = db.collection("posts").document(postId)
            if (isCurrentlyLiked) {
                docRef.update(
                    "likedBy", FieldValue.arrayRemove(userId),
                    "likesCount", FieldValue.increment(-1)
                ).await()
            } else {
                docRef.update(
                    "likedBy", FieldValue.arrayUnion(userId),
                    "likesCount", FieldValue.increment(1)
                ).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling like", e)
            false
        }
    }

    suspend fun addComment(postId: String, comment: Comment): Boolean {
        val db = firestore ?: return false
        return try {
            val commentId = db.collection("posts").document(postId).collection("comments").document().id
            val finalComment = comment.copy(id = commentId, postId = postId)
            db.collection("posts").document(postId).collection("comments").document(commentId)
                .set(finalComment.toFirestoreMap()).await()

            db.collection("posts").document(postId).update("commentsCount", FieldValue.increment(1)).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error adding comment", e)
            false
        }
    }

    fun postsFlow(): Flow<List<Post>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("posts")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "posts listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parsePost(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    private fun parsePost(id: String, map: Map<String, Any?>): Post {
        val likedBy = (map["likedBy"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        val followedBy = (map["followedBy"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        val tags = (map["tags"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        val typeStr = map["type"] as? String ?: PostType.WORK_SHOWCASE.name
        val postType = try { PostType.valueOf(typeStr) } catch (e: Exception) { PostType.WORK_SHOWCASE }

        return Post(
            id = id,
            workerId = map["workerId"] as? String ?: "",
            workerName = map["workerName"] as? String ?: "",
            workerTrade = map["workerTrade"] as? String ?: "",
            workerAvatarColor = map["workerAvatarColor"] as? String ?: "#E65100",
            workerLocation = map["workerLocation"] as? String ?: "Delhi, NCR",
            workerRating = ((map["workerRating"] as? Number)?.toFloat()) ?: 4.9f,
            type = postType,
            title = map["title"] as? String ?: "",
            caption = map["caption"] as? String ?: "",
            category = map["category"] as? String ?: "General",
            imageUrl = map["imageUrl"] as? String,
            videoUrl = map["videoUrl"] as? String,
            tags = tags,
            linkedServiceId = map["linkedServiceId"] as? String,
            linkedServiceTitle = map["linkedServiceTitle"] as? String,
            linkedPriceInr = (map["linkedPriceInr"] as? Number)?.toInt(),
            beforeDescription = map["beforeDescription"] as? String,
            afterDescription = map["afterDescription"] as? String,
            likesCount = (map["likesCount"] as? Number)?.toInt() ?: likedBy.size,
            isLikedByMe = false,
            likedBy = likedBy,
            commentsCount = (map["commentsCount"] as? Number)?.toInt() ?: 0,
            sharesCount = (map["sharesCount"] as? Number)?.toInt() ?: 0,
            isFollowedByMe = false,
            followedBy = followedBy,
            timestamp = map["timestamp"] as? String ?: "Recent",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    // -------------------------------------------------------------
    // ORDERS COLLECTION
    // -------------------------------------------------------------

    suspend fun createOrder(order: Order): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (order.id.isNotBlank()) order.id else db.collection("orders").document().id
            val finalOrder = order.copy(id = docId, status = OrderStatus.PENDING)
            db.collection("orders").document(docId).set(finalOrder.toFirestoreMap()).await()

            // Also create a notification for the worker
            createNotification(
                NotificationItem(
                    id = UUID.randomUUID().toString(),
                    userId = order.workerId,
                    type = NotificationType.BOOKING_NEW,
                    title = "New Booking Request! 🎉",
                    message = "${order.customerName} requested '${order.serviceTitle}' (₹${order.priceInr})",
                    relatedId = docId,
                    timestamp = "Just now",
                    createdAt = System.currentTimeMillis()
                )
            )

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating order", e)
            false
        }
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: OrderStatus, order: Order? = null): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("orders").document(orderId).update("status", newStatus.name).await()

            if (order != null) {
                val notifType = when (newStatus) {
                    OrderStatus.ACCEPTED -> NotificationType.BOOKING_ACCEPTED
                    OrderStatus.CANCELLED -> NotificationType.BOOKING_REJECTED
                    OrderStatus.COMPLETED -> NotificationType.ORDER_COMPLETED
                    else -> NotificationType.BOOKING_ACCEPTED
                }
                val title = when (newStatus) {
                    OrderStatus.ACCEPTED -> "Booking Accepted! ✅"
                    OrderStatus.IN_PROGRESS -> "Work in Progress! 🔨"
                    OrderStatus.COMPLETED -> "Service Completed! ⭐"
                    OrderStatus.CANCELLED -> "Booking Cancelled ℹ️"
                    else -> "Booking Status Updated"
                }
                val msg = when (newStatus) {
                    OrderStatus.ACCEPTED -> "Worker ${order.workerName} accepted your request for '${order.serviceTitle}'."
                    OrderStatus.IN_PROGRESS -> "${order.workerName} has started work on your service."
                    OrderStatus.COMPLETED -> "${order.workerName} marked '${order.serviceTitle}' as completed. Please leave a review!"
                    OrderStatus.CANCELLED -> "The booking for '${order.serviceTitle}' was cancelled."
                    else -> "Status: ${newStatus.displayName}"
                }
                createNotification(
                    NotificationItem(
                        id = UUID.randomUUID().toString(),
                        userId = order.customerId,
                        type = notifType,
                        title = title,
                        message = msg,
                        relatedId = orderId,
                        timestamp = "Just now",
                        createdAt = System.currentTimeMillis()
                    )
                )

                // If completed, increment worker's completedJobs
                if (newStatus == OrderStatus.COMPLETED) {
                    db.collection("users").document(order.workerId)
                        .update("completedJobs", FieldValue.increment(1))
                }
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status", e)
            false
        }
    }

    fun ordersFlow(): Flow<List<Order>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("orders")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "orders listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parseOrder(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    private fun parseOrder(id: String, map: Map<String, Any?>): Order {
        val statusStr = map["status"] as? String ?: OrderStatus.PENDING.name
        val status = try { OrderStatus.valueOf(statusStr) } catch (e: Exception) { OrderStatus.PENDING }

        return Order(
            id = id,
            serviceId = map["serviceId"] as? String ?: "",
            serviceTitle = map["serviceTitle"] as? String ?: "",
            serviceCategory = map["serviceCategory"] as? String ?: "Other",
            customerId = map["customerId"] as? String ?: "",
            customerName = map["customerName"] as? String ?: "",
            customerPhone = map["customerPhone"] as? String ?: "",
            workerId = map["workerId"] as? String ?: "",
            workerName = map["workerName"] as? String ?: "",
            workerTrade = map["workerTrade"] as? String ?: "",
            priceInr = (map["priceInr"] as? Number)?.toInt() ?: 0,
            status = status,
            requirementDetails = map["requirementDetails"] as? String ?: "",
            serviceAddress = map["serviceAddress"] as? String ?: "",
            preferredDate = map["preferredDate"] as? String ?: "",
            timeSlot = map["timeSlot"] as? String ?: "",
            instructions = map["instructions"] as? String ?: "",
            imageUrl = map["imageUrl"] as? String,
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            hasReview = (map["hasReview"] as? Boolean) ?: false
        )
    }

    // -------------------------------------------------------------
    // CHATS & MESSAGES COLLECTION
    // -------------------------------------------------------------

    suspend fun sendMessage(message: ChatMessage): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (message.id.isNotBlank()) message.id else db.collection("messages").document().id
            val finalMsg = message.copy(id = docId)
            db.collection("messages").document(docId).set(finalMsg.toFirestoreMap()).await()

            // Update chat meta
            val chatMeta = mapOf(
                "lastMessage" to message.text,
                "lastTimestamp" to message.timestamp,
                "participants" to listOf(message.senderId, message.receiverId),
                "updatedAt" to System.currentTimeMillis()
            )
            db.collection("chats").document(message.conversationId).set(chatMeta, SetOptions.merge()).await()

            // Send notification to receiver
            createNotification(
                NotificationItem(
                    id = UUID.randomUUID().toString(),
                    userId = message.receiverId,
                    type = NotificationType.NEW_MESSAGE,
                    title = "New Message from ${message.senderName}",
                    message = message.text.take(60),
                    relatedId = message.conversationId,
                    timestamp = "Just now",
                    createdAt = System.currentTimeMillis()
                )
            )

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error sending message", e)
            false
        }
    }

    fun messagesFlow(): Flow<List<ChatMessage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "messages listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parseMessage(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    private fun parseMessage(id: String, map: Map<String, Any?>): ChatMessage {
        return ChatMessage(
            id = id,
            conversationId = map["conversationId"] as? String ?: "",
            senderId = map["senderId"] as? String ?: "",
            senderName = map["senderName"] as? String ?: "",
            receiverId = map["receiverId"] as? String ?: "",
            text = map["text"] as? String ?: "",
            imageUrl = map["imageUrl"] as? String,
            orderIdRef = map["orderIdRef"] as? String,
            timestamp = (map["timestamp"] as? Number)?.toLong() ?: System.currentTimeMillis(),
            formattedTime = map["formattedTime"] as? String ?: "Recent",
            isRead = (map["isRead"] as? Boolean) ?: true
        )
    }

    // -------------------------------------------------------------
    // REVIEWS & RATINGS COLLECTION
    // -------------------------------------------------------------

    suspend fun createReview(review: Review): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (review.id.isNotBlank()) review.id else db.collection("reviews").document().id
            val finalReview = review.copy(id = docId)
            db.collection("reviews").document(docId).set(finalReview.toFirestoreMap()).await()

            // Mark order as reviewed
            if (review.orderId.isNotBlank()) {
                db.collection("orders").document(review.orderId).update("hasReview", true).await()
            }

            // Update worker rating and reviewCount in worker user profile
            val workerDoc = db.collection("users").document(review.workerId).get().await()
            if (workerDoc.exists()) {
                val currentRating = (workerDoc.getDouble("rating") ?: 5.0).toFloat()
                val currentReviews = (workerDoc.getLong("reviewCount") ?: 0L).toInt()
                val newReviewCount = currentReviews + 1
                val newAvgRating = ((currentRating * currentReviews) + review.rating) / newReviewCount
                val roundedRating = Math.round(newAvgRating * 10.0) / 10.0

                db.collection("users").document(review.workerId).update(
                    mapOf(
                        "rating" to roundedRating,
                        "reviewCount" to newReviewCount
                    )
                ).await()
            }

            // Notification to worker
            createNotification(
                NotificationItem(
                    id = UUID.randomUUID().toString(),
                    userId = review.workerId,
                    type = NotificationType.REVIEW_RECEIVED,
                    title = "New ${review.rating}⭐ Review Received!",
                    message = "${review.customerName}: \"${review.comment.take(50)}\"",
                    relatedId = docId,
                    timestamp = "Just now",
                    createdAt = System.currentTimeMillis()
                )
            )

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating review", e)
            false
        }
    }

    fun reviewsFlow(): Flow<List<Review>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("reviews")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "reviews listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parseReview(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    private fun parseReview(id: String, map: Map<String, Any?>): Review {
        val tags = (map["tags"] as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
        return Review(
            id = id,
            workerId = map["workerId"] as? String ?: "",
            customerId = map["customerId"] as? String ?: "",
            customerName = map["customerName"] as? String ?: "Customer",
            serviceId = map["serviceId"] as? String ?: "",
            serviceTitle = map["serviceTitle"] as? String ?: "",
            orderId = map["orderId"] as? String ?: "",
            rating = ((map["rating"] as? Number)?.toInt()) ?: 5,
            comment = map["comment"] as? String ?: "",
            tags = tags,
            imageUrl = map["imageUrl"] as? String,
            date = map["date"] as? String ?: "Today",
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    // -------------------------------------------------------------
    // FOLLOW SYSTEM
    // -------------------------------------------------------------

    suspend fun toggleFollowWorker(customerId: String, customerName: String, workerId: String, isCurrentlyFollowing: Boolean): Boolean {
        val db = firestore ?: return false
        return try {
            val followDocId = "${customerId}_$workerId"
            val followDoc = db.collection("follows").document(followDocId)

            if (isCurrentlyFollowing) {
                followDoc.delete().await()
                db.collection("users").document(workerId).update("followersCount", FieldValue.increment(-1))
                db.collection("users").document(customerId).update("followingCount", FieldValue.increment(-1))
            } else {
                val followData = mapOf(
                    "customerId" to customerId,
                    "workerId" to workerId,
                    "createdAt" to System.currentTimeMillis()
                )
                followDoc.set(followData).await()
                db.collection("users").document(workerId).update("followersCount", FieldValue.increment(1))
                db.collection("users").document(customerId).update("followingCount", FieldValue.increment(1))

                createNotification(
                    NotificationItem(
                        id = UUID.randomUUID().toString(),
                        userId = workerId,
                        type = NotificationType.NEW_FOLLOWER,
                        title = "New Follower! 👤",
                        message = "$customerName started following your work profile.",
                        relatedId = customerId,
                        timestamp = "Just now",
                        createdAt = System.currentTimeMillis()
                    )
                )
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling follow", e)
            false
        }
    }

    // -------------------------------------------------------------
    // NOTIFICATIONS
    // -------------------------------------------------------------

    suspend fun createNotification(notification: NotificationItem): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (notification.id.isNotBlank()) notification.id else db.collection("notifications").document().id
            val finalNotif = notification.copy(id = docId)
            db.collection("notifications").document(docId).set(finalNotif.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating notification", e)
            false
        }
    }

    suspend fun markNotificationAsRead(notifId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("notifications").document(notifId).update("isRead", true).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun notificationsFlow(userId: String): Flow<List<NotificationItem>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("notifications")
            .whereEqualTo("userId", userId)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "notifications listen error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        doc.data?.let { parseNotification(doc.id, it) }
                    }
                    trySend(list)
                }
            }
        awaitClose { registration.remove() }
    }

    private fun parseNotification(id: String, map: Map<String, Any?>): NotificationItem {
        val typeStr = map["type"] as? String ?: NotificationType.BOOKING_NEW.name
        val type = try { NotificationType.valueOf(typeStr) } catch (e: Exception) { NotificationType.BOOKING_NEW }
        return NotificationItem(
            id = id,
            userId = map["userId"] as? String ?: "",
            type = type,
            title = map["title"] as? String ?: "",
            message = map["message"] as? String ?: "",
            relatedId = map["relatedId"] as? String,
            timestamp = map["timestamp"] as? String ?: "Just now",
            isRead = (map["isRead"] as? Boolean) ?: false,
            createdAt = (map["createdAt"] as? Number)?.toLong() ?: System.currentTimeMillis()
        )
    }

    // -------------------------------------------------------------
    // IMAGE UPLOADS
    // -------------------------------------------------------------

    suspend fun uploadImageUri(uri: Uri, folder: String = "images"): Result<String> {
        val storageRef = storage
        return try {
            val compressedBytes = ImageUtils.compressImageUri(context, uri)
                ?: throw Exception("Could not process selected image.")

            if (storageRef != null && isFirebaseAvailable) {
                val fileName = "${folder}/${UUID.randomUUID()}.jpg"
                val fileRef = storageRef.reference.child(fileName)
                fileRef.putBytes(compressedBytes).await()
                val downloadUrl = fileRef.downloadUrl.await().toString()
                Result.success(downloadUrl)
            } else {
                // Fallback to data URL
                val base64 = ImageUtils.uriToBase64DataUrl(context, uri)
                    ?: throw Exception("Failed to encode image")
                Result.success(base64)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Storage upload exception, using fallback: ${e.message}")
            val fallback = ImageUtils.uriToBase64DataUrl(context, uri)
            if (fallback != null) {
                Result.success(fallback)
            } else {
                Result.failure(Exception("Image processing failed: ${e.localizedMessage}"))
            }
        }
    }

    // -------------------------------------------------------------
    // CONVENIENCE FLOWS & HELPERS FOR REPOSITORY
    // -------------------------------------------------------------

    val allUsersFlow: Flow<List<User>> get() = usersFlow()
    val allServicesFlow: Flow<List<ServicePackage>> get() = servicesFlow()
    val allPostsFlow: Flow<List<Post>> get() = postsFlow()
    val allOrdersFlow: Flow<List<Order>> get() = ordersFlow()
    val allReviewsFlow: Flow<List<Review>> get() = reviewsFlow()

    suspend fun updateUserProfile(
        uid: String,
        name: String,
        city: String,
        area: String,
        bio: String,
        trade: String,
        skills: List<String>,
        accountType: String
    ): Boolean {
        val db = firestore ?: return false
        return try {
            val updates = mapOf(
                "name" to name,
                "city" to city,
                "area" to area,
                "location" to "$area, $city",
                "bio" to bio,
                "trade" to trade,
                "skills" to skills,
                "accountType" to accountType
            )
            db.collection("users").document(uid).set(updates, SetOptions.merge()).await()
            if (accountType.equals("worker", ignoreCase = true)) {
                db.collection("workerProfiles").document(uid).set(updates, SetOptions.merge()).await()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating profile", e)
            false
        }
    }

    suspend fun updateOrder(order: Order): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("orders").document(order.id).set(order.toFirestoreMap(), SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun submitReview(review: Review): Boolean {
        return createReview(review)
    }

    suspend fun updateWorkerRating(workerId: String, rating: Float, reviewCount: Int, completedJobs: Int): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(workerId).update(
                mapOf(
                    "rating" to rating.toDouble(),
                    "reviewCount" to reviewCount,
                    "completedJobs" to completedJobs
                )
            ).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun likePost(postId: String, newCount: Int): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("posts").document(postId).update("likesCount", newCount).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun toggleFollow(workerId: String, currentFollowState: Boolean): Boolean {
        val currentUid = auth?.currentUser?.uid ?: return false
        val currentName = auth?.currentUser?.displayName ?: "User"
        return toggleFollowWorker(currentUid, currentName, workerId, currentFollowState)
    }

    suspend fun addComment(comment: Comment): Boolean {
        return addComment(comment.postId, comment)
    }

    suspend fun addNotification(notification: NotificationItem): Boolean {
        return createNotification(notification)
    }

    // -------------------------------------------------------------
    // SUPPORT TICKETS & REAL-TIME SUPPORT CHAT
    // -------------------------------------------------------------

    fun getSupportTicketsFlow(): Flow<List<SupportTicket>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("supportTickets")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "SupportTickets listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val tickets = snapshot.documents.mapNotNull { doc ->
                        try {
                            val map = doc.data ?: return@mapNotNull null
                            val statusStr = map["status"] as? String ?: "OPEN"
                            val priorityStr = map["priority"] as? String ?: "MEDIUM"
                            SupportTicket(
                                id = doc.id,
                                ticketId = doc.id,
                                userId = map["userId"] as? String ?: "",
                                userName = map["userName"] as? String ?: "",
                                userEmail = map["userEmail"] as? String ?: "",
                                userRole = map["userRole"] as? String ?: "customer",
                                subject = map["subject"] as? String ?: "",
                                category = map["category"] as? String ?: "General Support",
                                status = try { TicketStatus.valueOf(statusStr) } catch (e: Exception) { TicketStatus.OPEN },
                                priority = try { TicketPriority.valueOf(priorityStr) } catch (e: Exception) { TicketPriority.MEDIUM },
                                relatedOrderId = map["relatedOrderId"] as? String,
                                relatedOrderTitle = map["relatedOrderTitle"] as? String,
                                internalNotes = map["internalNotes"] as? String ?: "",
                                createdAt = (map["createdAt"] as? Long) ?: System.currentTimeMillis(),
                                updatedAt = (map["updatedAt"] as? Long) ?: System.currentTimeMillis(),
                                lastMessage = map["lastMessage"] as? String ?: "",
                                unreadUserCount = (map["unreadUserCount"] as? Long)?.toInt() ?: 0,
                                unreadAdminCount = (map["unreadAdminCount"] as? Long)?.toInt() ?: 0
                            )
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed parsing support ticket doc: ${doc.id}", e)
                            null
                        }
                    }
                    trySend(tickets)
                }
            }

        awaitClose { listener.remove() }
    }

    fun getSupportMessagesFlow(ticketId: String): Flow<List<SupportMessage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("supportMessages")
            .whereEqualTo("ticketId", ticketId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "SupportMessages listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { doc ->
                        try {
                            val map = doc.data ?: return@mapNotNull null
                            SupportMessage(
                                id = doc.id,
                                messageId = doc.id,
                                ticketId = map["ticketId"] as? String ?: ticketId,
                                senderId = map["senderId"] as? String ?: "",
                                senderName = map["senderName"] as? String ?: "",
                                senderRole = map["senderRole"] as? String ?: "user",
                                message = map["message"] as? String ?: "",
                                imageUrl = map["imageUrl"] as? String,
                                createdAt = (map["createdAt"] as? Long) ?: System.currentTimeMillis(),
                                read = (map["read"] as? Boolean) ?: false,
                                formattedTime = map["formattedTime"] as? String ?: "Just now"
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }.sortedBy { it.createdAt }
                    trySend(messages)
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun createSupportTicket(ticket: SupportTicket): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (ticket.id.isNotBlank()) ticket.id else UUID.randomUUID().toString().take(8).uppercase()
            val finalTicket = ticket.copy(id = docId, ticketId = docId)
            db.collection("supportTickets").document(docId).set(finalTicket.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating support ticket", e)
            false
        }
    }

    suspend fun updateSupportTicket(ticketId: String, updates: Map<String, Any?>): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("supportTickets").document(ticketId).update(updates).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating support ticket $ticketId", e)
            false
        }
    }

    suspend fun sendSupportMessage(message: SupportMessage): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (message.id.isNotBlank()) message.id else UUID.randomUUID().toString()
            val finalMsg = message.copy(id = docId, messageId = docId)
            db.collection("supportMessages").document(docId).set(finalMsg.toFirestoreMap()).await()

            // Update ticket's lastMessage, updatedAt, and unread count
            val isFromAdmin = message.isFromSupport
            val ticketRef = db.collection("supportTickets").document(message.ticketId)
            ticketRef.update(
                mapOf(
                    "lastMessage" to message.message,
                    "updatedAt" to message.createdAt,
                    (if (isFromAdmin) "unreadUserCount" else "unreadAdminCount") to FieldValue.increment(1)
                )
            ).await()

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error sending support message", e)
            false
        }
    }

    suspend fun markSupportMessagesRead(ticketId: String, forUser: Boolean): Boolean {
        val db = firestore ?: return false
        return try {
            val ticketRef = db.collection("supportTickets").document(ticketId)
            val fieldToReset = if (forUser) "unreadUserCount" else "unreadAdminCount"
            ticketRef.update(fieldToReset, 0).await()

            // Mark unread messages
            val roleToMark = if (forUser) listOf("admin", "support") else listOf("user", "customer", "worker")
            val msgsSnapshot = db.collection("supportMessages")
                .whereEqualTo("ticketId", ticketId)
                .whereEqualTo("read", false)
                .get().await()

            for (doc in msgsSnapshot.documents) {
                val role = doc.getString("senderRole") ?: ""
                if (roleToMark.contains(role.lowercase())) {
                    doc.reference.update("read", true)
                }
            }
            true
        } catch (e: Exception) {
            Log.w(TAG, "Error marking support messages read", e)
            false
        }
    }

    // -------------------------------------------------------------
    // COMPLAINTS
    // -------------------------------------------------------------

    fun getComplaintsFlow(): Flow<List<Complaint>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("complaints")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Complaints listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        try {
                            val map = doc.data ?: return@mapNotNull null
                            Complaint(
                                id = doc.id,
                                complaintId = doc.id,
                                ticketId = map["ticketId"] as? String ?: "",
                                userId = map["userId"] as? String ?: "",
                                userName = map["userName"] as? String ?: "",
                                category = map["category"] as? String ?: "Other",
                                orderId = map["orderId"] as? String,
                                orderTitle = map["orderTitle"] as? String,
                                details = map["details"] as? String ?: "",
                                evidenceImageUrl = map["evidenceImageUrl"] as? String,
                                status = map["status"] as? String ?: "Under Investigation",
                                createdAt = (map["createdAt"] as? Long) ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(list)
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun createComplaint(complaint: Complaint): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (complaint.id.isNotBlank()) complaint.id else "CMP-${System.currentTimeMillis().toString().takeLast(6)}"
            val finalComplaint = complaint.copy(id = docId, complaintId = docId)
            db.collection("complaints").document(docId).set(finalComplaint.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error creating complaint", e)
            false
        }
    }

    // -------------------------------------------------------------
    // FAQS
    // -------------------------------------------------------------

    fun getFaqsFlow(): Flow<List<FaqItem>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = db.collection("faqs")
            .orderBy("orderIndex", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "FAQs listener error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = snapshot.documents.mapNotNull { doc ->
                        try {
                            val map = doc.data ?: return@mapNotNull null
                            FaqItem(
                                id = doc.id,
                                question = map["question"] as? String ?: "",
                                answer = map["answer"] as? String ?: "",
                                category = map["category"] as? String ?: "General",
                                orderIndex = (map["orderIndex"] as? Long)?.toInt() ?: 0,
                                createdAt = (map["createdAt"] as? Long) ?: System.currentTimeMillis()
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(list)
                }
            }

        awaitClose { listener.remove() }
    }

    suspend fun saveFaqItem(faq: FaqItem): Boolean {
        val db = firestore ?: return false
        return try {
            val docId = if (faq.id.isNotBlank()) faq.id else UUID.randomUUID().toString()
            val finalFaq = faq.copy(id = docId)
            db.collection("faqs").document(docId).set(finalFaq.toFirestoreMap()).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error saving FAQ", e)
            false
        }
    }

    suspend fun deleteFaqItem(faqId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("faqs").document(faqId).delete().await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting FAQ", e)
            false
        }
    }

    suspend fun seedInitialFirestoreDataIfEmpty(
        users: List<User>,
        services: List<ServicePackage>,
        posts: List<Post>,
        orders: List<Order>,
        reviews: List<Review>
    ) {
        val db = firestore ?: return
        try {
            val userCheck = db.collection("users").limit(1).get().await()
            if (userCheck.isEmpty) {
                // Seed users & workerProfiles
                users.forEach { u ->
                    db.collection("users").document(u.id).set(u.toFirestoreMap())
                    if (u.role == UserRole.WORKER) {
                        db.collection("workerProfiles").document(u.id).set(u.toFirestoreMap())
                    }
                }
                // Seed services
                services.forEach { s ->
                    db.collection("services").document(s.id).set(s.toFirestoreMap())
                }
                // Seed posts
                posts.forEach { p ->
                    db.collection("posts").document(p.id).set(p.toFirestoreMap())
                }
                // Seed orders
                orders.forEach { o ->
                    db.collection("orders").document(o.id).set(o.toFirestoreMap())
                }
                // Seed reviews
                reviews.forEach { r ->
                    db.collection("reviews").document(r.id).set(r.toFirestoreMap())
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Seeding Firestore notice: ${e.message}")
        }
    }

    // -------------------------------------------------------------
    // USER FRIENDLY ERROR MESSAGES
    // -------------------------------------------------------------

    fun getFriendlyErrorMessage(e: Throwable): String {
        val msg = e.message ?: ""
        return when {
            msg.contains("The email address is already in use", ignoreCase = true) || msg.contains("ERROR_EMAIL_ALREADY_IN_USE", ignoreCase = true) ->
                "This email address is already registered. Please login instead."
            msg.contains("The email address is badly formatted", ignoreCase = true) || msg.contains("ERROR_INVALID_EMAIL", ignoreCase = true) ->
                "Please enter a valid email address."
            msg.contains("The password is invalid or the user does not have a password", ignoreCase = true) ||
            msg.contains("wrong-password", ignoreCase = true) || msg.contains("ERROR_WRONG_PASSWORD", ignoreCase = true) ->
                "Incorrect password. Please try again or tap 'Forgot Password'."
            msg.contains("There is no user record corresponding to this identifier", ignoreCase = true) ||
            msg.contains("user-not-found", ignoreCase = true) ->
                "No account found with this email. Please sign up first."
            msg.contains("Password should be at least 6 characters", ignoreCase = true) || msg.contains("WEAK_PASSWORD", ignoreCase = true) ->
                "Password must be at least 6 characters long."
            msg.contains("network error", ignoreCase = true) || msg.contains("offline", ignoreCase = true) ->
                "Network connection problem. Please check your internet connection."
            msg.contains("PERMISSION_DENIED", ignoreCase = true) ->
                "Access permission denied. Please sign in again."
            else -> msg.ifBlank { "An unexpected error occurred. Please try again." }
        }
    }
}
