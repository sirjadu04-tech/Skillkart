package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.skillkart.data.model.UserRole
import com.example.skillkart.ui.components.CommentsSheet
import com.example.skillkart.ui.components.EditProfileDialog
import com.example.skillkart.ui.components.NotificationsSheet
import com.example.skillkart.ui.components.ReviewDialog
import com.example.skillkart.ui.components.SkillKartBottomNav
import com.example.skillkart.ui.components.SkillKartTopBar
import com.example.skillkart.ui.screens.admin.AdminSupportScreen
import com.example.skillkart.ui.screens.auth.AuthScreen
import com.example.skillkart.ui.screens.booking.BookingSheet
import com.example.skillkart.ui.screens.challenges.ChallengesScreen
import com.example.skillkart.ui.screens.chat.ChatScreen
import com.example.skillkart.ui.screens.create.CreateScreen
import com.example.skillkart.ui.screens.discover.DiscoverScreen
import com.example.skillkart.ui.screens.home.HomeFeedScreen
import com.example.skillkart.ui.screens.orders.OrdersScreen
import com.example.skillkart.ui.screens.profile.UserProfileScreen
import com.example.skillkart.ui.screens.profile.WorkerProfileScreen
import com.example.skillkart.ui.screens.servicedetail.ServiceDetailScreen
import com.example.skillkart.ui.screens.splash.SplashScreen
import com.example.skillkart.ui.screens.support.FaqScreen
import com.example.skillkart.ui.screens.support.HelpSupportScreen
import com.example.skillkart.ui.screens.support.MyComplaintsScreen
import com.example.skillkart.ui.screens.support.ReportProblemDialog
import com.example.skillkart.ui.screens.support.SupportChatScreen
import com.example.skillkart.ui.theme.SkillKartTheme
import com.example.skillkart.ui.viewmodel.MainTab
import com.example.skillkart.ui.viewmodel.SkillKartViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SkillKartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SkillKartTheme {
                SkillKartApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SkillKartApp(viewModel: SkillKartViewModel) {
    var showSplash by remember { mutableStateOf(true) }

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val allUsers by viewModel.allUsers.collectAsStateWithLifecycle()
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()

    val allServices by viewModel.allServices.collectAsStateWithLifecycle()
    val filteredServices by viewModel.filteredServices.collectAsStateWithLifecycle()
    val allPosts by viewModel.allPosts.collectAsStateWithLifecycle()
    val allOrders by viewModel.allOrders.collectAsStateWithLifecycle()
    val allMessages by viewModel.allMessages.collectAsStateWithLifecycle()
    val allReviews by viewModel.allReviews.collectAsStateWithLifecycle()
    val allNotifications by viewModel.allNotifications.collectAsStateWithLifecycle()
    val filterState by viewModel.filterState.collectAsStateWithLifecycle()
    val postComments by viewModel.postComments.collectAsStateWithLifecycle()

    val selectedService by viewModel.selectedService.collectAsStateWithLifecycle()
    val selectedWorker by viewModel.selectedWorker.collectAsStateWithLifecycle()
    val activeChatPartner by viewModel.activeChatPartner.collectAsStateWithLifecycle()
    val activeChatOrderIdRef by viewModel.activeChatOrderIdRef.collectAsStateWithLifecycle()

    val showBookingSheet by viewModel.showBookingSheet.collectAsStateWithLifecycle()
    val showReviewDialog by viewModel.showReviewDialog.collectAsStateWithLifecycle()
    val orderToReview by viewModel.orderToReview.collectAsStateWithLifecycle()
    val activeCommentPost by viewModel.activeCommentPost.collectAsStateWithLifecycle()
    val showAuthScreen by viewModel.showAuthScreen.collectAsStateWithLifecycle()
    val showNotificationsSheet by viewModel.showNotificationsSheet.collectAsStateWithLifecycle()
    val showEditProfileDialog by viewModel.showEditProfileDialog.collectAsStateWithLifecycle()

    // Support System State Flows
    val supportTickets by viewModel.supportTickets.collectAsStateWithLifecycle()
    val activeSupportTicket by viewModel.activeSupportTicket.collectAsStateWithLifecycle()
    val supportMessages by viewModel.supportMessages.collectAsStateWithLifecycle()
    val complaints by viewModel.complaints.collectAsStateWithLifecycle()
    val faqs by viewModel.faqs.collectAsStateWithLifecycle()
    val showHelpSupportScreen by viewModel.showHelpSupportScreen.collectAsStateWithLifecycle()
    val showMyComplaintsScreen by viewModel.showMyComplaints.collectAsStateWithLifecycle()
    val showFaqScreen by viewModel.showFaqs.collectAsStateWithLifecycle()
    val showReportProblemDialog by viewModel.showReportProblemDialog.collectAsStateWithLifecycle()
    val showAdminSupportScreen by viewModel.showAdminSupportScreen.collectAsStateWithLifecycle()
    val preselectedComplaintOrder by viewModel.preselectedComplaintOrder.collectAsStateWithLifecycle()

    // Challenges state
    val challenges by viewModel.challenges.collectAsStateWithLifecycle()
    val showChallengesScreen by viewModel.showChallengesScreen.collectAsStateWithLifecycle()

    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearSnackbar()
        }
    }

    if (showSplash) {
        SplashScreen(onTimeout = { showSplash = false })
        return
    }

    // Auth screen overlay
    if (showAuthScreen) {
        AuthScreen(
            allUsers = allUsers,
            onSelectDemoUser = { userId ->
                viewModel.switchUser(userId)
                viewModel.toggleAuthScreen(false)
            },
            onRegisterUser = { name, email, phone, role, trade, location ->
                viewModel.registerUser(name, email, phone, role, trade, location)
            },
            onClose = { viewModel.toggleAuthScreen(false) }
        )
        return
    }

    // In-App Support Chat Screen overlay
    if (activeSupportTicket != null) {
        val currentMessages = supportMessages[activeSupportTicket!!.id] ?: emptyList()
        SupportChatScreen(
            ticket = activeSupportTicket!!,
            messages = currentMessages,
            currentUser = currentUser,
            onSendMessage = { msg, img ->
                viewModel.sendSupportMessage(activeSupportTicket!!.id, msg, img, isFromAdmin = currentUser.isAdmin)
            },
            onCloseTicket = {
                viewModel.closeTicket(activeSupportTicket!!.id)
            },
            onReopenTicket = {
                viewModel.reopenTicket(activeSupportTicket!!.id)
            },
            onBack = { viewModel.closeSupportChat() }
        )
        return
    }

    // Admin Support Panel overlay
    if (showAdminSupportScreen && currentUser.isAdmin) {
        AdminSupportScreen(
            currentUser = currentUser,
            supportTickets = supportTickets,
            supportMessages = supportMessages,
            complaints = complaints,
            faqs = faqs,
            onBack = { viewModel.closeAdminSupport() },
            onSendAdminReply = { ticketId, text, img ->
                viewModel.sendSupportMessage(ticketId, text, img, isFromAdmin = true)
            },
            onUpdateTicketStatus = { ticketId, status ->
                viewModel.updateTicketStatus(ticketId, status)
            },
            onUpdateTicketPriority = { ticketId, priority ->
                viewModel.updateTicketPriority(ticketId, priority)
            },
            onUpdateInternalNotes = { ticketId, notes ->
                viewModel.updateTicketInternalNotes(ticketId, notes)
            },
            onSaveFaq = { faq ->
                viewModel.saveFaq(faq)
            },
            onDeleteFaq = { faqId ->
                viewModel.deleteFaq(faqId)
            }
        )
        return
    }

    // My Complaints Screen overlay
    if (showMyComplaintsScreen) {
        val userComplaints = complaints.filter { it.userId == currentUser.id }
        MyComplaintsScreen(
            complaints = userComplaints,
            onBack = { viewModel.closeMyComplaints() },
            onOpenTicketChat = { ticketId ->
                viewModel.closeMyComplaints()
                viewModel.openSupportChatByTicketId(ticketId)
            },
            onReportNewProblem = {
                viewModel.openReportProblem(null)
            }
        )
        return
    }

    // FAQ Screen overlay
    if (showFaqScreen) {
        FaqScreen(
            faqs = faqs,
            onBack = { viewModel.closeFaqs() },
            onOpenSupportChat = {
                viewModel.closeFaqs()
                viewModel.openHelpSupport()
            }
        )
        return
    }

    // Help & Support Center Screen overlay
    if (showHelpSupportScreen) {
        HelpSupportScreen(
            currentUser = currentUser,
            supportTickets = supportTickets,
            complaints = complaints,
            onBack = { viewModel.closeHelpSupport() },
            onOpenChatWithSupport = {
                // Find or open latest open ticket, or show create dialog
                val openTicket = supportTickets.find { it.userId == currentUser.id && it.isOpen }
                if (openTicket != null) {
                    viewModel.openSupportChat(openTicket)
                } else {
                    // Start new general support ticket
                    viewModel.createSupportTicket("General In-App Inquiry", "General", "Hello SkillKart Support Team, I need assistance.")
                }
            },
            onOpenTicketChat = { ticket ->
                viewModel.openSupportChat(ticket)
            },
            onOpenMyComplaints = {
                viewModel.openMyComplaints()
            },
            onOpenFaqs = {
                viewModel.openFaqs()
            },
            onOpenReportProblem = {
                viewModel.openReportProblem(null)
            },
            onStartNewTicket = { subject, category, message ->
                viewModel.createSupportTicket(subject, category, message)
            }
        )
        return
    }

    // Challenges Screen overlay
    if (showChallengesScreen) {
        ChallengesScreen(
            challenges = challenges,
            currentUser = currentUser,
            onBack = { viewModel.closeChallenges() },
            onJoinChallenge = { chId -> viewModel.toggleJoinChallenge(chId) },
            onVoteParticipant = { chId, workerId -> viewModel.voteForChallengeParticipant(chId, workerId) },
            onSubmitWork = { chId ->
                viewModel.submitChallengeWork(chId, "Master Quality Trade Work & Precision Installation")
            },
            onWorkerClick = { workerId ->
                viewModel.closeChallenges()
                viewModel.openWorkerProfile(workerId)
            }
        )
        return
    }

    // Active Chat Screen overlay
    if (activeChatPartner != null) {
        ChatScreen(
            partner = activeChatPartner!!,
            currentUser = currentUser,
            messages = allMessages,
            orderIdRef = activeChatOrderIdRef,
            onSendMessage = { text, photo, orderId ->
                viewModel.sendChatMessage(activeChatPartner!!.id, text, photo, orderId)
            },
            onBack = { viewModel.closeChat() }
        )
        return
    }

    // Selected Service Detail Screen overlay
    if (selectedService != null && !showBookingSheet) {
        val workerUser = allUsers.find { it.id == selectedService!!.workerId }
        val serviceReviews = allReviews.filter { it.serviceTitle == selectedService!!.title || it.workerId == selectedService!!.workerId }
        ServiceDetailScreen(
            service = selectedService!!,
            worker = workerUser,
            reviews = serviceReviews,
            onBookClick = { viewModel.startBooking(selectedService!!) },
            onChatClick = {
                if (workerUser != null) {
                    viewModel.openChatWith(workerUser)
                }
            },
            onWorkerClick = { workerId ->
                viewModel.closeServiceDetail()
                viewModel.openWorkerProfile(workerId)
            },
            onBack = { viewModel.closeServiceDetail() }
        )
        return
    }

    // Selected Worker Profile Screen overlay
    if (selectedWorker != null) {
        WorkerProfileScreen(
            worker = selectedWorker!!,
            services = allServices,
            posts = allPosts,
            reviews = allReviews,
            onBack = { viewModel.closeWorkerProfile() },
            onBookService = { srv -> viewModel.startBooking(srv) },
            onServiceClick = { srv -> viewModel.openServiceDetail(srv) },
            onChatClick = { worker -> viewModel.openChatWith(worker) },
            onFollowClick = { viewModel.toggleFollow(selectedWorker!!.id, false) },
            onLikePost = { post -> viewModel.toggleLike(post) },
            onCommentPost = { post -> viewModel.openCommentsFor(post) }
        )
        return
    }

    // Main Scaffold with TopBar and Bottom Navigation Bar
    val unreadNotifs = allNotifications.count { !it.isRead }
    val activeOrdersCount = allOrders.count {
        if (currentUser.role == UserRole.WORKER) it.workerId == currentUser.id else it.customerId == currentUser.id
    }

    Scaffold(
        topBar = {
            SkillKartTopBar(
                currentUser = currentUser,
                unreadNotifCount = unreadNotifs,
                onOpenNotifications = { viewModel.toggleNotifications(true) },
                onOpenUserSwitch = { viewModel.toggleAuthScreen(true) }
            )
        },
        bottomBar = {
            SkillKartBottomNav(
                currentTab = currentTab,
                onTabSelected = { tab -> viewModel.selectTab(tab) },
                ordersBadgeCount = activeOrdersCount
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            color = MaterialTheme.colorScheme.background
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    MainTab.HOME -> {
                        HomeFeedScreen(
                            posts = allPosts,
                            featuredServices = allServices,
                            topWorkers = allUsers,
                            currentUser = currentUser,
                            onLikePost = { post -> viewModel.toggleLike(post) },
                            onCommentPost = { post -> viewModel.openCommentsFor(post) },
                            onFollowWorker = { workerId, curr -> viewModel.toggleFollow(workerId, curr) },
                            onWorkerProfileClick = { workerId -> viewModel.openWorkerProfile(workerId) },
                            onServiceClick = { srvId ->
                                val srv = allServices.find { it.id == srvId }
                                if (srv != null) viewModel.openServiceDetail(srv)
                            },
                            onCreatePostClick = { viewModel.selectTab(MainTab.CREATE) },
                            onOpenChallenges = { viewModel.openChallenges() }
                        )
                    }
                    MainTab.DISCOVER -> {
                        DiscoverScreen(
                            services = filteredServices,
                            workers = allUsers,
                            filterState = filterState,
                            onCategorySelected = { cat -> viewModel.setCategoryFilter(cat) },
                            onSearchChanged = { q -> viewModel.setSearchQuery(q) },
                            onSortChanged = { s -> viewModel.setSortBy(s) },
                            onServiceClick = { srv -> viewModel.openServiceDetail(srv) },
                            onBookService = { srv -> viewModel.startBooking(srv) },
                            onWorkerClick = { workerId -> viewModel.openWorkerProfile(workerId) },
                            onChatWithWorker = { workerId -> viewModel.openChatWithWorkerId(workerId) },
                            onMaxPriceChanged = { price -> viewModel.setMaxPrice(price) },
                            onMinRatingChanged = { rating -> viewModel.setMinRating(rating) },
                            onResetFilters = { viewModel.resetFilters() }
                        )
                    }
                    MainTab.CREATE -> {
                        CreateScreen(
                            currentUser = currentUser,
                            myServices = allServices.filter { it.workerId == currentUser.id },
                            onCreatePost = { title, cap, type, tags, srvId, srvTitle, price, before, after ->
                                viewModel.createPost(title, cap, type, tags, srvId, srvTitle, price, before, after)
                            },
                            onCreateService = { title, cat, price, time, radius, visits, desc, inclusions ->
                                viewModel.createServicePackage(title, cat, price, time, radius, visits, desc, inclusions)
                            }
                        )
                    }
                    MainTab.ORDERS -> {
                        OrdersScreen(
                            orders = allOrders,
                            currentUser = currentUser,
                            onOrderClick = { ord -> viewModel.openOrderDetail(ord) },
                            onChatWithPartner = { partnerId, orderId ->
                                viewModel.openChatWithWorkerId(partnerId, orderId)
                            },
                            onUpdateStatus = { ord, status ->
                                viewModel.updateOrderStatus(ord, status)
                            },
                            onReviewClick = { ord ->
                                viewModel.startReview(ord)
                            }
                        )
                    }
                    MainTab.PROFILE -> {
                        UserProfileScreen(
                            currentUser = currentUser,
                            myServices = allServices,
                            onToggleRole = { viewModel.toggleRole() },
                            onEditProfileClick = { viewModel.toggleEditProfile(true) },
                            onOpenAuthSwitch = { viewModel.toggleAuthScreen(true) },
                            onCreateNewService = { viewModel.selectTab(MainTab.CREATE) },
                            onServiceClick = { srv -> viewModel.openServiceDetail(srv) },
                            onOpenHelpSupport = { viewModel.openHelpSupport() },
                            onOpenChatWithSupport = {
                                val openTicket = supportTickets.find { it.userId == currentUser.id && it.isOpen }
                                if (openTicket != null) {
                                    viewModel.openSupportChat(openTicket)
                                } else {
                                    viewModel.createSupportTicket("General Inquiry", "General", "Hello SkillKart Support Team, I need assistance.")
                                }
                            },
                            onOpenMyComplaints = { viewModel.openMyComplaints() },
                            onOpenFaqs = { viewModel.openFaqs() },
                            onOpenReportProblem = { viewModel.openReportProblem(null) },
                            onOpenAdminSupport = { viewModel.openAdminSupport() },
                            onOpenChallenges = { viewModel.openChallenges() }
                        )
                    }
                }
            }
        }
    }

    // Report a Problem / File Complaint Dialog
    if (showReportProblemDialog) {
        val userOrders = allOrders.filter {
            if (currentUser.role == UserRole.WORKER) it.workerId == currentUser.id else it.customerId == currentUser.id
        }
        ReportProblemDialog(
            preselectedOrder = preselectedComplaintOrder,
            userOrders = userOrders,
            onDismiss = { viewModel.closeReportProblem() },
            onSubmitComplaint = { category, details, orderId, orderTitle, imageUrl ->
                viewModel.submitComplaint(
                    category = category,
                    details = details,
                    orderId = orderId,
                    orderTitle = orderTitle,
                    imageUrl = imageUrl
                )
            }
        )
    }

    // Booking Bottom Sheet
    if (showBookingSheet && selectedService != null) {
        BookingSheet(
            service = selectedService!!,
            currentUser = currentUser,
            onDismiss = { viewModel.closeBooking() },
            onConfirmBooking = { srv, req, addr, dt, slot, inst ->
                viewModel.confirmBooking(srv, req, addr, dt, slot, inst)
            }
        )
    }

    // Review Dialog
    if (showReviewDialog && orderToReview != null) {
        ReviewDialog(
            order = orderToReview!!,
            onDismiss = { viewModel.closeReviewDialog() },
            onSubmitReview = { rating, comment, tags ->
                viewModel.submitReview(rating, comment, tags)
            }
        )
    }

    // Post Comments Sheet
    if (activeCommentPost != null) {
        val commentsList = postComments[activeCommentPost!!.id] ?: emptyList()
        CommentsSheet(
            post = activeCommentPost!!,
            comments = commentsList,
            currentUser = currentUser,
            onDismiss = { viewModel.closeComments() },
            onSubmitComment = { text ->
                viewModel.submitComment(activeCommentPost!!.id, text)
            }
        )
    }

    // Notifications Sheet
    if (showNotificationsSheet) {
        NotificationsSheet(
            notifications = allNotifications,
            onDismiss = { viewModel.toggleNotifications(false) },
            onNotificationClick = { notif ->
                viewModel.toggleNotifications(false)
                if (notif.relatedId != null) {
                    viewModel.selectTab(MainTab.ORDERS)
                }
            }
        )
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        EditProfileDialog(
            currentUser = currentUser,
            onDismiss = { viewModel.toggleEditProfile(false) },
            onSave = { name, loc, bio, trade, skills ->
                viewModel.updateProfile(name, loc, bio, trade, skills)
            }
        )
    }
}
