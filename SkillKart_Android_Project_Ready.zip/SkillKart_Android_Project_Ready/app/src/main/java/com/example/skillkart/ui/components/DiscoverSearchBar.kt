package com.example.skillkart.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.FilterAlt
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.skillkart.data.model.SkillCategories
import com.example.skillkart.ui.theme.EmeraldSuccess
import com.example.skillkart.ui.theme.GoldStar
import com.example.skillkart.ui.theme.IndigoPrimary
import com.example.skillkart.ui.theme.SaffronPrimary
import com.example.skillkart.ui.theme.SaffronSecondary
import com.example.skillkart.ui.viewmodel.FilterState
import kotlinx.coroutines.launch

/**
 * Quick search popular query suggestions for Indian trades & home services
 */
val POPULAR_SEARCH_PROMPTS = listOf(
    "MS Sliding Gate",
    "Electrician Wiring",
    "Split AC Service",
    "Kitchen Plumbing",
    "Deep Cleaning",
    "Sofa Upholstery",
    "Custom Wardrobe",
    "Wall Painter",
    "Roof Waterproofing"
)

/**
 * Dedicated DiscoverSearchBar component for filtering services and workers in the Discover tab.
 * Supports keyword search, 17 skill categories carousel, instant suggestion chips,
 * and an interactive filter bottom sheet with price range and rating constraints.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DiscoverSearchBar(
    filterState: FilterState,
    onSearchChanged: (String) -> Unit,
    onCategorySelected: (String) -> Unit,
    onSortChanged: (String) -> Unit,
    onMaxPriceChanged: (Int) -> Unit,
    onMinRatingChanged: (Float) -> Unit,
    onResetFilters: () -> Unit,
    resultCount: Int,
    modifier: Modifier = Modifier,
    isSearchingWorkers: Boolean = false
) {
    var showFilterSheet by remember { mutableStateOf(false) }
    var showQuickSuggestions by remember { mutableStateOf(false) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    // Calculate active filter count (excluding default values)
    val activeFilterCount = remember(filterState) {
        var count = 0
        if (filterState.selectedCategory != "All") count++
        if (filterState.maxPrice < 10000) count++
        if (filterState.minRating > 0f) count++
        if (filterState.sortBy != "Popular") count++
        count
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("discover_search_bar_container")
    ) {
        // Main Search Bar with Filter and Action buttons
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp,
            shadowElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Top Search Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = filterState.searchQuery,
                        onValueChange = {
                            onSearchChanged(it)
                            showQuickSuggestions = it.isBlank()
                        },
                        placeholder = {
                            Text(
                                text = if (isSearchingWorkers) "Search workers, trades, areas..." else "Search MS gates, AC repair, plumbing...",
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search icon",
                                tint = SaffronPrimary
                            )
                        },
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (filterState.searchQuery.isNotBlank()) {
                                    IconButton(
                                        onClick = {
                                            onSearchChanged("")
                                            showQuickSuggestions = false
                                        },
                                        modifier = Modifier.testTag("clear_search_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Clear,
                                            contentDescription = "Clear search",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("discover_search_input"),
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = SaffronPrimary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                        ),
                        singleLine = true
                    )

                    // Filter Options Trigger Button with Badge
                    Surface(
                        onClick = { showFilterSheet = true },
                        shape = RoundedCornerShape(16.dp),
                        color = if (activeFilterCount > 0) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 2.dp,
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("discover_filter_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (activeFilterCount > 0) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Filters applied",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Outlined.FilterAlt,
                                    contentDescription = "Filter options",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }

                // Quick Search Suggestion Pills
                AnimatedVisibility(
                    visible = filterState.searchQuery.isBlank(),
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(modifier = Modifier.padding(top = 10.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(bottom = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Popular searches:",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            POPULAR_SEARCH_PROMPTS.forEach { prompt ->
                                Surface(
                                    onClick = { onSearchChanged(prompt) },
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier.testTag("quick_prompt_${prompt.replace(" ", "_")}")
                                ) {
                                    Text(
                                        text = prompt,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Skill Categories Chips Carousel (All 17 Categories with Hindi text)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SkillCategories.ALL.forEach { cat ->
                        val isSelected = filterState.selectedCategory.equals(cat.name, ignoreCase = true)
                        FilterChip(
                            selected = isSelected,
                            onClick = { onCategorySelected(cat.name) },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = cat.icon, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "${cat.name} (${cat.hindiName})",
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp
                                    )
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SaffronPrimary,
                                selectedLabelColor = Color.White,
                                containerColor = MaterialTheme.colorScheme.surface,
                                labelColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(20.dp),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.testTag("cat_chip_${cat.name.lowercase().replace(" ", "_")}")
                        )
                    }
                }

                // Active Filters Row (if any filter is applied)
                if (activeFilterCount > 0 || filterState.searchQuery.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Active:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (filterState.selectedCategory != "All") {
                            ActiveFilterChip(
                                label = filterState.selectedCategory,
                                onRemove = { onCategorySelected("All") }
                            )
                        }

                        if (filterState.searchQuery.isNotBlank()) {
                            ActiveFilterChip(
                                label = "\"${filterState.searchQuery}\"",
                                onRemove = { onSearchChanged("") }
                            )
                        }

                        if (filterState.maxPrice < 10000) {
                            ActiveFilterChip(
                                label = "Max ₹${filterState.maxPrice}",
                                onRemove = { onMaxPriceChanged(10000) }
                            )
                        }

                        if (filterState.minRating > 0f) {
                            ActiveFilterChip(
                                label = "★ ${filterState.minRating}+",
                                onRemove = { onMinRatingChanged(0f) }
                            )
                        }

                        if (filterState.sortBy != "Popular") {
                            ActiveFilterChip(
                                label = "Sort: ${filterState.sortBy}",
                                onRemove = { onSortChanged("Popular") }
                            )
                        }

                        // Reset All Button
                        Surface(
                            onClick = onResetFilters,
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f),
                            modifier = Modifier.testTag("reset_filters_pill")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reset All",
                                    tint = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Reset All",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }

                // Results Summary Row
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (resultCount > 0) "Showing $resultCount verified results" else "No matching results found",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (resultCount > 0) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                    )

                    Text(
                        text = "⚡ Real-time Firestore Sync",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = EmeraldSuccess
                    )
                }
            }
        }
    }

    // Filter Bottom Sheet Dialog
    if (showFilterSheet) {
        ModalBottomSheet(
            onDismissRequest = { showFilterSheet = false },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.testTag("discover_filter_bottom_sheet")
        ) {
            FilterBottomSheetContent(
                filterState = filterState,
                onCategorySelected = onCategorySelected,
                onSortChanged = onSortChanged,
                onMaxPriceChanged = onMaxPriceChanged,
                onMinRatingChanged = onMinRatingChanged,
                onReset = {
                    onResetFilters()
                    scope.launch { sheetState.hide() }.invokeOnCompletion { showFilterSheet = false }
                },
                onApply = {
                    scope.launch { sheetState.hide() }.invokeOnCompletion { showFilterSheet = false }
                }
            )
        }
    }
}

@Composable
private fun ActiveFilterChip(
    label: String,
    onRemove: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = SaffronSecondary.copy(alpha = 0.15f),
        border = androidx.compose.foundation.BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = SaffronPrimary
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Remove filter",
                tint = SaffronPrimary,
                modifier = Modifier
                    .size(12.dp)
                    .clickable { onRemove() }
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FilterBottomSheetContent(
    filterState: FilterState,
    onCategorySelected: (String) -> Unit,
    onSortChanged: (String) -> Unit,
    onMaxPriceChanged: (Int) -> Unit,
    onMinRatingChanged: (Float) -> Unit,
    onReset: () -> Unit,
    onApply: () -> Unit
) {
    var tempMaxPrice by remember { mutableFloatStateOf(filterState.maxPrice.toFloat()) }
    var tempMinRating by remember { mutableFloatStateOf(filterState.minRating) }
    var tempSortBy by remember { mutableStateOf(filterState.sortBy) }
    var tempCategory by remember { mutableStateOf(filterState.selectedCategory) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .padding(bottom = 24.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Filter & Sort Services",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Reset",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SaffronPrimary,
                modifier = Modifier
                    .clickable {
                        tempMaxPrice = 10000f
                        tempMinRating = 0f
                        tempSortBy = "Popular"
                        tempCategory = "All"
                        onReset()
                    }
                    .testTag("filter_sheet_reset_button")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Sort By
        Text(
            text = "Sort By",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "Popular" to "Popular",
                "Rating" to "Top Rated",
                "PriceLow" to "₹ Low-High",
                "PriceHigh" to "₹ High-Low"
            ).forEach { (id, label) ->
                val isSelected = tempSortBy == id
                FilterChip(
                    selected = isSelected,
                    onClick = { tempSortBy = id },
                    label = { Text(label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = IndigoPrimary,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("sort_chip_$id")
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Max Price Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Maximum Budget (₹)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = if (tempMaxPrice >= 10000f) "₹10,000+ (Any)" else "₹${tempMaxPrice.toInt()}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SaffronPrimary
            )
        }
        Slider(
            value = tempMaxPrice,
            onValueChange = { tempMaxPrice = it },
            valueRange = 500f..10000f,
            steps = 19,
            colors = SliderDefaults.colors(
                thumbColor = SaffronPrimary,
                activeTrackColor = SaffronPrimary
            ),
            modifier = Modifier.testTag("price_slider")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Minimum Worker Rating
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Minimum Rating",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = if (tempMinRating == 0f) "Any Rating" else "★ ${tempMinRating}+",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = GoldStar
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(0f to "All", 3.5f to "3.5+ ★", 4.0f to "4.0+ ★", 4.5f to "4.5+ ★", 4.8f to "4.8+ ★").forEach { (rating, label) ->
                val isSelected = tempMinRating == rating
                FilterChip(
                    selected = isSelected,
                    onClick = { tempMinRating = rating },
                    label = { Text(label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldStar,
                        selectedLabelColor = Color.Black
                    ),
                    modifier = Modifier.testTag("rating_chip_${rating}")
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onReset,
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Cancel")
            }

            Button(
                onClick = {
                    onCategorySelected(tempCategory)
                    onSortChanged(tempSortBy)
                    onMaxPriceChanged(tempMaxPrice.toInt())
                    onMinRatingChanged(tempMinRating)
                    onApply()
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("filter_sheet_apply_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Apply Filters", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
