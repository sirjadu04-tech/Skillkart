package com.example.skillkart.data.model

data class ChallengeParticipant(
    val rank: Int = 1,
    val workerId: String = "",
    val workerName: String = "",
    val workerAvatarColor: String = "#E65100",
    val trade: String = "",
    val submissionTitle: String = "",
    val submissionImageUrl: String? = null,
    val votesCount: Int = 0,
    val isVotedByMe: Boolean = false,
    val submissionDate: String = "Yesterday"
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "rank" to rank,
            "workerId" to workerId,
            "workerName" to workerName,
            "workerAvatarColor" to workerAvatarColor,
            "trade" to trade,
            "submissionTitle" to submissionTitle,
            "submissionImageUrl" to submissionImageUrl,
            "votesCount" to votesCount,
            "submissionDate" to submissionDate
        )
    }
}

data class Challenge(
    val id: String = "",
    val title: String = "",
    val hindiTitle: String = "",
    val category: String = "Welding",
    val trade: String = "Electrician",
    val description: String = "",
    val xpReward: Int = 500,
    val cashPrizeInr: Int = 2500,
    val badgeName: String = "Pro Craftsman",
    val badgeEmoji: String = "🏆",
    val deadline: String = "3 Days Left",
    val daysLeft: Int = 3,
    val participantsCount: Int = 42,
    val submissionsCount: Int = 18,
    val isJoinedByMe: Boolean = false,
    val status: String = "ACTIVE", // ACTIVE, UPCOMING, COMPLETED
    val sponsorName: String = "SkillKart Pro League",
    val leaderboard: List<ChallengeParticipant> = emptyList(),
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "title" to title,
            "hindiTitle" to hindiTitle,
            "category" to category,
            "trade" to trade,
            "description" to description,
            "xpReward" to xpReward,
            "cashPrizeInr" to cashPrizeInr,
            "badgeName" to badgeName,
            "badgeEmoji" to badgeEmoji,
            "deadline" to deadline,
            "daysLeft" to daysLeft,
            "participantsCount" to participantsCount,
            "submissionsCount" to submissionsCount,
            "status" to status,
            "sponsorName" to sponsorName,
            "leaderboard" to leaderboard.map { it.toFirestoreMap() },
            "createdAt" to createdAt
        )
    }
}

object SampleChallenges {
    val ALL = listOf(
        Challenge(
            id = "ch_1",
            title = "⚡ Modular Switchboard Wiring Mastery",
            hindiTitle = "मॉड्यूलर स्विचबोर्ड वायरिंग मास्टरी",
            category = "Electrician",
            trade = "Electrician",
            description = "Showcase your cleanest, safest 8-module concealed switchboard wiring with color-coded ferrules and earthing test.",
            xpReward = 600,
            cashPrizeInr = 3000,
            badgeName = "Volt Master 2026",
            badgeEmoji = "⚡",
            deadline = "2 Days Left",
            daysLeft = 2,
            participantsCount = 56,
            submissionsCount = 24,
            isJoinedByMe = true,
            status = "ACTIVE",
            sponsorName = "Havells Pro Partner",
            leaderboard = listOf(
                ChallengeParticipant(
                    rank = 1,
                    workerId = "w1",
                    workerName = "Rajesh Sharma",
                    workerAvatarColor = "#E65100",
                    trade = "Master Electrician",
                    submissionTitle = "Concealed 12-way DB box with dual surge protection",
                    votesCount = 142,
                    isVotedByMe = true
                ),
                ChallengeParticipant(
                    rank = 2,
                    workerId = "w2",
                    workerName = "Vikram Singh",
                    workerAvatarColor = "#1B5E20",
                    trade = "Industrial Electrician",
                    submissionTitle = "Modular AC inverter load distribution board",
                    votesCount = 118,
                    isVotedByMe = false
                ),
                ChallengeParticipant(
                    rank = 3,
                    workerId = "w3",
                    workerName = "Amit Kumar",
                    workerAvatarColor = "#4A148C",
                    trade = "Licensed Wireman",
                    submissionTitle = "Smart touch relay switchboard installation",
                    votesCount = 95,
                    isVotedByMe = false
                )
            )
        ),
        Challenge(
            id = "ch_2",
            title = "🚰 Zero-Leak PVC & CPVC Pipe Fitting Challenge",
            hindiTitle = "जीरो-लीक पाइप फिटिंग चैलेंज",
            category = "Plumber",
            trade = "Plumber",
            description = "Design and install a high-pressure bathroom manifold manifold with zero joint sweating and neat alignment.",
            xpReward = 500,
            cashPrizeInr = 2500,
            badgeName = "Hydro Expert",
            badgeEmoji = "🚰",
            deadline = "4 Days Left",
            daysLeft = 4,
            participantsCount = 38,
            submissionsCount = 15,
            isJoinedByMe = false,
            status = "ACTIVE",
            sponsorName = "Astral Pipes Skill Hub",
            leaderboard = listOf(
                ChallengeParticipant(
                    rank = 1,
                    workerId = "w4",
                    workerName = "Manoj Verma",
                    workerAvatarColor = "#006064",
                    trade = "Master Plumber",
                    submissionTitle = "4-line overhead water tank inlet manifold",
                    votesCount = 89,
                    isVotedByMe = false
                ),
                ChallengeParticipant(
                    rank = 2,
                    workerId = "w5",
                    workerName = "Sunil Yadav",
                    workerAvatarColor = "#BF360C",
                    trade = "Plumbing Specialist",
                    submissionTitle = "Concealed diverter installation with pressure balance",
                    votesCount = 74,
                    isVotedByMe = false
                )
            )
        ),
        Challenge(
            id = "ch_3",
            title = "🎨 Living Room Accent Wall Makeover",
            hindiTitle = "लिविंग रूम एक्सेंट वॉल मेकओवर",
            category = "Painter",
            trade = "Painter",
            description = "Transform a plain wall with texture stencil, metallic accents, or royal velvet finish. Share before & after!",
            xpReward = 750,
            cashPrizeInr = 4000,
            badgeName = "Color Maestro",
            badgeEmoji = "🎨",
            deadline = "5 Days Left",
            daysLeft = 5,
            participantsCount = 49,
            submissionsCount = 21,
            isJoinedByMe = false,
            status = "ACTIVE",
            sponsorName = "Asian Paints Royale League",
            leaderboard = listOf(
                ChallengeParticipant(
                    rank = 1,
                    workerId = "w6",
                    workerName = "Deepak Saini",
                    workerAvatarColor = "#880E4F",
                    trade = "Interior Artist & Painter",
                    submissionTitle = "3D Geometric Gold Leaf Texture Accent Wall",
                    votesCount = 204,
                    isVotedByMe = true
                )
            )
        ),
        Challenge(
            id = "ch_4",
            title = "🪚 Dovetail Joint Wooden Furniture Craft",
            hindiTitle = "डवटेल जॉइंट लकड़ी क्राफ्ट",
            category = "Carpenter",
            trade = "Carpenter",
            description = "Craft a solid teak or sheesham wood bedside table or shelf utilizing precision hand-cut dovetail joints.",
            xpReward = 800,
            cashPrizeInr = 5000,
            badgeName = "Artisan Carpenter",
            badgeEmoji = "🪚",
            deadline = "6 Days Left",
            daysLeft = 6,
            participantsCount = 33,
            submissionsCount = 12,
            isJoinedByMe = false,
            status = "ACTIVE",
            sponsorName = "Fevicol Champions Club",
            leaderboard = listOf(
                ChallengeParticipant(
                    rank = 1,
                    workerId = "w7",
                    workerName = "Ramesh Mistri",
                    workerAvatarColor = "#3E2723",
                    trade = "Senior Woodcraftsman",
                    submissionTitle = "Antique Teakwood Corner Shelf with Interlocking Joints",
                    votesCount = 163,
                    isVotedByMe = false
                )
            )
        )
    )
}
