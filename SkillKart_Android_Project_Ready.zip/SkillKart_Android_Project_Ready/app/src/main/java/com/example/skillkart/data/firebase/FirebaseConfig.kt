package com.example.skillkart.data.firebase

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

/**
 * Central Firebase initialization configuration and provider for SkillKart.
 * 
 * Sets up and manages Firestore, FirebaseAuth, and FirebaseStorage SDK instances
 * with production settings, offline persistence caching, timeout policies,
 * and strongly typed collection and storage paths.
 */
object FirebaseConfig {

    private const val TAG = "SkillKartFirebaseConfig"

    // Collections
    const val COLLECTION_USERS = "users"
    const val COLLECTION_SERVICES = "services"
    const val COLLECTION_WORKER_PROFILES = "workerProfiles"
    const val COLLECTION_POSTS = "posts"
    const val COLLECTION_ORDERS = "orders"
    const val COLLECTION_MESSAGES = "messages"
    const val COLLECTION_SUPPORT_TICKETS = "supportTickets"
    const val COLLECTION_SUPPORT_MESSAGES = "supportMessages"
    const val COLLECTION_REVIEWS = "reviews"
    const val COLLECTION_NOTIFICATIONS = "notifications"
    const val COLLECTION_COMPLAINTS = "complaints"
    const val COLLECTION_FAQS = "faqs"
    const val COLLECTION_CHATS = "chats"
    const val COLLECTION_FOLLOWS = "follows"
    const val COLLECTION_CHALLENGES = "challenges"

    // Storage Paths
    const val STORAGE_PATH_PROFILES = "profile_images"
    const val STORAGE_PATH_SERVICES = "service_images"
    const val STORAGE_PATH_POSTS = "post_images"
    const val STORAGE_PATH_BEFORE_AFTER = "before_after_images"
    const val STORAGE_PATH_CHAT = "chat_attachments"
    const val STORAGE_PATH_SUPPORT = "support_attachments"

    @Volatile
    private var isConfigured: Boolean = false

    @Volatile
    private var authInstance: FirebaseAuth? = null

    @Volatile
    private var firestoreInstance: FirebaseFirestore? = null

    @Volatile
    private var storageInstance: FirebaseStorage? = null

    /**
     * Initializes the Firebase SDK components for the SkillKart application.
     * Safe to call multiple times from Application class or MainActivity.
     */
    @Synchronized
    fun initialize(context: Context): Boolean {
        if (isConfigured) return true

        return try {
            val appContext = context.applicationContext
            val app = if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext)
            } else {
                FirebaseApp.getInstance()
            }

            if (app != null) {
                // Initialize Authentication
                authInstance = FirebaseAuth.getInstance(app).apply {
                    useAppLanguage()
                }

                // Initialize Cloud Firestore with offline cache settings
                firestoreInstance = FirebaseFirestore.getInstance(app).apply {
                    val settings = FirebaseFirestoreSettings.Builder()
                        .setLocalCacheSettings(
                            PersistentCacheSettings.newBuilder()
                                .setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                                .build()
                        )
                        .build()
                    firestoreSettings = settings
                }

                // Initialize Firebase Storage with reasonable timeout policies
                storageInstance = FirebaseStorage.getInstance(app).apply {
                    maxUploadRetryTimeMillis = 30_000L
                    maxOperationRetryTimeMillis = 30_000L
                }

                isConfigured = true
                Log.i(TAG, "SkillKart Firebase initialized successfully (App: ${app.name})")
                true
            } else {
                Log.w(TAG, "FirebaseApp could not be initialized")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Firebase instances", e)
            false
        }
    }

    /**
     * Checks if Firebase is initialized and available.
     */
    val isInitialized: Boolean
        get() = isConfigured && authInstance != null && firestoreInstance != null

    /**
     * Gets the FirebaseAuth instance.
     */
    val auth: FirebaseAuth?
        get() = authInstance ?: try {
            FirebaseAuth.getInstance().also { authInstance = it }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth not ready: ${e.message}")
            null
        }

    /**
     * Gets the Cloud Firestore instance.
     */
    val firestore: FirebaseFirestore?
        get() = firestoreInstance ?: try {
            FirebaseFirestore.getInstance().also { firestoreInstance = it }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseFirestore not ready: ${e.message}")
            null
        }

    /**
     * Gets the Firebase Storage instance.
     */
    val storage: FirebaseStorage?
        get() = storageInstance ?: try {
            FirebaseStorage.getInstance().also { storageInstance = it }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseStorage not ready: ${e.message}")
            null
        }

    /**
     * Current authenticated Firebase user.
     */
    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    // -------------------------------------------------------------
    // CONVENIENCE FIRESTORE COLLECTION ACCESSORS
    // -------------------------------------------------------------

    fun usersCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_USERS)

    fun workerProfilesCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_WORKER_PROFILES)

    fun servicesCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_SERVICES)

    fun postsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_POSTS)

    fun ordersCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_ORDERS)

    fun messagesCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_MESSAGES)

    fun supportTicketsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_SUPPORT_TICKETS)

    fun supportMessagesCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_SUPPORT_MESSAGES)

    fun reviewsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_REVIEWS)

    fun notificationsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_NOTIFICATIONS)

    fun complaintsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_COMPLAINTS)

    fun faqsCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_FAQS)

    fun challengesCollection(): CollectionReference? =
        firestore?.collection(COLLECTION_CHALLENGES)

    // -------------------------------------------------------------
    // CONVENIENCE STORAGE REFERENCE ACCESSORS
    // -------------------------------------------------------------

    fun getStorageRoot(): StorageReference? =
        storage?.reference

    fun getProfileImagesRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_PROFILES)

    fun getServiceImagesRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_SERVICES)

    fun getPostImagesRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_POSTS)

    fun getBeforeAfterImagesRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_BEFORE_AFTER)

    fun getChatAttachmentsRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_CHAT)

    fun getSupportAttachmentsRef(): StorageReference? =
        storage?.reference?.child(STORAGE_PATH_SUPPORT)
}
