package com.example.skillkart.data.model

enum class UserRole {
    CUSTOMER,
    WORKER,
    ADMIN
}

data class User(
    val id: String = "",
    val uid: String = id,
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val accountType: String = if (role == UserRole.WORKER) "worker" else if (role == UserRole.ADMIN) "admin" else "customer",
    val trade: String = "",
    val city: String = "Delhi NCR",
    val area: String = "Connaught Place",
    val location: String = "$area, $city",
    val bio: String = "",
    val skills: List<String> = emptyList(),
    val rating: Float = 5.0f,
    val reviewCount: Int = 0,
    val completedJobs: Int = 0,
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val profilePhoto: String? = null,
    val avatarColorHex: String = "#E65100",
    val isVerified: Boolean = true,
    val joinedDate: String = "Jan 2026",
    val createdAt: Long = System.currentTimeMillis()
) {
    val isAdmin: Boolean get() = role == UserRole.ADMIN || accountType.equals("admin", ignoreCase = true)

    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "uid" to id,
            "name" to name,
            "email" to email,
            "phone" to phone,
            "accountType" to if (role == UserRole.WORKER) "worker" else if (role == UserRole.ADMIN) "admin" else "customer",
            "trade" to trade,
            "city" to city,
            "area" to area,
            "bio" to bio,
            "skills" to skills,
            "rating" to rating.toDouble(),
            "reviewCount" to reviewCount,
            "completedJobs" to completedJobs,
            "followersCount" to followersCount,
            "followingCount" to followingCount,
            "profilePhoto" to profilePhoto,
            "avatarColorHex" to avatarColorHex,
            "isVerified" to isVerified,
            "createdAt" to createdAt
        )
    }
}

enum class PostType {
    WORK_SHOWCASE,
    BEFORE_AFTER,
    SERVICE_OFFER,
    TIPS_UPDATE
}

data class Post(
    val id: String = "",
    val workerId: String = "",
    val workerName: String = "",
    val workerTrade: String = "",
    val workerAvatarColor: String = "#E65100",
    val workerLocation: String = "Delhi, NCR",
    val workerRating: Float = 4.9f,
    val type: PostType = PostType.WORK_SHOWCASE,
    val title: String = "",
    val caption: String = "",
    val category: String = "General",
    val imageUrl: String? = null,
    val videoUrl: String? = null,
    val tags: List<String> = emptyList(),
    val linkedServiceId: String? = null,
    val linkedServiceTitle: String? = null,
    val linkedPriceInr: Int? = null,
    val beforeDescription: String? = null,
    val afterDescription: String? = null,
    val likesCount: Int = 0,
    val isLikedByMe: Boolean = false,
    val likedBy: List<String> = emptyList(),
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isFollowedByMe: Boolean = false,
    val followedBy: List<String> = emptyList(),
    val timestamp: String = "Just now",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "workerId" to workerId,
            "workerName" to workerName,
            "workerTrade" to workerTrade,
            "workerAvatarColor" to workerAvatarColor,
            "workerLocation" to workerLocation,
            "workerRating" to workerRating.toDouble(),
            "type" to type.name,
            "title" to title,
            "caption" to caption,
            "category" to category,
            "imageUrl" to imageUrl,
            "videoUrl" to videoUrl,
            "tags" to tags,
            "linkedServiceId" to linkedServiceId,
            "linkedServiceTitle" to linkedServiceTitle,
            "linkedPriceInr" to linkedPriceInr,
            "beforeDescription" to beforeDescription,
            "afterDescription" to afterDescription,
            "likesCount" to likesCount,
            "likedBy" to likedBy,
            "commentsCount" to commentsCount,
            "sharesCount" to sharesCount,
            "createdAt" to createdAt
        )
    }
}

data class Comment(
    val id: String = "",
    val postId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userAvatarColor: String = "#1A237E",
    val text: String = "",
    val timestamp: String = "Just now",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "postId" to postId,
            "userId" to userId,
            "userName" to userName,
            "userAvatarColor" to userAvatarColor,
            "text" to text,
            "timestamp" to timestamp,
            "createdAt" to createdAt
        )
    }
}

data class ServicePackage(
    val id: String = "",
    val workerId: String = "",
    val workerName: String = "",
    val workerTrade: String = "",
    val workerRating: Float = 4.9f,
    val workerLocation: String = "Delhi",
    val title: String = "",
    val category: String = "Other",
    val priceInr: Int = 0,
    val completionTime: String = "1-2 Days",
    val serviceRadius: String = "Within 10 km",
    val maxVisits: String = "1-2 on-site visits",
    val description: String = "",
    val inclusions: List<String> = emptyList(),
    val images: List<String> = emptyList(),
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
) {
    val estimatedDays: String get() = completionTime
    val price: Int get() = priceInr

    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "serviceId" to id,
            "workerId" to workerId,
            "workerName" to workerName,
            "workerTrade" to workerTrade,
            "workerRating" to workerRating.toDouble(),
            "workerLocation" to workerLocation,
            "title" to title,
            "category" to category,
            "price" to priceInr,
            "priceInr" to priceInr,
            "estimatedDays" to completionTime,
            "completionTime" to completionTime,
            "serviceRadius" to serviceRadius,
            "maxVisits" to maxVisits,
            "description" to description,
            "inclusions" to inclusions,
            "images" to images,
            "active" to isActive,
            "isActive" to isActive,
            "createdAt" to createdAt
        )
    }
}

enum class OrderStatus(val displayName: String, val hindiName: String) {
    PENDING("Pending", "लंबित"),
    ACCEPTED("Accepted", "स्वीकृत"),
    IN_PROGRESS("In Progress", "प्रगति पर"),
    COMPLETED("Completed", "पूर्ण"),
    CANCELLED("Cancelled", "रद्द")
}

data class Order(
    val id: String = "",
    val serviceId: String = "",
    val serviceTitle: String = "",
    val serviceCategory: String = "Other",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val workerId: String = "",
    val workerName: String = "",
    val workerTrade: String = "",
    val priceInr: Int = 0,
    val status: OrderStatus = OrderStatus.PENDING,
    val requirementDetails: String = "",
    val serviceAddress: String = "",
    val preferredDate: String = "",
    val timeSlot: String = "",
    val instructions: String = "",
    val imageUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val hasReview: Boolean = false
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "serviceId" to serviceId,
            "serviceTitle" to serviceTitle,
            "serviceCategory" to serviceCategory,
            "customerId" to customerId,
            "customerName" to customerName,
            "customerPhone" to customerPhone,
            "workerId" to workerId,
            "workerName" to workerName,
            "workerTrade" to workerTrade,
            "priceInr" to priceInr,
            "status" to status.name,
            "requirementDetails" to requirementDetails,
            "serviceAddress" to serviceAddress,
            "preferredDate" to preferredDate,
            "timeSlot" to timeSlot,
            "instructions" to instructions,
            "imageUrl" to imageUrl,
            "createdAt" to createdAt,
            "hasReview" to hasReview
        )
    }
}

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val receiverId: String = "",
    val text: String = "",
    val imageUrl: String? = null,
    val orderIdRef: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val formattedTime: String = "Just now",
    val isRead: Boolean = true
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "conversationId" to conversationId,
            "senderId" to senderId,
            "senderName" to senderName,
            "receiverId" to receiverId,
            "text" to text,
            "imageUrl" to imageUrl,
            "orderIdRef" to orderIdRef,
            "timestamp" to timestamp,
            "formattedTime" to formattedTime,
            "isRead" to isRead
        )
    }
}

data class Review(
    val id: String = "",
    val workerId: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val serviceId: String = "",
    val serviceTitle: String = "",
    val orderId: String = "",
    val rating: Int = 5,
    val comment: String = "",
    val tags: List<String> = emptyList(),
    val imageUrl: String? = null,
    val date: String = "Today",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "workerId" to workerId,
            "customerId" to customerId,
            "customerName" to customerName,
            "serviceId" to serviceId,
            "serviceTitle" to serviceTitle,
            "orderId" to orderId,
            "rating" to rating,
            "comment" to comment,
            "tags" to tags,
            "imageUrl" to imageUrl,
            "date" to date,
            "createdAt" to createdAt
        )
    }
}

enum class NotificationType {
    BOOKING_NEW,
    BOOKING_ACCEPTED,
    BOOKING_REJECTED,
    ORDER_COMPLETED,
    REVIEW_RECEIVED,
    NEW_MESSAGE,
    NEW_FOLLOWER,
    POST_LIKED,
    NEW_COMMENT,
    SUPPORT_REPLY,
    COMPLAINT_STATUS_CHANGED,
    DISPUTE_STATUS_CHANGED,
    REFUND_STATUS_CHANGED
}

data class NotificationItem(
    val id: String = "",
    val userId: String = "",
    val type: NotificationType = NotificationType.BOOKING_NEW,
    val title: String = "",
    val message: String = "",
    val relatedId: String? = null,
    val timestamp: String = "Just now",
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toFirestoreMap(): Map<String, Any?> {
        return mapOf(
            "id" to id,
            "userId" to userId,
            "type" to type.name,
            "title" to title,
            "message" to message,
            "relatedId" to relatedId,
            "timestamp" to timestamp,
            "isRead" to isRead,
            "createdAt" to createdAt
        )
    }
}

object SkillCategories {
    val ALL = listOf(
        CategoryItem("All", "सभी", "🛠️"),
        CategoryItem("Welding", "वेल्डिंग", "⚡"),
        CategoryItem("Electrician", "इलेक्ट्रीशियन", "💡"),
        CategoryItem("Plumber", "प्लम्बर", "🚰"),
        CategoryItem("Carpenter", "कारपेंटर", "🪚"),
        CategoryItem("Painter", "पेंटर", "🎨"),
        CategoryItem("Mechanic", "मैकेनिक", "🔧"),
        CategoryItem("AC Repair", "एसी रिपेयर", "❄️"),
        CategoryItem("Mobile Repair", "मोबाइल रिपेयर", "📱"),
        CategoryItem("Computer Repair", "कंप्यूटर", "💻"),
        CategoryItem("Tutor", "ट्यूटर", "📚"),
        CategoryItem("Graphic Designer", "ग्राफिक डिज़ाइन", "✒️"),
        CategoryItem("Video Editor", "वीडियो एडिटर", "🎬"),
        CategoryItem("Photographer", "फोटोग्राफर", "📷"),
        CategoryItem("Beauty Services", "ब्यूटी सेवाएं", "💇"),
        CategoryItem("Cleaning", "सफाई सेवाएं", "🧹"),
        CategoryItem("Other", "अन्य", "✨")
    )
}

data class CategoryItem(
    val name: String,
    val hindiName: String,
    val icon: String
)
