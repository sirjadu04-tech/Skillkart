package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// SkillKart Brand Palette
val SaffronPrimary = Color(0xFFE65100)
val SaffronSecondary = Color(0xFFFF8F00)
val SaffronContainer = Color(0xFFFFE0B2)
val OnSaffronContainer = Color(0xFF4E1A00)

val IndigoPrimary = Color(0xFF1A237E)
val IndigoSecondary = Color(0xFF283593)
val IndigoContainer = Color(0xFFE8EAF6)
val OnIndigoContainer = Color(0xFF0D1244)

val EmeraldSuccess = Color(0xFF2E7D32)
val EmeraldSuccessContainer = Color(0xFFE8F5E9)
val GoldStar = Color(0xFFFFA000)
val GoldContainer = Color(0xFFFFF8E1)

val SlateBackground = Color(0xFFF8FAFC)
val SlateSurface = Color(0xFFFFFFFF)
val SlateSurfaceVariant = Color(0xFFF1F5F9)
val SlateBorder = Color(0xFFE2E8F0)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)

// Dark Palette
val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF151C2C)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkBorder = Color(0xFF334155)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkSaffronPrimary = Color(0xFFFFB74D)
val DarkIndigoContainer = Color(0xFF283593)

