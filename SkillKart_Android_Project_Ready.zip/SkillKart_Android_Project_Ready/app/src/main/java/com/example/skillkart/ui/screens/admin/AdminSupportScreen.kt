package com.example.skillkart.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.QuestionAnswer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SecondaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.skillkart.data.model.Complaint
import com.example.skillkart.data.model.ComplaintCategories
import com.example.skillkart.data.model.FaqItem
import com.example.skillkart.data.model.SupportMessage
import com.example.skillkart.data.model.SupportTicket
import com.example.skillkart.data.model.TicketPriority
import com.example.skillkart.data.model.TicketStatus
import com.example.skillkart.data.model.User
import com.example.skillkart.ui.theme.EmeraldSuccess
import com.example.skillkart.ui.theme.IndigoPrimary
import com.example.skillkart.ui.theme.SaffronPrimary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminSupportScreen(
    currentUser: User,
    supportTickets: List<SupportTicket>,
    supportMessages: Map<String, List<SupportMessage>>,
    complaints: List<Complaint>,
    faqs: List<FaqItem>,
    onBack: () -> Unit,
    onSendAdminReply: (ticketId: String, text: String, imageUrl: String?) -> Unit,
    onUpdateTicketStatus: (ticketId: String, status: TicketStatus) -> Unit,
    onUpdateTicketPriority: (ticketId: String, priority: TicketPriority) -> Unit,
    onUpdateInternalNotes: (ticketId: String, notes: String) -> Unit,
    onSaveFaq: (FaqItem) -> Unit,
    onDeleteFaq: (String) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var ticketStatusFilter by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    var selectedTicketForDetail by remember { mutableStateOf<SupportTicket?>(null) }
    var showFaqEditDialog by remember { mutableStateOf<FaqItem?>(null) }
    var showNewFaqDialog by remember { mutableStateOf(false) }

    // Detail Dialog State
    selectedTicketForDetail?.let { activeTicket ->
        val latestTicket = supportTickets.find { it.id == activeTicket.id } ?: activeTicket
        val messages = supportMessages[latestTicket.id] ?: emptyList()

        AdminTicketDetailDialog(
            ticket = latestTicket,
            messages = messages,
            onDismiss = { selectedTicketForDetail = null },
            onSendReply = { text, img ->
                onSendAdminReply(latestTicket.id, text, img)
            },
            onUpdateStatus = { st ->
                onUpdateTicketStatus(latestTicket.id, st)
            },
            onUpdatePriority = { pr ->
                onUpdateTicketPriority(latestTicket.id, pr)
            },
            onSaveNotes = { notes ->
                onUpdateInternalNotes(latestTicket.id, notes)
            }
        )
    }

    // FAQ Add/Edit Dialog
    if (showNewFaqDialog || showFaqEditDialog != null) {
        val itemToEdit = showFaqEditDialog
        AdminFaqEditDialog(
            faqItem = itemToEdit,
            onDismiss = {
                showNewFaqDialog = false
                showFaqEditDialog = null
            },
            onSave = { faq ->
                onSaveFaq(faq)
                showNewFaqDialog = false
                showFaqEditDialog = null
            }
        )
    }

    Scaffold(
        modifier = Modifier.testTag("admin_support_screen"),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD32F2F)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = "Admin",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Admin Support Center",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "SkillKart Operations & Helpdesk",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("admin_support_back_button")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Header
            SecondaryTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IndigoPrimary
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        val openCount = supportTickets.count { it.isOpen }
                        Text(
                            text = if (openCount > 0) "Tickets ($openCount)" else "Tickets",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Complaints (${complaints.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Text(
                            text = "FAQ Manager",
                            fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }

            when (selectedTab) {
                0 -> {
                    // --- TICKETS TAB ---
                    val statusOptions = listOf("All", "Open", "Waiting for Support", "Waiting for User", "Resolved", "Closed")

                    val filteredTickets = supportTickets.filter { ticket ->
                        val matchStatus = when (ticketStatusFilter) {
                            "All" -> true
                            "Open" -> ticket.status == TicketStatus.OPEN
                            "Waiting for Support" -> ticket.status == TicketStatus.WAITING_FOR_SUPPORT
                            "Waiting for User" -> ticket.status == TicketStatus.WAITING_FOR_USER
                            "Resolved" -> ticket.status == TicketStatus.RESOLVED
                            "Closed" -> ticket.status == TicketStatus.CLOSED
                            else -> true
                        }
                        val matchSearch = searchQuery.isBlank() ||
                                ticket.ticketId.contains(searchQuery, ignoreCase = true) ||
                                ticket.userName.contains(searchQuery, ignoreCase = true) ||
                                ticket.subject.contains(searchQuery, ignoreCase = true) ||
                                ticket.category.contains(searchQuery, ignoreCase = true)
                        matchStatus && matchSearch
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Search bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search by ticket #, user name, category...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("admin_ticket_search_input"),
                            leadingIcon = {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IndigoPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Status filter chips
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(statusOptions) { opt ->
                                val isSelected = ticketStatusFilter == opt
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { ticketStatusFilter = opt },
                                    label = { Text(opt) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = IndigoPrimary,
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Tickets list
                        if (filteredTickets.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No tickets match your filters.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredTickets) { ticket ->
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedTicketForDetail = ticket }
                                            .testTag("admin_ticket_item_${ticket.id}"),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(text = ComplaintCategories.getIcon(ticket.category), fontSize = 16.sp)
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Text(
                                                        text = "#${ticket.ticketId}",
                                                        style = MaterialTheme.typography.titleSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                    Spacer(modifier = Modifier.width(6.dp))
                                                    Surface(
                                                        shape = RoundedCornerShape(4.dp),
                                                        color = if (ticket.userRole == "worker") SaffronPrimary.copy(alpha = 0.15f) else IndigoPrimary.copy(alpha = 0.15f)
                                                    ) {
                                                        Text(
                                                            text = ticket.userRole.uppercase(),
                                                            style = MaterialTheme.typography.labelSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = if (ticket.userRole == "worker") SaffronPrimary else IndigoPrimary,
                                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }

                                                // Priority badge
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = when (ticket.priority) {
                                                        TicketPriority.URGENT -> Color(0xFFFFEBEE)
                                                        TicketPriority.HIGH -> Color(0xFFFFF3E0)
                                                        TicketPriority.MEDIUM -> Color(0xFFE3F2FD)
                                                        TicketPriority.LOW -> Color(0xFFECEFF1)
                                                    }
                                                ) {
                                                    Text(
                                                        text = ticket.priority.displayName,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = when (ticket.priority) {
                                                            TicketPriority.URGENT -> Color(0xFFD32F2F)
                                                            TicketPriority.HIGH -> SaffronPrimary
                                                            TicketPriority.MEDIUM -> IndigoPrimary
                                                            TicketPriority.LOW -> Color(0xFF546E7A)
                                                        },
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))

                                            Text(
                                                text = "${ticket.userName} • ${ticket.subject}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )

                                            if (ticket.lastMessage.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = ticket.lastMessage,
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 2
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(8.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val (statusBg, statusFg) = when (ticket.status) {
                                                    TicketStatus.OPEN -> Pair(Color(0xFFE3F2FD), IndigoPrimary)
                                                    TicketStatus.WAITING_FOR_SUPPORT -> Pair(Color(0xFFFFF3E0), SaffronPrimary)
                                                    TicketStatus.WAITING_FOR_USER -> Pair(Color(0xFFEDE7F6), Color(0xFF5E35B1))
                                                    TicketStatus.RESOLVED -> Pair(Color(0xFFE8F5E9), EmeraldSuccess)
                                                    TicketStatus.CLOSED -> Pair(Color(0xFFECEFF1), Color(0xFF546E7A))
                                                }

                                                Surface(
                                                    shape = RoundedCornerShape(6.dp),
                                                    color = statusBg
                                                ) {
                                                    Text(
                                                        text = ticket.status.displayName,
                                                        style = MaterialTheme.typography.labelSmall,
                                                        fontWeight = FontWeight.Bold,
                                                        color = statusFg,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }

                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    if (ticket.unreadAdminCount > 0) {
                                                        Surface(
                                                            shape = CircleShape,
                                                            color = Color(0xFFD32F2F),
                                                            modifier = Modifier.padding(end = 6.dp)
                                                        ) {
                                                            Text(
                                                                text = "${ticket.unreadAdminCount} new",
                                                                style = MaterialTheme.typography.labelSmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = Color.White,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
                                                            )
                                                        }
                                                    }
                                                    Text(
                                                        text = "Manage →",
                                                        style = MaterialTheme.typography.labelMedium,
                                                        fontWeight = FontWeight.Bold,
                                                        color = IndigoPrimary
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // --- COMPLAINTS TAB ---
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(complaints) { cmp ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(text = ComplaintCategories.getIcon(cmp.category), fontSize = 16.sp)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = cmp.complaintId,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = IndigoPrimary.copy(alpha = 0.1f)
                                        ) {
                                            Text(
                                                text = cmp.status,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = IndigoPrimary,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "User: ${cmp.userName} • Category: ${cmp.category}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )

                                    if (!cmp.orderTitle.isNullOrBlank()) {
                                        Text(
                                            text = "Order: ${cmp.orderTitle}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = cmp.details,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        Button(
                                            onClick = {
                                                val targetTicket = supportTickets.find { it.id == cmp.ticketId }
                                                if (targetTicket != null) {
                                                    selectedTicketForDetail = targetTicket
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
                                        ) {
                                            Text("Open Ticket Chat")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // --- FAQ MANAGER TAB ---
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "SkillKart FAQ Directory",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Button(
                                onClick = { showNewFaqDialog = true },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                modifier = Modifier.testTag("admin_add_faq_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add FAQ")
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(faqs) { faq ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = IndigoPrimary.copy(alpha = 0.08f)
                                            ) {
                                                Text(
                                                    text = faq.category,
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = IndigoPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                )
                                            }

                                            Row {
                                                IconButton(
                                                    onClick = { showFaqEditDialog = faq },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = IndigoPrimary, modifier = Modifier.size(16.dp))
                                                }
                                                Spacer(modifier = Modifier.width(4.dp))
                                                IconButton(
                                                    onClick = { onDeleteFaq(faq.id) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFD32F2F), modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = faq.question,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = faq.answer,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminTicketDetailDialog(
    ticket: SupportTicket,
    messages: List<SupportMessage>,
    onDismiss: () -> Unit,
    onSendReply: (String, String?) -> Unit,
    onUpdateStatus: (TicketStatus) -> Unit,
    onUpdatePriority: (TicketPriority) -> Unit,
    onSaveNotes: (String) -> Unit
) {
    var replyText by remember { mutableStateOf("") }
    var internalNotesText by remember { mutableStateOf(ticket.internalNotes) }
    var showStatusDropdown by remember { mutableStateOf(false) }
    var showPriorityDropdown by remember { mutableStateOf(false) }
    var showNotesSection by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .testTag("admin_ticket_detail_dialog"),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Header
                TopAppBar(
                    title = {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Ticket #${ticket.ticketId}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "(${ticket.userName})",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Text(
                                text = ticket.subject,
                                style = MaterialTheme.typography.labelSmall,
                                color = IndigoPrimary,
                                maxLines = 1
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    },
                    actions = {
                        IconButton(onClick = { showNotesSection = !showNotesSection }) {
                            Icon(Icons.Default.NoteAdd, contentDescription = "Internal Notes", tint = IndigoPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )

                // Controls Bar (Status & Priority)
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Status selector
                        Box {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = IndigoPrimary,
                                modifier = Modifier.clickable { showStatusDropdown = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Status: ${ticket.status.displayName} ▼",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                            DropdownMenu(
                                expanded = showStatusDropdown,
                                onDismissRequest = { showStatusDropdown = false }
                            ) {
                                TicketStatus.values().forEach { st ->
                                    DropdownMenuItem(
                                        text = { Text(st.displayName) },
                                        onClick = {
                                            showStatusDropdown = false
                                            onUpdateStatus(st)
                                        }
                                    )
                                }
                            }
                        }

                        // Priority selector
                        Box {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SaffronPrimary,
                                modifier = Modifier.clickable { showPriorityDropdown = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Priority: ${ticket.priority.displayName} ▼",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                            DropdownMenu(
                                expanded = showPriorityDropdown,
                                onDismissRequest = { showPriorityDropdown = false }
                            ) {
                                TicketPriority.values().forEach { pr ->
                                    DropdownMenuItem(
                                        text = { Text(pr.displayName) },
                                        onClick = {
                                            showPriorityDropdown = false
                                            onUpdatePriority(pr)
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Internal Notes drawer if open
                if (showNotesSection) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDE7))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "🔒 Internal Operations Notes (Not visible to user)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF57F17)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = internalNotesText,
                                onValueChange = { internalNotesText = it },
                                placeholder = { Text("Log internal investigation findings, phone calls with worker, or refund authorization codes...") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = {
                                        onSaveNotes(internalNotesText)
                                        showNotesSection = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57F17))
                                ) {
                                    Text("Save Notes", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Conversation list
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { msg ->
                        val isFromAdmin = msg.senderRole == "admin" || msg.isFromSupport

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (isFromAdmin) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isFromAdmin) IndigoPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = if (isFromAdmin) "SkillKart Support" else msg.senderName,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isFromAdmin) Color.White.copy(alpha = 0.8f) else IndigoPrimary
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = msg.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (isFromAdmin) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = msg.formattedTime,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isFromAdmin) Color.White.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Admin Reply bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = replyText,
                            onValueChange = { replyText = it },
                            placeholder = { Text("Reply as SkillKart Support...") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("admin_reply_input"),
                            shape = RoundedCornerShape(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (replyText.isNotBlank()) {
                                    onSendReply(replyText, null)
                                    replyText = ""
                                }
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(IndigoPrimary)
                                .testTag("admin_reply_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send",
                                tint = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminFaqEditDialog(
    faqItem: FaqItem?,
    onDismiss: () -> Unit,
    onSave: (FaqItem) -> Unit
) {
    var question by remember { mutableStateOf(faqItem?.question ?: "") }
    var answer by remember { mutableStateOf(faqItem?.answer ?: "") }
    var category by remember { mutableStateOf(faqItem?.category ?: "General") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (faqItem == null) "Add FAQ" else "Edit FAQ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    label = { Text("Question") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = answer,
                    onValueChange = { answer = it },
                    label = { Text("Answer") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (question.isNotBlank() && answer.isNotBlank()) {
                        val updated = FaqItem(
                            id = faqItem?.id ?: "faq_${System.currentTimeMillis()}",
                            question = question.trim(),
                            answer = answer.trim(),
                            category = category.trim(),
                            orderIndex = faqItem?.orderIndex ?: 10
                        )
                        onSave(updated)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IndigoPrimary)
            ) {
                Text("Save FAQ", color = Color.White)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
