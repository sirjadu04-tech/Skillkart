package com.example.skillkart.ui.screens.orders

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.skillkart.data.model.Order
import com.example.skillkart.data.model.OrderStatus
import com.example.skillkart.data.model.User
import com.example.skillkart.data.model.UserRole
import com.example.skillkart.ui.components.OrderCard
import com.example.skillkart.ui.theme.SaffronPrimary

@Composable
fun OrdersScreen(
    orders: List<Order>,
    currentUser: User,
    onOrderClick: (Order) -> Unit,
    onChatWithPartner: (partnerId: String, orderId: String) -> Unit,
    onUpdateStatus: (Order, OrderStatus) -> Unit,
    onReviewClick: (Order) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Active, 1 = Completed, 2 = All

    val isWorker = currentUser.role == UserRole.WORKER

    // Relevant orders for current user
    val userOrders = remember(orders, currentUser) {
        if (isWorker) {
            orders.filter { it.workerId == currentUser.id }
        } else {
            orders.filter { it.customerId == currentUser.id }
        }
    }

    val filteredOrders = remember(userOrders, selectedTab) {
        when (selectedTab) {
            0 -> userOrders.filter { it.status == OrderStatus.PENDING || it.status == OrderStatus.ACCEPTED || it.status == OrderStatus.IN_PROGRESS }
            1 -> userOrders.filter { it.status == OrderStatus.COMPLETED }
            2 -> userOrders
            else -> userOrders
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("orders_screen")
    ) {
        // Header info
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            Text(
                text = if (isWorker) "Worker Service Requests (ऑर्डर्स)" else "My Bookings (मेरी बुकिंग्स)",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = if (isWorker) "Manage your service leads, accept bookings, and mark jobs done" else "Track your booked packages and message your workers",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp)),
                divider = {}
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Active", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Completed", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("All (${userOrders.size})", fontWeight = FontWeight.Bold) }
                )
            }
        }

        if (filteredOrders.isEmpty()) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier.padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "No orders found in this status",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (isWorker) "When customers book your packages, they will appear here!" else "Explore packages in Discover and book your first service!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filteredOrders, key = { it.id }) { order ->
                    val partnerId = if (isWorker) order.customerId else order.workerId
                    OrderCard(
                        order = order,
                        isWorkerView = isWorker,
                        onOrderClick = { onOrderClick(order) },
                        onChatClick = { onChatWithPartner(partnerId, order.id) },
                        onStatusChange = { newStatus -> onUpdateStatus(order, newStatus) },
                        onReviewClick = { onReviewClick(order) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }
}
