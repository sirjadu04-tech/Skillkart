package com.example

import com.example.skillkart.data.model.ServicePackage
import com.example.skillkart.data.model.SkillCategories
import com.example.skillkart.ui.viewmodel.FilterState
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun testAll17SkillCategoriesPresent() {
        assertEquals(17, SkillCategories.ALL.size)
        assertTrue(SkillCategories.ALL.any { it.name == "Welding" })
        assertTrue(SkillCategories.ALL.any { it.name == "Electrician" })
    }

    @Test
    fun testFilterStateLogic() {
        val defaultFilter = FilterState()
        assertEquals("All", defaultFilter.selectedCategory)
        assertEquals("", defaultFilter.searchQuery)
        assertEquals(10000, defaultFilter.maxPrice)

        val updatedFilter = defaultFilter.copy(
            selectedCategory = "Electrician",
            searchQuery = "Wiring",
            maxPrice = 2500,
            minRating = 4.5f
        )
        assertEquals("Electrician", updatedFilter.selectedCategory)
        assertEquals("Wiring", updatedFilter.searchQuery)
        assertEquals(2500, updatedFilter.maxPrice)
        assertEquals(4.5f, updatedFilter.minRating)
    }
}

