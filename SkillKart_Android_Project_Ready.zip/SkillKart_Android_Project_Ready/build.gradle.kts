plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.google.devtools.ksp) apply false
    alias(libs.plugins.secrets) apply false
    alias(libs.plugins.google.services) apply false
}
e
    alias(libs.plugins.secrets) apply false
}
 
.google.services) apply false
}

}
apply false
}
.google.services) apply false
}

}
