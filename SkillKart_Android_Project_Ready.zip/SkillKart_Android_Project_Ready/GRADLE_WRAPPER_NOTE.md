# Gradle Wrapper note

This project includes `gradlew` and `gradlew.bat` launchers plus `gradle/wrapper/gradle-wrapper.properties`.
The Unix launcher uses an installed Gradle when available; otherwise it downloads Gradle 9.3.1.
